/* File : CGNInit.c */

#include "SYSTEM.h"
#include "Prelude.h"
#include "SetPrelude.h"
#include "CautiousPrelude.h"
#include "LazyPrelude.h"
#include "IncrPrelude.h"
#include "CodePrelude.h"
#include "FunctionPrelude.h"

extern void CGNInit_Init(void)
{
  Prelude_InitGlobals();
  SetPrelude_InitGlobals();
  CautiousPrelude_InitGlobals();
  LazyPrelude_InitGlobals();
  IncrPrelude_InitGlobals();
  CodePrelude_InitGlobals();
  FunctionPrelude_InitGlobals();
} /* Init */

/* END CGNInit */
