/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef _Prelude_C
#define _Prelude_C

#include "SYSTEM.h"
#include "Strings.h"
#include "StandardTypes.h"
#include "FileStream.h"

#define _NULL()		do {} while (0)
#define _CONSTRUCT(a,b)	b

#define _PLAIN_NULL(x)		x
#define _PLAIN_CONSTRUCT(a,b)	b

#define _PLAIN_START(a) 	(TRUE)
#define _PLAIN_DESTRUCT(a,s,x)	((!*s) ? FALSE : (*x = *a, *s=FALSE, TRUE))

#define _F_PLAIN_START(a) 		_PLAIN_START(a)
#define _F_PLAIN_DESTRUCT(a,i,x)	_PLAIN_DESTRUCT(a,i,x)


#define _CAST(t,x)	((t)(x))
#define _DISCARD(x)	((void)(x))

#define _EQ(x,y)	(x == y)
#define _NEQ(x,y)	(x != y)
#define _LT(x,y)	(x < y)
#define _LE(x,y)	(x <= y)
#define _GT(x,y)	(x > y)
#define _GE(x,y)	(x >= y)

#define _PLUS(x,y)	(x + y)
#define _MINUS(x,y)	(x - y)
#define _NEG(x)		(-x)
#define _TIMES(x,y)	(x * y)
#define _DIV(x,y)	(x / y)
#define _REM(x,y)	(x % y)
#define _MOD(x,y)	((StandardTypes_Int)((unsigned)x % (unsigned)y))
#define _ASSPLUS(x,y)	(*x += y)
#define _ASSMINUS(x,y)	(*x -= y)
#define _ASSTIMES(x,y)	(*x *= y)
#define _ASSDIV(x,y)	(*x /= y)

#define _MAX(x,y)	((x>y)?x:y)
#define _MIN(x,y)	((x<y)?x:y)

#define _EVEN(x)	(x % 2 == 0)
#define _ODD(x)		(! _EVEN(x))

#define _FL2INT(x)	((StandardTypes_Int)x)
#define _CHAR2INT(x)	((StandardTypes_Int)x)
#define _INT2CHAR(x)	((StandardTypes_Char)x)
#define _INT2FL(x)	((StandardTypes_Float)x)

#define _OR(x,y)	(x || y)
#define _AND(x,y)	(x && y)
#define _IMPLIES(x,y)	(!x || y)
#define _NOT(x)		(!x)

#define _IN(x,y)	IN(x,y)

#define _ARRAY_SIZE(x)	(x->size)

#define _ARRAY_START(a) (0)
#define _ARRAY_DESTRUCT(a,i,x)	(*i >= (*a)->size ? FALSE : (*x = (*a)->value[*i], (*i)++, TRUE))

#define _F_ARRAY_START(a) 		_ARRAY_START(a)
#define _F_ARRAY_DESTRUCT(a,i,x)	_ARRAY_DESTRUCT(a,i,x)


#define _IDENT_LENGTH(i)	((StandardTypes_Int)(i->length))
#define _IDENT2STRING(i)	((StandardTypes_String)(i->represent))

#define _IDENT_START(a) (0)
#define _IDENT_DESTRUCT(a,i,x)	(*i >= (*a)->length ? FALSE : (*x = (*a)->represent[*i], (*i)++, TRUE))

#define _F_IDENT_START(a) (0)
#define _F_IDENT_DESTRUCT(a,i,x)	(*i >= (*a)->length ? FALSE : (*x = (*a)->represent[*i], (*i)++, TRUE))

#define _STRING_EQ(x,y)	(Strings_Compare(x,y) == SystemTypes_EQ)
#define _STRING_LT(x,y)	(Strings_Compare(x,y) == SystemTypes_LT)
#define _STRING_GT(x,y)	(Strings_Compare(x,y) == SystemTypes_GT)

#define _STRING_START(a) (0)
#define _STRING_DESTRUCT(a,i,x)	((*a)[*i] == 0 ? FALSE : (*x = (*a)[*i], (*i)++, TRUE))

#define _F_STRING_START(a) (0)
#define _F_STRING_DESTRUCT(a,i,x)	((*a)[*i] == 0 ? FALSE : (*x = (*a)[*i], (*i)++, TRUE))

/*************** Int operations ***************/

extern StandardTypes_Int _F_Plus (StandardTypes_Int a, StandardTypes_Int b);
extern StandardTypes_Int _F_Minus (StandardTypes_Int a, StandardTypes_Int b);
extern StandardTypes_Int _F_Times (StandardTypes_Int a, StandardTypes_Int b);
extern StandardTypes_Int _F_Div (StandardTypes_Int a, StandardTypes_Int b);
extern StandardTypes_Int _F_Rem (StandardTypes_Int a, StandardTypes_Int b);
extern StandardTypes_Int _F_Mod (StandardTypes_Int a, StandardTypes_Int b);
extern StandardTypes_Int _F_Neg (StandardTypes_Int a);
extern StandardTypes_Int _F_Min (StandardTypes_Int a, StandardTypes_Int b);
extern StandardTypes_Int _F_Max (StandardTypes_Int a, StandardTypes_Int b);

extern StandardTypes_Bool _F_Even (StandardTypes_Int a);
extern StandardTypes_Bool _F_Odd (StandardTypes_Int a);

extern void _F_AssPlus  (StandardTypes_Int *a, StandardTypes_Int b);
extern void _F_AssMinus (StandardTypes_Int *a, StandardTypes_Int b);
extern void _F_AssTimes (StandardTypes_Int *a, StandardTypes_Int b);
extern void _F_AssDiv   (StandardTypes_Int *a, StandardTypes_Int b);

/*************** Float operations ***************/

extern StandardTypes_Float _Fl_Plus (StandardTypes_Float a, StandardTypes_Float b);
extern StandardTypes_Float _Fl_Minus (StandardTypes_Float a, StandardTypes_Float b);
extern StandardTypes_Float _Fl_Times (StandardTypes_Float a, StandardTypes_Float b);
extern StandardTypes_Float _Fl_Div (StandardTypes_Float a, StandardTypes_Float b);
extern StandardTypes_Float _Fl_Neg (StandardTypes_Float a);
extern StandardTypes_Float _Fl_Min (StandardTypes_Float a, StandardTypes_Float b);
extern StandardTypes_Float _Fl_Max (StandardTypes_Float a, StandardTypes_Float b);

extern StandardTypes_Int   _F_Float2Int (StandardTypes_Float a);
extern StandardTypes_Float _F_Int2Float (StandardTypes_Int a);

extern void PrintFloat (FileStream_WriteFile f, StandardTypes_Float real);

extern void _Fl_AssPlus  (StandardTypes_Float *a, StandardTypes_Float b);
extern void _Fl_AssMinus (StandardTypes_Float *a, StandardTypes_Float b);
extern void _Fl_AssTimes (StandardTypes_Float *a, StandardTypes_Float b);
extern void _Fl_AssDiv   (StandardTypes_Float *a, StandardTypes_Float b);

/*************** Boolean operations ***************/

extern StandardTypes_Bool _F_And (StandardTypes_Bool a, StandardTypes_Bool b);
extern StandardTypes_Bool _F_Or (StandardTypes_Bool a, StandardTypes_Bool b);
extern StandardTypes_Bool _F_Implies (StandardTypes_Bool a, StandardTypes_Bool b);
extern StandardTypes_Bool _F_Not (StandardTypes_Bool a);

/*************** Char operations ***************/

extern StandardTypes_Int  _F_Char2Int (StandardTypes_Char c);
extern StandardTypes_Char _F_Int2Char (StandardTypes_Int i);

/*************** String operations ***************/

extern StandardTypes_Bool _FS_Eq (StandardTypes_String a, StandardTypes_String b);
extern StandardTypes_Bool _FS_Lt (StandardTypes_String a, StandardTypes_String b);
extern StandardTypes_Bool _FS_Gt (StandardTypes_String a, StandardTypes_String b);
extern StandardTypes_Bool _FS_Le (StandardTypes_String a, StandardTypes_String b);
extern StandardTypes_Bool _FS_Ge (StandardTypes_String a, StandardTypes_String b);


/*************** Bitset operations ***************/

#define _EMPTYSET() ((StandardTypes_Bitset)0)

extern StandardTypes_Bitset _F_Set_Empty (void);

extern StandardTypes_Bool _F_Set_In (StandardTypes_Int i, StandardTypes_Bitset s);
extern StandardTypes_Bool _F_Set_Subset (StandardTypes_Bitset i, StandardTypes_Bitset s);

extern StandardTypes_Bitset _F_Set_Incl (StandardTypes_Bitset s, StandardTypes_Int i);
extern StandardTypes_Bitset _F_Set_Excl (StandardTypes_Bitset s, StandardTypes_Int i);
extern StandardTypes_Bitset _F_Set_Union (StandardTypes_Bitset s, StandardTypes_Bitset i);
extern StandardTypes_Bitset _F_Set_Diff (StandardTypes_Bitset s, StandardTypes_Bitset i);
extern StandardTypes_Bitset _F_Set_Intersect (StandardTypes_Bitset s, StandardTypes_Bitset i);
extern StandardTypes_Bitset _F_Set_XOr (StandardTypes_Bitset s, StandardTypes_Bitset i);
extern StandardTypes_Bitset _F_Set_Negate (StandardTypes_Bitset s);
extern StandardTypes_Int _F_Set_Size (StandardTypes_Bitset s);

extern StandardTypes_Bitset _F_ShiftLeft (StandardTypes_Bitset s, StandardTypes_Int i);
extern StandardTypes_Bitset _F_ShiftRight (StandardTypes_Bitset s, StandardTypes_Int i);

#define _BITSET_NULL(b) (0)
#define _BITSET_CONSTRUCT(b,x)	(b | (1 << x))

extern StandardTypes_Bitset _F_BITSET_NULL (StandardTypes_Int b);
extern StandardTypes_Bitset _F_BITSET_CONSTRUCT (StandardTypes_Int b, StandardTypes_Bitset x);

#define _BITSET_START(b) (1)
#define _BITSET_DESTRUCT(b,s,x)	(*s == 0 ? FALSE : (*x = (*b & *s) != 0, *s = *s << 1, TRUE))

extern StandardTypes_Int _F_BITSET_START (StandardTypes_Bitset s);
extern StandardTypes_Bool _F_BITSET_DESTRUCT (StandardTypes_Bitset *b, StandardTypes_Int *s, StandardTypes_Int*x);

/*************** Generic comparison operations ***************/

extern StandardTypes_Bool _F_Eq_1 (TYPE_1 a, TYPE_1 b);	
extern StandardTypes_Bool _F_Eq_2 (TYPE_2 a, TYPE_2 b);	
extern StandardTypes_Bool _F_Eq_4 (TYPE_4 a, TYPE_4 b);	
extern StandardTypes_Bool _F_Eq_8 (TYPE_8 a, TYPE_8 b);	

extern StandardTypes_Bool _F_Neq_1 (TYPE_1 a, TYPE_1 b);	
extern StandardTypes_Bool _F_Neq_2 (TYPE_2 a, TYPE_2 b);	
extern StandardTypes_Bool _F_Neq_4 (TYPE_4 a, TYPE_4 b);	
extern StandardTypes_Bool _F_Neq_8 (TYPE_8 a, TYPE_8 b);	

/* On Ints and Chars */

extern StandardTypes_Bool _F_Lt (StandardTypes_Int a, StandardTypes_Int b);	/* On Ints and Chars */
extern StandardTypes_Bool _F_Le (StandardTypes_Int a, StandardTypes_Int b);
extern StandardTypes_Bool _F_Gt (StandardTypes_Int a, StandardTypes_Int b);
extern StandardTypes_Bool _F_Ge (StandardTypes_Int a, StandardTypes_Int b);

extern StandardTypes_Bool _Fl_Lt (StandardTypes_Float a, StandardTypes_Float b);	/* On Floats */
extern StandardTypes_Bool _Fl_Le (StandardTypes_Float a, StandardTypes_Float b);
extern StandardTypes_Bool _Fl_Gt (StandardTypes_Float a, StandardTypes_Float b);
extern StandardTypes_Bool _Fl_Ge (StandardTypes_Float a, StandardTypes_Float b);

#define _LIST_NULL(x) 		(NULL)
#define _LIST_CONSTRUCT(l,x)	(NULL)

typedef struct Struct_Prelude_List1 *_List1;
typedef struct Struct_Prelude_List2 *_List2;
typedef struct Struct_Prelude_List4 *_List4;
typedef struct Struct_Prelude_List8 *_List8;

extern _List1 _F_LIST_NULL_1 (TYPE_1 x);
/* extern _List2 _F_LIST_NULL_2 (TYPE_2 x); */
extern _List4 _F_LIST_NULL_4 (TYPE_4 x);
extern _List8 _F_LIST_NULL_8 (TYPE_8 x);

extern _List1 _F_LIST_CONSTRUCT_1 (_List1 l, TYPE_1 x);
/* extern _List2 _F_LIST_CONSTRUCT_2 (_List2 l, TYPE_2 x); */
extern _List4 _F_LIST_CONSTRUCT_4 (_List4 l, TYPE_4 x);
extern _List8 _F_LIST_CONSTRUCT_8 (_List8 l, TYPE_8 x);

#define _LIST_START(a) (a)
#define _LIST_DESTRUCT(a,i,x)	(*i == NULL ? FALSE : (*x = (*i)->head, *i = (*i)->tail, TRUE))

extern _List1 _F_LIST_START_1 (_List1 a);
/* extern _List2 _F_LIST_START_2 (_List2 a); */
extern _List4 _F_LIST_START_4 (_List4 a);
extern _List8 _F_LIST_START_8 (_List8 a);

extern StandardTypes_Bool _F_LIST_DESTRUCT_1 (_List1 *a, _List1 *i, TYPE_1 *x);
/* extern StandardTypes_Bool _F_LIST_DESTRUCT_2 (_List2 *a, _List2 *i, TYPE_2 *x); */
extern StandardTypes_Bool _F_LIST_DESTRUCT_4 (_List4 *a, _List4 *i, TYPE_4 *x);
extern StandardTypes_Bool _F_LIST_DESTRUCT_8 (_List8 *a, _List8 *i, TYPE_8 *x);

#define GetField(x,f)   (x->f)
#define SetField(x,f,e) (x->f = e)

#define GetStructField(x,f)   (x.f)
#define SetStructField(x,f,e) (x.f = e)

extern StandardTypes_Int _F_Array_Size_1 (StandardTypes_Array1 a);
/* extern StandardTypes_Int _F_Array_Size_2 (StandardTypes_Array2 a); */
extern StandardTypes_Int _F_Array_Size_4 (StandardTypes_Array4 a);
extern StandardTypes_Int _F_Array_Size_8 (StandardTypes_Array8 a);

/************** sets **************/

typedef struct Struct_SetPrelude_Set1 *_Set1;
typedef struct Struct_SetPrelude_Set2 *_Set2;
typedef struct Struct_SetPrelude_Set4 *_Set4;
typedef struct Struct_SetPrelude_Set8 *_Set8;

#define _SET_NULL(x) 		(NULL)

extern _Set1 _F_SET_NULL_1 (TYPE_1 x);
/* extern _Set2 _F_SET_NULL_2 (TYPE_2 x); */
extern _Set4 _F_SET_NULL_4 (TYPE_4 x);
extern _Set8 _F_SET_NULL_8 (TYPE_8 x);

extern _Set1 _F_SET_START_1 (_Set1 a);
/* extern _Set2 _F_SET_START_2 (_Set2 a); */
extern _Set4 _F_SET_START_4 (_Set4 a);
extern _Set8 _F_SET_START_8 (_Set8 a);

extern StandardTypes_Bool _F_SET_DESTRUCT_1 (_Set1 *a, _Set1 *i, TYPE_1 *x);
/* extern StandardTypes_Bool _F_SET_DESTRUCT_2 (_Sey2 *a, _Set2 *i, TYPE_2 *x); */
extern StandardTypes_Bool _F_SET_DESTRUCT_4 (_Set4 *a, _Set4 *i, TYPE_4 *x);
extern StandardTypes_Bool _F_SET_DESTRUCT_8 (_Set8 *a, _Set8 *i, TYPE_8 *x);

#endif /* _Prelude_C */

