/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef __FileStream
#include "FileStream.h"
#endif

bool FileStream_CreateInput (string name, FileStream_ReadFile *f)
{ 
  *f = fopen ((char*)name, "r");
  return(*f NEQ NULL);
} /* CreateInput */

bool FileStream_CreateOutput (string name, FileStream_WriteFile *f)
{ 
  *f = fopen ((char*)name, "w");
  return(*f NEQ NULL);
} /* CreateOutput */

bool FileStream_AppendOutput (string name, FileStream_WriteFile *f)
{ 
  *f = fopen ((char*)name, "a");
  return(*f NEQ NULL);
} /* AppendOutput */

void FileStream_CloseInput (FileStream_ReadFile f)
{ 
  fclose (f);
} /* CloseInput */

void FileStream_CloseOutput (FileStream_WriteFile f)
{ 
  fclose (f);
} /* CloseOutput */

int FileStream_Read (address ptr, int size, int nitems, FileStream_ReadFile f)
{ 
  return(fread (ptr, (size_t) size,(size_t) nitems, f));
} /* Read */

int FileStream_Write (address ptr, int size, int nitems, FileStream_WriteFile f)
{ 
  return(fwrite (ptr, (size_t) size, (size_t) nitems, f));
} /* Write */

bool FileStream_Eof (FileStream_ReadFile f)
{ 
  int ch ;
  ch = fgetc (f);
  if (ch EQ EOF) { return(TRUE); }
  ungetc ((Char)ch, f);
  return(FALSE);
} /* Eof */

void FileStream_InitGlobals (void) { }

/* END FileStream */


