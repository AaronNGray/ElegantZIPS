/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef __TimeDate
#define __TimeDate

#ifndef __SYSTEM
#include "SYSTEM.h"
#endif

typedef struct tm *TIME;

#define SIZE_TIME SIZE_pointer

extern time_t TimeDate_Clock (void);
/* Time in seconds since 1-1-1970, 00:00:00 GMT, local time used. */

extern TIME TimeDate_LocalTime (time_t clock);
/*  Conversion of the time as returned by Clock in a local TIME */

extern TIME TimeDate_GMT (time_t clock);
/*  Conversion of the time as returned by Clock in a TIME for GMT */

extern string TimeDate_TimeString (time_t clock);
/*  Conversion of the time according to the following format:-
          Sun Sep 16 01:03:52 1973\n\0
*/

extern string TimeDate_TIMEToString (TIME time);
/*  Conversion of the time according to the following format:-
          Sun Sep 16 01:03:52 1973\n\0
*/

extern void TimeDate_InitGlobals (void);
#endif /*  TimeDate. */

