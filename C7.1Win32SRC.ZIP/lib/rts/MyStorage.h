/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef __MyStorage
#define __MyStorage

#ifndef __SYSTEM
#include "SYSTEM.h"
#endif

#ifndef __Machines
#include "Machines.h"
#endif

#define MyStorage_BYTESPERWORD  (Machines_BITSPERWORD / 8)
#define MyStorage_ALIGNMENT  (2*MyStorage_BYTESPERWORD)

#define MyStorage_BlockSize (64 * 1024)

#define TRACK_LINES 0

/* units have to be identical to the units returned by sizeof.

   DEALLOCATE doesn't do anything
*/

extern address MyStorage_Bottom;  /* Bottom of heap */
extern address MyStorage_Top;     /* Top of heap    */


extern char *MyStorage_filename;
extern int   MyStorage_linenum;
extern bool  MyStorage_CollectIdent;
extern bool  MyStorage_CollectMemo;

/* Fast_ALLOCATE assumes alignment and units <= BlockSize */ 
/* Const_ALLOCATE assumes units to be a compile time constant */ 

#if TRACK_LINES
#define MyStorage_ALLOCATE(units) \
  ( MyStorage_filename = __FILE__, MyStorage_linenum = __LINE__, \
    MyStorage__ALLOCATE(units))
#define MyStorage_Fast_ALLOCATE(units) \
  ( MyStorage_filename = __FILE__, MyStorage_linenum = __LINE__, \
    MyStorage__Fast_ALLOCATE(units))
extern address MyStorage__ALLOCATE (cardinal units);
extern address MyStorage__Fast_ALLOCATE (cardinal units);
#else
#define MyStorage__ALLOCATE      MyStorage_ALLOCATE
#define MyStorage__Fast_ALLOCATE MyStorage_Fast_ALLOCATE
extern address MyStorage_ALLOCATE (cardinal units);
extern address MyStorage_Fast_ALLOCATE (cardinal units);
#endif

#define MyStorage_Const_ALLOCATE(units) \
( (units % MyStorage_ALIGNMENT == 0 && units <= MyStorage_BlockSize) ? \
    MyStorage_Fast_ALLOCATE(units) \
  : \
    MyStorage_ALLOCATE(units) \
)

extern void MyStorage_DEALLOCATE (address adr, cardinal units);

extern int MyStorage_HeapSize (void);

extern void MyStorage_InitGlobals(void);

extern void MyStorage_GC_Set_Heap   (void *p, cardinal size);
extern void MyStorage_GC_Set_Stack  (void *p);
extern void MyStorage_GC_Set_Global (void *p);
extern void MyStorage_GC_Set_Globals (void *p, void *q, bool memo_table);
extern address MyStorage_GC_Set_Memo (void *p);

extern void MyStorage_WantsGC (void);
extern void MyStorage_SetGCPrio (cardinal n);
extern void MyStorage_RunGC (void);

#endif /*  MyStorage */

