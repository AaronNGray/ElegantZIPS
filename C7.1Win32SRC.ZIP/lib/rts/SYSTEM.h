/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef __SYSTEM
#define __SYSTEM

#ifndef __ansi
#include "ansi.h"
#endif

typedef int bool;

#ifdef TRUE
#undef TRUE
#endif

#ifdef FALSE
#undef FALSE
#endif

#ifdef AND
#undef AND
#endif

#ifdef OR
#undef OR
#endif

#ifdef NOT
#undef NOT
#endif

#ifdef EQ
#undef EQ
#endif

#ifdef NEQ
#undef NEQ
#endif

#ifdef DIV
#undef DIV
#endif

#ifdef MOD
#undef MOD
#endif

#define TRUE  1
#define FALSE 0
#define AND   &&
#define OR    ||
#define NOT   !

#define EQ    ==
#define NEQ   !=

#define DIV   /
#define MOD   %

typedef unsigned char	Char;

typedef void*		address;
typedef unsigned int	cardinal;
typedef Char*           string; 

typedef unsigned bitset;

#ifdef empty_bitset
#undef empty_bitset
#endif

#ifdef BIT
#undef BIT
#endif

#ifdef Neg
#undef Neg
#endif

#ifdef EMPTY
#undef EMPTY
#endif

#ifdef IN
#undef IN
#endif

#ifdef INCL
#undef INCL
#endif

#ifdef EXCL
#undef EXCL
#endif

#ifdef SUBSET
#undef SUBSET
#endif

#ifdef UNION
#undef UNION
#endif

#ifdef DIFFERENCE
#undef DIFFERENCE
#endif

#ifdef INTERSECTION
#undef INTERSECTION
#endif

#ifdef SYMMETRICDIFFERENCE
#undef SYMMETRICDIFFERENCE
#endif

#define empty_bitset 0x0
#define BIT(e) (0x1 << (e))
#define Neg(s) (~s)

#define BitCode(c) ((bitset)(c))
#define EMPTY ((bitset)(0))
#define IN(e,s) ((bool)(((unsigned)(s) & BIT(e)) NEQ empty_bitset))
#define INCL(s,e) ((bitset)((unsigned)(s) | BIT(e)))
#define EXCL(s,e) ((bitset)((unsigned)(s) & Neg(BIT(e))))
#define SUBSET(s1,s2) ((bool)(((unsigned)(s2) | (unsigned)(s1)) EQ (unsigned)(s2)))
#define UNION(s1,s2) ((bitset)((unsigned)(s1) | (unsigned)(s2)))
#define DIFFERENCE(s1,s2) ((bitset)((unsigned)(s1) & Neg((unsigned)(s2))))
#define INTERSECTION(s1,s2) ((bitset)((unsigned)(s1) & (unsigned)(s2)))
#define SYMMETRICDIFFERENCE(s1,s2) (UNION(DIFFERENCE(s1,s2),DIFFERENCE(s2,s1)))


/* for use in CGN modules: */


typedef int       SYSTEM_int;
typedef bool      SYSTEM_bool;
typedef char      SYSTEM_char;
typedef Char      SYSTEM_Char;
typedef string    SYSTEM_string;
typedef address   SYSTEM_address;
typedef cardinal  SYSTEM_cardinal;
typedef bitset    SYSTEM_bitset;

#define SYSTEM_CARD(n) ((cardinal)(n))


#endif /*  SYSTEM */

