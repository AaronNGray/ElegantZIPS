/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef __SYSTEM
#include "SYSTEM.h"
#endif

#ifndef __FileStream
#include "FileStream.h"
#endif

#ifndef __Strings
#include "Strings.h"
#endif

#ifndef __TextIO
#include "TextIO.h"
#endif

#ifndef __SysStreams
#include "SysStreams.h"
#endif

#ifndef __FileStream
#include "FileStream.h"
#endif

#ifndef __Paths
#include "Paths.h"
#endif

FileStream_ReadFile Paths_CreateInput 
                          (string path, string name, string *dir, bool MustBeUnique, bool *Unique)
{ 

  char fn[Paths_FileNameLength] ;
  int low, high ;
  FileStream_ReadFile s, file ;
  int i, j, dirhigh ;
  bool found ;
  int pathlength, namelength ;

  pathlength = Strings_Length (path);
  namelength = Strings_Length (name);
  (*dir)[0] = '\0';
  low = 0;
  high = 0;
  found = FALSE;
  file = NULL;
  while (high < pathlength)
  { /* low EQ high */
    while ((high < pathlength) AND (path[high] NEQ ':'))
    { high++; }
    i = -1;
    /* skip leading spaces */
    while ((low < pathlength) AND TextIO_WhiteSpace (path[low])) { low++; }
    if ((low >= pathlength)) { return((FileStream_ReadFile)NULL); }
    /* copy path */
    while ((low < pathlength) AND (path[low] NEQ ':'))
    { i++;
      fn [i] = path[low];
      low++;
    }
    if (high < pathlength)
    { low++;
      high++;
    }
    /* low EQ high */
    /* remove trailing spaces */
    while ((i >= 0) AND TextIO_WhiteSpace (fn[i])) { i--; }
    /* single '.' is current directory */
    if ((i EQ 0) AND (fn[i] EQ '.')) { i--; }
    if ((i >= 0) AND (fn[i] NEQ '/'))
    { i++;
      fn[i] = '/';
    }
    /* directory determined */
    dirhigh = i;
    /* copy file name */
    for (j = 0; j <= namelength -1; j++)
    { i++;
      fn[i] = name[j];
    }
    fn[i+1] = '\0';
    if (FileStream_CreateInput ((string)fn, &s))
    { if (found AND MustBeUnique)
      { *Unique = FALSE;
        FileStream_CloseInput (s);
        return(file);
      }
      for (j = 0; j <= dirhigh; j++) { (*dir)[j] = fn[j]; }
      (*dir)[dirhigh+1] = '\0';
      file = s;
      found = TRUE;
      if (NOT MustBeUnique) { return(s); }
    }
  }
  if (found)
  { *Unique = TRUE;
    return(file);
  }
  return((FileStream_ReadFile)NULL);
} /* CreateInput */

void Paths_InitGlobals (void) { }

/* END Paths */

