/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/


#ifndef __SYSTEM
#include "SYSTEM.h"
#endif

#ifndef __MyStorage
#include "MyStorage.h"
#endif

#ifndef __StandardTypes
#include "StandardTypes.h"
#endif

#ifndef __LazyCodeModule
#include "LazyCodeModule.h"
#endif

void StandardTypes_Pack (string b, int start, StandardTypes_Repr s, int lo, int up)
{
  int i,j;
  i = start;
  for (j = lo; j <=up; j++)
  { s[j] = b[i];
    i++;
  }
} /* Pack */

#define CreateArray(n) \
CAT(StandardTypes_Array,n) CAT(Create_StandardTypes_Array_,n) (int size, CAT(TYPE_,n) element) \
{ CAT(StandardTypes_Array,n) array; \
  int i; \
  if (size < 0) { size = 0; } \
  array = MyStorage_ALLOCATE (sizeof(int) + (cardinal)size*sizeof(array->value[0])); \
  array->size = size; \
  for (i = 0 ; i < size ; i++) { array->value[i] = element; } \
  return (array); \
}

CreateArray(1)
CreateArray(2)
CreateArray(4)
CreateArray(8)


TYPE_0 Const_StandardTypes_Lazy0 (StandardTypes_Lazy0 x)
{ 
}

TYPE_1 Const_StandardTypes_Lazy1 (StandardTypes_Lazy1 x)
{ return (x->uval.value);
}

TYPE_2 Const_StandardTypes_Lazy2 (StandardTypes_Lazy2 x)
{ return (x->uval.value);
}

TYPE_4 Const_StandardTypes_Lazy4 (StandardTypes_Lazy4 x)
{ return (x->uval.value);
}

TYPE_8 Const_StandardTypes_Lazy8 (StandardTypes_Lazy8 x)
{ return (x->uval.value);
}

/*********************/

void StandardTypes_Init (void)
{
}

/* END StandardTypes */

