/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/


#ifndef __StandardTypes
#define __StandardTypes

#ifndef __SYSTEM
#include "SYSTEM.h"
#endif

#ifndef __SystemTypes
#include "SystemTypes.h"
#endif

/* CONST */
#define StandardTypes_MaxBuf (1024 * 128)

typedef bool StandardTypes_Bool;
#define SIZE_Bool SIZE_int

typedef int StandardTypes_Int;
#define SIZE_Int SIZE_int

typedef Char StandardTypes_Char;
#define SIZE_Char SIZE_char

typedef Char *StandardTypes_BufType; 

typedef Char *StandardTypes_Repr;

typedef string StandardTypes_String;
#define SIZE_String SIZE_pointer

typedef double StandardTypes_Float;
#define SIZE_Float SIZE_double

typedef struct StandardTypes_StructIdent      StandardTypes_RecIdent;
typedef struct StandardTypes_StructIdent      *StandardTypes_Ident;
#define SIZE_Ident SIZE_pointer

struct StandardTypes_StructIdent
        { StandardTypes_Ident	next;
          int			length;
          address		info;
          StandardTypes_Repr	represent;
        };

typedef union StandardTypes_UnionSimpleType     StandardTypes_SimpleType;

union  StandardTypes_UnionSimpleType 
          { StandardTypes_Int    IntVal;
            StandardTypes_Bool   BoolVal;
            StandardTypes_Char   CharVal;
            StandardTypes_String StringVal;
            StandardTypes_Ident  IdentVal;
            StandardTypes_Float  FloatVal;
          } ;

typedef bitset StandardTypes_Bitset;
#define SIZE_Bitset SIZE_int

extern void StandardTypes_Pack (string b, int start, StandardTypes_Repr s, int lo, int up);

typedef struct Struct_StandardTypes_List *StandardTypes_List;
typedef struct Struct_StandardTypes_List { struct Struct_StandardTypes_List *tail; void* head; } Rec_StandardTypes_List;

typedef struct Struct_StandardTypes_Tree *StandardTypes_Tree;
typedef struct Struct_StandardTypes_Tree { struct Struct_StandardTypes_Tree *left, *right; void* head; } Rec_StandardTypes_Tree;

/******** Generic types **/

typedef struct Struct_StandardTypes_Array1 *StandardTypes_Array1;
typedef struct Struct_StandardTypes_Array1 { int size; TYPE_1 value[1]; } 
               Rec_StandardTypes_Array1;

typedef struct Struct_StandardTypes_Array2 *StandardTypes_Array2;
typedef struct Struct_StandardTypes_Array2 { int size; TYPE_2 value[1]; } 
               Rec_StandardTypes_Array2;

typedef struct Struct_StandardTypes_Array4 *StandardTypes_Array4;
typedef struct Struct_StandardTypes_Array4 { int size; TYPE_4 value[1]; } 
               Rec_StandardTypes_Array4;

typedef struct Struct_StandardTypes_Array8 *StandardTypes_Array8;
typedef struct Struct_StandardTypes_Array8 { int size; TYPE_8 value[1]; } 
               Rec_StandardTypes_Array8;

extern StandardTypes_Array1 Create_StandardTypes_Array_1(int size, TYPE_1 element);
extern StandardTypes_Array2 Create_StandardTypes_Array_2(int size, TYPE_2 element);
extern StandardTypes_Array4 Create_StandardTypes_Array_4(int size, TYPE_4 element);
extern StandardTypes_Array8 Create_StandardTypes_Array_8(int size, TYPE_8 element);

#define SIZE_Array SIZE_pointer

/******** Lazy stuff *************/

    /******* size 0 ********/
    
typedef struct Struct_StandardTypes_Lazy0 *StandardTypes_Lazy0;
typedef void (*PROC_StandardTypes_Lazy0) (StandardTypes_Lazy0 l);
typedef struct Struct_StandardTypes_Lazy0 {
	address env;
	PROC_StandardTypes_Lazy0 eval;
} Rec_StandardTypes_Lazy0;

extern TYPE_0 Const_StandardTypes_Lazy0(StandardTypes_Lazy0 lazy); 

typedef struct Struct_StandardTypes_Closure0 *StandardTypes_Closure0;
typedef void (*PROC_StandardTypes_Closure0) (StandardTypes_Closure0 l);
typedef struct Struct_StandardTypes_Closure0 {
	address env;
	PROC_StandardTypes_Closure0 eval;
} Rec_StandardTypes_Closure0;


typedef struct Struct_StandardTypes_Incr0 *StandardTypes_Incr0;
typedef void (*PROC_StandardTypes_Incr0) (StandardTypes_Incr0 l);
typedef struct Struct_StandardTypes_Incr0 {
	address env;
	PROC_StandardTypes_Incr0 eval;
	StandardTypes_List callers;
	StandardTypes_Closure0 unval;
} Rec_StandardTypes_Incr0;

    /******* size 1 ********/
    
typedef struct Struct_StandardTypes_Lazy1 *StandardTypes_Lazy1;
typedef TYPE_1 (*PROC_StandardTypes_Lazy1) (StandardTypes_Lazy1 l);
typedef struct Struct_StandardTypes_Lazy1 {
	union { 
		TYPE_1 value;
		address env;
	} uval;
	PROC_StandardTypes_Lazy1 eval;
} Rec_StandardTypes_Lazy1;

extern TYPE_1 Const_StandardTypes_Lazy1(StandardTypes_Lazy1 lazy); 

typedef struct Struct_StandardTypes_Closure1 *StandardTypes_Closure1;
typedef TYPE_1 (*PROC_StandardTypes_Closure1) (StandardTypes_Closure1 l);
typedef struct Struct_StandardTypes_Closure1 {
	address env;
	PROC_StandardTypes_Closure1 eval;
} Rec_StandardTypes_Closure1;

typedef struct Struct_StandardTypes_Incr1 *StandardTypes_Incr1;
typedef TYPE_1 (*PROC_StandardTypes_Incr1) (StandardTypes_Incr1 l);
typedef struct Struct_StandardTypes_Incr1 {
	address env;
	PROC_StandardTypes_Incr1 eval;
	StandardTypes_List callers;
	StandardTypes_Closure0 unval;
	TYPE_1 value;
} Rec_StandardTypes_Incr1;

typedef struct Struct_StandardTypes_Vincr1 *StandardTypes_Vincr1;
typedef TYPE_1 (*PROC_StandardTypes_Vincr1) (StandardTypes_Vincr1 l);
typedef struct Struct_StandardTypes_Vincr1 {
	address env;
	PROC_StandardTypes_Vincr1 eval;
	StandardTypes_List callers;
	StandardTypes_Closure0 unval;
	TYPE_1 value;
} Rec_StandardTypes_Vincr1;

    /******* size 2 ********/
    
typedef struct Struct_StandardTypes_Lazy2 *StandardTypes_Lazy2;
typedef TYPE_2 (*PROC_StandardTypes_Lazy2) (StandardTypes_Lazy2 l);
typedef struct Struct_StandardTypes_Lazy2 {
	union { 
		TYPE_2 value;
		address env;
	} uval;
	PROC_StandardTypes_Lazy2 eval;
} Rec_StandardTypes_Lazy2;

extern TYPE_2 Const_StandardTypes_Lazy2(StandardTypes_Lazy2 lazy); 

typedef struct Struct_StandardTypes_Closure2 *StandardTypes_Closure2;
typedef TYPE_2 (*PROC_StandardTypes_Closure2) (StandardTypes_Closure2 l);
typedef struct Struct_StandardTypes_Closure2 {
	address env;
	PROC_StandardTypes_Closure2 eval;
} Rec_StandardTypes_Closure2;

typedef struct Struct_StandardTypes_Incr2 *StandardTypes_Incr2;
typedef TYPE_2 (*PROC_StandardTypes_Incr2) (StandardTypes_Incr2 l);
typedef struct Struct_StandardTypes_Incr2 {
	address env;
	PROC_StandardTypes_Incr2 eval;
	StandardTypes_List callers;
	StandardTypes_Closure0 unval;
	TYPE_2 value;
} Rec_StandardTypes_Incr2;

typedef struct Struct_StandardTypes_Vincr2 *StandardTypes_Vincr2;
typedef TYPE_2 (*PROC_StandardTypes_Vincr2) (StandardTypes_Vincr2 l);
typedef struct Struct_StandardTypes_Vincr2 {
	address env;
	PROC_StandardTypes_Vincr2 eval;
	StandardTypes_List callers;
	StandardTypes_Closure0 unval;
	TYPE_2 value;
} Rec_StandardTypes_Vincr2;

    /******* size 4 ********/
    
typedef struct Struct_StandardTypes_Lazy4 *StandardTypes_Lazy4;
typedef TYPE_4 (*PROC_StandardTypes_Lazy4) (StandardTypes_Lazy4 l);
typedef struct Struct_StandardTypes_Lazy4 {
	union { 
		TYPE_4 value;
		address env;
	} uval;
	PROC_StandardTypes_Lazy4 eval;
} Rec_StandardTypes_Lazy4;

extern TYPE_4 Const_StandardTypes_Lazy4(StandardTypes_Lazy4 lazy); 

typedef struct Struct_StandardTypes_Closure4 *StandardTypes_Closure4;
typedef TYPE_4 (*PROC_StandardTypes_Closure4) (StandardTypes_Closure4 l);
typedef struct Struct_StandardTypes_Closure4 {
	address env;
	PROC_StandardTypes_Closure4 eval;
} Rec_StandardTypes_Closure4;

typedef struct Struct_StandardTypes_Incr4 *StandardTypes_Incr4;
typedef TYPE_4 (*PROC_StandardTypes_Incr4) (StandardTypes_Incr4 l);
typedef struct Struct_StandardTypes_Incr4 {
	address env;
	PROC_StandardTypes_Incr4 eval;
	StandardTypes_List callers;
	StandardTypes_Closure0 unval;
	TYPE_4 value;
} Rec_StandardTypes_Incr4;

typedef struct Struct_StandardTypes_Vincr4 *StandardTypes_Vincr4;
typedef TYPE_4 (*PROC_StandardTypes_Vincr4) (StandardTypes_Vincr4 l);
typedef struct Struct_StandardTypes_Vincr4 {
	address env;
	PROC_StandardTypes_Vincr4 eval;
	StandardTypes_List callers;
	StandardTypes_Closure0 unval;
	TYPE_4 value;
} Rec_StandardTypes_Vincr4;

    /******* size 8 ********/
    
typedef struct Struct_StandardTypes_Lazy8 *StandardTypes_Lazy8;
typedef TYPE_8 (*PROC_StandardTypes_Lazy8) (StandardTypes_Lazy8 l);
typedef struct Struct_StandardTypes_Lazy8 {
	union { 
		TYPE_8 value;
		address env;
	} uval;
	PROC_StandardTypes_Lazy8 eval;
} Rec_StandardTypes_Lazy8;

extern TYPE_8 Const_StandardTypes_Lazy8(StandardTypes_Lazy8 lazy); 

typedef struct Struct_StandardTypes_Closure8 *StandardTypes_Closure8;
typedef TYPE_8 (*PROC_StandardTypes_Closure8) (StandardTypes_Closure8 l);
typedef struct Struct_StandardTypes_Closure8 {
	address env;
	PROC_StandardTypes_Closure8 eval;
} Rec_StandardTypes_Closure8;

typedef struct Struct_StandardTypes_Incr8 *StandardTypes_Incr8;
typedef TYPE_8 (*PROC_StandardTypes_Incr8) (StandardTypes_Incr8 l);
typedef struct Struct_StandardTypes_Incr8 {
	address env;
	PROC_StandardTypes_Incr8 eval;
	StandardTypes_List callers;
	StandardTypes_Closure0 unval;
	TYPE_8 value;
} Rec_StandardTypes_Incr8;

typedef struct Struct_StandardTypes_Vincr8 *StandardTypes_Vincr8;
typedef TYPE_8 (*PROC_StandardTypes_Vincr8) (StandardTypes_Vincr8 l);
typedef struct Struct_StandardTypes_Vincr8 {
	address env;
	PROC_StandardTypes_Vincr8 eval;
	StandardTypes_List callers;
	StandardTypes_Closure0 unval;
	TYPE_8 value;
} Rec_StandardTypes_Vincr8;

#define SIZE_Lazy SIZE_pointer
#define SIZE_Closure SIZE_pointer
#define SIZE_Incr SIZE_pointer
#define SIZE_Vincr SIZE_pointer

typedef struct LazyCodeModule_StructLAZYFUNC	
			LazyCodeModule_RecLAZYFUNCTION;
typedef struct LazyCodeModule_StructLAZYFUNC
			*LazyCodeModule_LAZYFUNCTION;

struct LazyCodeModule_StructLAZYFUNC
	{ address	env;
	  address	eval;
	};
	
extern void StandardTypes_Init (void);

#endif /*  StandardTypes */
