/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/


#ifndef __LazyCodeModule
#define __LazyCodeModule

#ifndef __StandardTypes
#include "StandardTypes.h"
#endif

extern StandardTypes_Closure0 LazyCodeModule_Create (address env, PROC_StandardTypes_Closure0 eval);

extern StandardTypes_Closure0 LazyCodeModule_CreateString (StandardTypes_String val);

extern StandardTypes_Closure0 LazyCodeModule_CreateInt (StandardTypes_Int val);

extern StandardTypes_Closure0 LazyCodeModule_CreateBool (StandardTypes_Bool val);

extern StandardTypes_Closure0 LazyCodeModule_CreateChar (StandardTypes_Char val);

extern StandardTypes_Closure0 LazyCodeModule_CreateIdent (StandardTypes_Ident val);

extern StandardTypes_Closure0 LazyCodeModule_Concat (StandardTypes_Closure0 c1, StandardTypes_Closure0 c2);

#define EVALLAZY(x) (*((x)->eval))(x)

extern TYPE_0 Closure_Eval_0 (StandardTypes_Closure0 x);
extern TYPE_1 Closure_Eval_1 (StandardTypes_Closure1 x);
extern TYPE_2 Closure_Eval_2 (StandardTypes_Closure2 x);
extern TYPE_4 Closure_Eval_4 (StandardTypes_Closure4 x);
extern TYPE_8 Closure_Eval_8 (StandardTypes_Closure8 x);

extern TYPE_0 Lazy_Eval_0 (StandardTypes_Lazy0 x);
extern TYPE_1 Lazy_Eval_1 (StandardTypes_Lazy1 x);
extern TYPE_2 Lazy_Eval_2 (StandardTypes_Lazy2 x);
extern TYPE_4 Lazy_Eval_4 (StandardTypes_Lazy4 x);
extern TYPE_8 Lazy_Eval_8 (StandardTypes_Lazy8 x);

extern TYPE_0 Incr_Eval_0 (StandardTypes_Incr0 x);
extern TYPE_1 Incr_Eval_1 (StandardTypes_Incr1 x);
extern TYPE_2 Incr_Eval_2 (StandardTypes_Incr2 x);
extern TYPE_4 Incr_Eval_4 (StandardTypes_Incr4 x);
extern TYPE_8 Incr_Eval_8 (StandardTypes_Incr8 x);

extern TYPE_1 Vincr_Eval_1 (StandardTypes_Vincr1 x);
extern TYPE_2 Vincr_Eval_2 (StandardTypes_Vincr2 x);
extern TYPE_4 Vincr_Eval_4 (StandardTypes_Vincr4 x);
extern TYPE_8 Vincr_Eval_8 (StandardTypes_Vincr8 x);

extern void LazyCodeModule_Eval     (StandardTypes_Closure0 code);
extern void LazyCodeModule_EvalLazy (StandardTypes_Lazy0 code);
extern void LazyCodeModule_EvalIncr (StandardTypes_Incr0 code);

extern void LazyCodeModule_Nothing (StandardTypes_Lazy0 val);

extern LazyCodeModule_LAZYFUNCTION LazyCodeModule_CreateFunction (address env, address eval);

extern address LazyCodeModule_CreateEnv (cardinal n, ...);

/*************** Incremental stuff ****************/

extern StandardTypes_Incr0 LazyCodeModule_Current;

extern void LazyCodeModule_IUnval_0 (StandardTypes_Incr0 x);
extern void LazyCodeModule_IUnval_1 (StandardTypes_Incr1 x);
extern void LazyCodeModule_IUnval_2 (StandardTypes_Incr2 x);
extern void LazyCodeModule_IUnval_4 (StandardTypes_Incr4 x);
extern void LazyCodeModule_IUnval_8 (StandardTypes_Incr8 x);

extern void LazyCodeModule_Unval_1 (StandardTypes_Vincr1 x);
extern void LazyCodeModule_Unval_2 (StandardTypes_Vincr2 x);
extern void LazyCodeModule_Unval_4 (StandardTypes_Vincr4 x);
extern void LazyCodeModule_Unval_8 (StandardTypes_Vincr8 x);

extern StandardTypes_Vincr1 Create_StandardTypes_Vincr1 (TYPE_1 y);
extern StandardTypes_Vincr2 Create_StandardTypes_Vincr2 (TYPE_2 y);
extern StandardTypes_Vincr4 Create_StandardTypes_Vincr4 (TYPE_4 y);
extern StandardTypes_Vincr8 Create_StandardTypes_Vincr8 (TYPE_8 y);

extern void LazyCodeModule_Assign_1 (StandardTypes_Vincr1 x, TYPE_1 y);
extern void LazyCodeModule_Assign_2 (StandardTypes_Vincr2 x, TYPE_2 y);
extern void LazyCodeModule_Assign_4 (StandardTypes_Vincr4 x, TYPE_4 y);
extern void LazyCodeModule_Assign_8 (StandardTypes_Vincr8 x, TYPE_8 y);

extern void LazyCodeModule_Caller (StandardTypes_Incr0 x);

extern StandardTypes_Incr0 LazyCodeModule_CreateIncr (address env, PROC_StandardTypes_Incr0 eval);

extern TYPE_1 EvalStandardTypes_Vincr1 (StandardTypes_Vincr1 x);
extern TYPE_2 EvalStandardTypes_Vincr2 (StandardTypes_Vincr2 x);
extern TYPE_4 EvalStandardTypes_Vincr4 (StandardTypes_Vincr4 x);
extern TYPE_8 EvalStandardTypes_Vincr8 (StandardTypes_Vincr8 x);

extern TYPE_1 LazyCodeModule_NewVal_1 (StandardTypes_Vincr1 x);
extern TYPE_2 LazyCodeModule_NewVal_2 (StandardTypes_Vincr2 x);
extern TYPE_4 LazyCodeModule_NewVal_4 (StandardTypes_Vincr4 x);
extern TYPE_8 LazyCodeModule_NewVal_8 (StandardTypes_Vincr8 x);

/*********** Undo/redo *********/

typedef int LazyCodeModule_UndoTime;

typedef struct LazyCodeModule_UndoRec
                { struct LazyCodeModule_UndoRec *next;
                  LazyCodeModule_UndoTime time;
                  int  size;
                  union { struct { StandardTypes_Vincr1 vincr; TYPE_1 value; } uval1;
                          struct { StandardTypes_Vincr2 vincr; TYPE_2 value; } uval2;
                          struct { StandardTypes_Vincr4 vincr; TYPE_4 value; } uval4;
                          struct { StandardTypes_Vincr8 vincr; TYPE_8 value; } uval8;
                        } uval;
                } *LazyCodeModule_UndoRec;

extern LazyCodeModule_UndoRec LazyCodeModule_undo;
extern LazyCodeModule_UndoRec LazyCodeModule_redo;

extern LazyCodeModule_UndoTime LazyCodeModule_new_time (void);
extern LazyCodeModule_UndoTime LazyCodeModule_get_time (void);
extern void LazyCodeModule_SetUndo (StandardTypes_Bool u);
extern void LazyCodeModule_Undo (LazyCodeModule_UndoTime time);
extern void LazyCodeModule_Redo (LazyCodeModule_UndoTime time);
extern void LazyCodeModule_UndoStep (void);
extern void LazyCodeModule_RedoStep (void);

/*************** Lazy constants ****************/

extern CAT(StandardTypes_Lazy,SIZE_String)	LazyCodeModule_LazyEmptyString;
extern CAT(StandardTypes_Lazy,SIZE_pointer)	LazyCodeModule_LazyNIL;
extern CAT(StandardTypes_Lazy,SIZE_Bool)	LazyCodeModule_LazyFALSE;
extern CAT(StandardTypes_Lazy,SIZE_Bool)	LazyCodeModule_LazyTRUE;
extern CAT(StandardTypes_Lazy,SIZE_Int)		LazyCodeModule_LazyZero;
extern CAT(StandardTypes_Lazy,SIZE_Int)		LazyCodeModule_LazyOne;
extern CAT(StandardTypes_Closure,SIZE_void)	LazyCodeModule_LazySkip;

extern void LazyCodeModule_Init(void);

#endif /*   LazyCodeModule */
