/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef __Scan_RTS
#define __Scan_RTS

static void Scanner_symbolname(string name)
{ 
  cardinal i;
  i = 0;
  while (name[i] NEQ '\0')
  { TextIO_WriteCHAR(SysStreams_sysErr, name[i]);
    i++;
  }
} /* symbolname */

static void Scanner_encountered(void)
{ 
  if (ScanIO_maxerrors >= 0 && ScanIO_totalerrors > ScanIO_maxerrors)
  { return; }
  TextIO_WriteString(SysStreams_sysErr, (string)", ");
  Scanner_symbolname(Symbols_TerminalNames[Scanner_sym]);
  TextIO_WriteString(SysStreams_sysErr, (string)" encountered");
} /* encountered */

void Scanner_insertion(string inserttxt, bool suppress)
{
  ScanIO_OpenError(ScanIO_CharCount-ScanIO_symbollength+1, FALSE);
  if (ScanIO_maxerrors >= 0 && ScanIO_totalerrors > ScanIO_maxerrors)
  { return; }
  Scanner_symbolname(inserttxt);
  TextIO_WriteString(SysStreams_sysErr, (string)" expected");
  Scanner_encountered();
  ScanIO_FlushError();
  if (suppress AND NOT ScanIO_deleting)
  { ScanIO_SuppressContextChecks = TRUE; };
} /* insertion */

void Scanner_deletion(void)
{ 
  if (Scanner_sym NEQ Symbols_nonsense)
  { ScanIO_OpenError(ScanIO_CharCount-ScanIO_symbollength+1, FALSE);
    if (ScanIO_maxerrors >= 0 && ScanIO_totalerrors > ScanIO_maxerrors)
    {}
    else
    { TextIO_WriteString(SysStreams_sysErr, (string)"unexpected symbol");
      Scanner_encountered();
      ScanIO_FlushError();
    }
  }
  else if (Scanner_par < 0)
  { switch (-Scanner_par)
    { case 1: ScanIO_error(ScanIO_CharCount-ScanIO_symbollength+1,
                           (string)" illegal symbol deleted ", (string)"");
              break;
      case 3: ScanIO_error(ScanIO_CharCount-ScanIO_symbollength+1,
                           (string)" illegal constant deleted ", (string)"");
              break;
    }
    Scanner_par = 0;
  }
} /* deletion */

#ifdef ENCODE_Int

static void Scanner_EncodeInt(Symbols_Terminals Symbols_s)
{ 
  int  i;
  Char c;
  bool ok;
  int  maxok, maxdigit, digit;
  int  max;
  Scanner_sym = Symbols_s;
  Scanner_par = 0;
  maxok = MAXINT DIV 10;
  maxdigit = MAXINT MOD 10;
  ScanIO_ScanAttribute.IntVal = 0;  ok = TRUE;
  max = ScanIO_tokenptr;
  for (i = ScanIO_startptr+1; i <= max; i++)
  { c = ScanIO_buffer[i];
    digit = (int)c - (int)'0';
    ok = ok AND (0 <= digit) AND (digit <= 9) AND
         ( (ScanIO_ScanAttribute.IntVal < maxok) OR 
           ( (ScanIO_ScanAttribute.IntVal EQ maxok) AND
             (digit <= maxdigit)
         ) );
    if (ok)
    { ScanIO_ScanAttribute.IntVal = ScanIO_ScanAttribute.IntVal*10+digit; }
  }
  if (NOT ok)
  { Scanner_sym = Symbols_nonsense;
    Scanner_par = -3;  /* illegal constant, see deletion */
    ScanIO_error(ScanIO_CharCount-ScanIO_symbollength+1,
                 (string)" illegal integer representation ", (string)"");
  }
} /* EncodeInt */

#endif

#ifdef ENCODE_Bool

static int Scanner_min(int x, int y)
{
  if (x > y) 
  { return (y); }
  else
  { return (x); }
} /* min */

static void Scanner_EncodeBool(Symbols_Terminals Symbols_s)
{
  int i;
  char spelling[5];
  if (ScanIO_symbollength > 5)
  { Scanner_sym = Symbols_nonsense;
    Scanner_par = -3;  /* illegal constant, see deletion */
    ScanIO_error(ScanIO_CharCount-ScanIO_symbollength+1,
                 (string)" illegal boolean representation ", (string)"");
    return;
  }
  Scanner_sym = Symbols_s;
  Scanner_par = 0;
  strcpy(spelling,"     ");
  for (i = ScanIO_startptr+1; i <= Scanner_min(5,ScanIO_symbollength); i++)
  { spelling[i] = ScanIO_buffer[i]; }
  if (SystemTypes_EQ EQ Strings_Compare((string)spelling,(string)"TRUE "))
  { ScanIO_ScanAttribute.BoolVal = TRUE; }
  else if (SystemTypes_EQ EQ Strings_Compare((string)spelling,(string)"FALSE"))
  { ScanIO_ScanAttribute.BoolVal = FALSE; }
  else
  { Scanner_sym = Symbols_nonsense;
    Scanner_par = -3;  /* illegal constant, see deletion */
    ScanIO_error(ScanIO_CharCount-ScanIO_symbollength+1,
                 (string)" illegal boolean representation ", (string)"");
  }
} /* EncodeBool */

#endif

#ifdef ENCODE_Char

static void Scanner_EncodeChar(Symbols_Terminals Symbols_s)
{
  Scanner_sym = Symbols_s;
  Scanner_par = 0;
  if (ScanIO_symbollength EQ 1)
  { ScanIO_ScanAttribute.CharVal = ScanIO_buffer[ScanIO_startptr+1]; }
  else if (ScanIO_symbollength <= 3)
  { ScanIO_ScanAttribute.CharVal = ScanIO_buffer[ScanIO_startptr+2]; }
  else
  { Scanner_sym = Symbols_nonsense;
    Scanner_par = -3;  /* illegal constant, see deletion */
    ScanIO_error(ScanIO_CharCount-ScanIO_symbollength+1,
                 (string)" illegal character representation ", (string)"");
  }
} /* EncodeChar */

#endif

#ifdef ENCODE_Float

static void Scanner_EncodeFloat(Symbols_Terminals Symbols_s)
{
  StandardTypes_Float real, factor, frac ;
  bool negative, fractionalpart, exp_negative ;
  Char ch ;
  int exponent ;
  int i;
  Scanner_sym = Symbols_s;
  Scanner_par = 0;
  real =  0.0; fractionalpart = FALSE; exponent = 0.0;
  negative = FALSE; exp_negative = FALSE;
  i = 1;
  if (ScanIO_buffer[ScanIO_startptr+i] == '-') { negative = TRUE; i++; }
  while (i <= ScanIO_symbollength)
  { ch = ScanIO_buffer[ScanIO_startptr+i];
    if ((ch >= '0') AND (ch <= '9')) 
    { real = real * 10.0 + (StandardTypes_Float) ((cardinal)ch - (cardinal)'0'); i++; }
    else if (ch EQ '.') 
    { fractionalpart = TRUE; i++; break; }
    else { break; }
  }
  if (fractionalpart) 
  { factor = 1.0; frac = 0.0;
    while (i <= ScanIO_symbollength)
    { ch = ScanIO_buffer[ScanIO_startptr+i];
      if (('0' <= ch) AND (ch <= '9'))
      { factor = factor / 10.0;
        frac = frac + factor * (StandardTypes_Float)((cardinal)ch - (cardinal)'0'); 
        i++;
      }
      else 
      { break; }
    }
    real = real + frac;
  }
  ch = ScanIO_buffer[ScanIO_startptr+i];
  if ((ch EQ 'E') OR (ch EQ 'e'))
  { i++;
    if (ScanIO_buffer[ScanIO_startptr+i] == '-') { exp_negative = TRUE; i++; }
    else if (ScanIO_buffer[ScanIO_startptr+i] == '+') { i++; }
    while (i <= ScanIO_symbollength)
    { ch = ScanIO_buffer[ScanIO_startptr+i];
      if ((ch >= '0') AND (ch <= '9')) 
      { exponent = exponent * 10.0 + (StandardTypes_Float) ((cardinal)ch - (cardinal)'0'); i++; }
      else { break; }
    }
    if (exp_negative) { exponent = -exponent; }
    while (exponent > 0) {  real = real * 10.0; exponent--; }
    while (exponent < 0) {  real = real / 10.0; exponent++; }
  }
  else 
  if (negative) { real = -real; }
  { ScanIO_ScanAttribute.FloatVal = real; }
} /* EncodeFloat */

#endif


#endif /*  Scan_RTS */
