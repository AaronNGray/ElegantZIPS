/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/


#ifndef __ScanIO
#define __ScanIO

#ifndef __SYSTEM
#include "SYSTEM.h"
#endif

#ifndef __FileStream
#include "FileStream.h"
#endif

#ifndef __StandardTypes
#include "StandardTypes.h"
#endif

typedef struct ScanIO_StructInput	*ScanIO_InputFiles;

typedef struct Struct_ScanIO_FileLocation* ScanIO_FileLocation; 
typedef struct Struct_ScanIO_FileLocation {
		StandardTypes_Int line;
		StandardTypes_Int pos;
		StandardTypes_Ident file;
} Rec_ScanIO_FileLocation;

extern ScanIO_FileLocation Create_ScanIO_FileLocation(StandardTypes_Int line,StandardTypes_Int pos,StandardTypes_Ident file);

struct ScanIO_StructInput
        { StandardTypes_Ident	name;
	  int			firstchar; /* char nr of first char, -1 is unknown */
	  StandardTypes_String	str;       /* for parsing from string */
	  StandardTypes_Int	strlen;    /* for parsing from string */
          ScanIO_InputFiles	next;
        };

extern ScanIO_InputFiles ScanIO_inputs, 
                         ScanIO_firstinput, 
                         ScanIO_lastinput; 

extern bool ScanIO_inputerrors;

#define ScanIO_MSBChar 0x80
#define ScanIO_HSBChar 0xfe
#define ScanIO_EOFChar 0xff

extern int  ScanIO_tokenptr,                 /* tokenend in buffer          */
            ScanIO_rememberptr,              /* possible tokenend in buffer */
            ScanIO_startptr ;                /* token start in buffer       */
extern bool ScanIO_skipbool,
            ScanIO_resetbool;
extern int  ScanIO_symbollength,
            ScanIO_totalerrors,
            ScanIO_totalwarnings,
            ScanIO_maxerrors ;
extern bool ScanIO_noerrors ;
extern bool ScanIO_SuppressContextChecks ;
extern bool ScanIO_SuppressWarnings ;
extern bool ScanIO_deleting ;

/* extern BufType ScanIO_buffer; IMPOSSIBLE IN C; SO: */
extern Char ScanIO_buffer[StandardTypes_MaxBuf];    /* Token buffer for scanner */

extern FileStream_ReadFile ScanIO_scanin;       /* Current input file       */
extern StandardTypes_String ScanIO_scanstring;  /* Current input string     */

extern int ScanIO_CharCount;

extern int test_find;

/* Terminal attributes */

extern StandardTypes_SimpleType ScanIO_ScanAttribute;
extern StandardTypes_SimpleType *ScanIO_RefAttribute;
                                /* & ScanIO_ScanAttribute */
                                
#define ScanIO_IntAttribute ScanIO_RefAttribute->IntVal
#define ScanIO_FloatAttribute ScanIO_RefAttribute->FloatVal
#define ScanIO_BoolAttribute ScanIO_RefAttribute->BoolVal
#define ScanIO_CharAttribute ScanIO_RefAttribute->CharVal
#define ScanIO_StringAttribute ScanIO_RefAttribute->StringVal
#define ScanIO_IdentAttribute ScanIO_RefAttribute->IdentVal

extern void ScanIO_ResetBuf(void);

extern void ScanIO_reset (FileStream_ReadFile *s, char *fn);

extern void ScanIO_rewrite (FileStream_WriteFile *s, char *fn);

extern void ScanIO_writelnlist(void);

extern void ScanIO_StoreLineDir (int rel, StandardTypes_Ident f);
extern void ScanIO_LinePragma (string s, int l);

/* Error handling routines */

extern StandardTypes_Ident ScanIO_FindFileName (int ch);

extern void ScanIO_FindLocation (int ch, int *line, int *pos, StandardTypes_Ident *file);
/* Given an absolute char number 'ch', this function assigns
   the relative line and position numbers and the filename to its
   var parameters .
*/

extern ScanIO_FileLocation ScanIO_XFindLocation (int ch);
/* Given an absolute char number 'ch', this function assigns
   the relative line and position numbers and the filename to its
   result .
*/

extern void ScanIO_error (int ch, string errortext, string terminal);

extern void ScanIO_FlushError(void);

extern void ScanIO_OpenError (int ch, bool warning);

extern void ScanIO_fatalerror (string text);

/* Input file manipulation */

extern void ScanIO_AddInputFile (StandardTypes_Ident id);
extern void ScanIO_AddInputString (StandardTypes_String s, StandardTypes_Int strlen, StandardTypes_Ident name);

extern void ScanIO_OpenInputs(void);

extern void ScanIO_OpenFreshInput (StandardTypes_Ident id);

extern void ScanIO_ReInit(void);

extern void ScanIO_finalize(void);

extern void ScanIO_InitGlobals(void);

#endif /*   ScanIO */

