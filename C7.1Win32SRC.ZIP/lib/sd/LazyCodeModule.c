/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef __SYSTEM
#include "SYSTEM.h"
#endif

#ifndef __StandardTypes
#include "StandardTypes.h"
#endif

#ifndef __MyStorage
#include "MyStorage.h"
#endif

#ifndef __SingleOutput
#include "SingleOutput.h"
#endif

#ifndef __SystemTypes
#include "SystemTypes.h"
#endif

#ifndef __LazyCodeModule
#include "LazyCodeModule.h"
#endif

typedef struct LazyCodeModule_StructConcatEnv	
			LazyCodeModule_RecConcatEnv;
typedef struct LazyCodeModule_StructConcatEnv	
			*LazyCodeModule_ConcatEnv;

struct LazyCodeModule_StructConcatEnv
	{ StandardTypes_Closure0 c1, c2;
	};

void LazyCodeModule_Eval (StandardTypes_Closure0 code)
{
  (*code->eval) (code);
} /* Eval */

void LazyCodeModule_Nothing (StandardTypes_Lazy0 val)
{
} /* LazyCodeModule_Nothing */

void LazyCodeModule_EvalLazy (StandardTypes_Lazy0 code)
{
  (*code->eval) (code);
  code->eval = LazyCodeModule_Nothing;
} /* EvalLazy */

void LazyCodeModule_EvalIncr (StandardTypes_Incr0 code)
{
  (*code->eval) (code);
} /* EvalLazy */

static void LazyCodeModule_EvalInt (StandardTypes_Closure0 val)
{
  SingleOutput_FromInt ((StandardTypes_Int) (val->env));
} /* EvalInt */

static void LazyCodeModule_EvalBool (StandardTypes_Closure0 val)
{
  SingleOutput_FromBool ((StandardTypes_Bool) (val->env));
} /* EvalBool */

static void LazyCodeModule_EvalChar (StandardTypes_Closure0 val)
{
  SingleOutput_FromChar ((Char)(int) (val->env));
} /* EvalChar */

static void LazyCodeModule_EvalString (StandardTypes_Closure0 val)
{ 
  SingleOutput_FromString ((string) (val->env));
} /* EvalString */

static void LazyCodeModule_EvalIdent (StandardTypes_Closure0 val)
{
  SingleOutput_FromIdent ((StandardTypes_Ident) (val->env));
} /* EvalIdent */


static void LazyCodeModule_EvalConcat (StandardTypes_Closure0 val)
{
LazyCodeModule_ConcatEnv env = (LazyCodeModule_ConcatEnv)(val->env);
  (*env->c1->eval)(env->c1);
  (*env->c2->eval)(env->c2);
} /* EvalConcat */

StandardTypes_Closure0 LazyCodeModule_Create (address env, PROC_StandardTypes_Closure0 eval)
{ StandardTypes_Closure0 code;

  code = MyStorage_Const_ALLOCATE (sizeof(Rec_StandardTypes_Closure0));
  code->env = env;
  code->eval = eval;
  return (code);
} /* Create */

StandardTypes_Closure0 LazyCodeModule_CreateInt (StandardTypes_Int val) 
{
  return (LazyCodeModule_Create ((address)val, LazyCodeModule_EvalInt));
} /* CreateInt */

StandardTypes_Closure0 LazyCodeModule_CreateBool (StandardTypes_Bool val) 
{
  return (LazyCodeModule_Create ((address)val, LazyCodeModule_EvalBool));
} /* CreateBool */

StandardTypes_Closure0 LazyCodeModule_CreateChar (StandardTypes_Char val) 
{
  return (LazyCodeModule_Create ((address)(int)val, LazyCodeModule_EvalChar));
} /* CreateChar */

StandardTypes_Closure0 LazyCodeModule_CreateString (StandardTypes_String val) 
{
  return (LazyCodeModule_Create ((address)val, LazyCodeModule_EvalString));
} /* CreateString */

StandardTypes_Closure0 LazyCodeModule_CreateIdent (StandardTypes_Ident val) 
{
  return (LazyCodeModule_Create ((address)val, LazyCodeModule_EvalIdent));
} /* CreateIdent */

StandardTypes_Closure0 LazyCodeModule_Concat (StandardTypes_Closure0 c1, StandardTypes_Closure0 c2)
{ LazyCodeModule_ConcatEnv env;
  env = MyStorage_Const_ALLOCATE (sizeof(LazyCodeModule_RecConcatEnv));
  env->c1 = c1;
  env->c2 = c2;
  return (LazyCodeModule_Create (env, (PROC_StandardTypes_Closure0)LazyCodeModule_EvalConcat));
} /* Concat */

LazyCodeModule_LAZYFUNCTION LazyCodeModule_CreateFunction (address env, address eval)
{ LazyCodeModule_LAZYFUNCTION f;
  f = MyStorage_Const_ALLOCATE (sizeof(LazyCodeModule_RecLAZYFUNCTION));
  f->env = env;
  f->eval = eval;
  return (f);
} /*  CreateFunction */

address LazyCodeModule_CreateEnv (cardinal n, ...)
{
  cardinal i = 0;
  va_list ap;
  LazyCodeModule_LAZYFUNCTION *p = MyStorage_Const_ALLOCATE (n*sizeof(LazyCodeModule_LAZYFUNCTION));
  va_start (ap, n);
  for (i=0 ; i<n ; i++)
  { p[i] = va_arg (ap, LazyCodeModule_LAZYFUNCTION);
  }
  va_end (ap);
  return ((address)p);
}

/*************** Evaluation functions ****************/

#define T_EVAL0(T) \
TYPE_0 CAT(CAT(T,_Eval_),0) (CAT(CAT(StandardTypes_,T),0) x) \
{ (*(x->eval))(x); \
}

#define T_EVAL(T,n) \
CAT(TYPE_,n) CAT(CAT(T,_Eval_),n) (CAT(CAT(StandardTypes_,T),n) x) \
{ return (*(x->eval))(x); \
}

T_EVAL0(Closure)
T_EVAL(Closure,1)
T_EVAL(Closure,2)
T_EVAL(Closure,4)
T_EVAL(Closure,8)

T_EVAL0(Lazy)
T_EVAL(Lazy,1)
T_EVAL(Lazy,2)
T_EVAL(Lazy,4)
T_EVAL(Lazy,8)

T_EVAL0(Incr)
T_EVAL(Incr,1)
T_EVAL(Incr,2)
T_EVAL(Incr,4)
T_EVAL(Incr,8)

T_EVAL(Vincr,1)
T_EVAL(Vincr,2)
T_EVAL(Vincr,4)
T_EVAL(Vincr,8)

/*************** Incremental stuff ****************/

StandardTypes_Incr0 LazyCodeModule_Current;

#define _LIST


static StandardTypes_List Free = NULL;

void LazyCodeModule_IUnval_0 (StandardTypes_Incr0 x)
{ register void* caller;
  register StandardTypes_List free;
  if (x==NULL || x->callers == NULL) { return; }
  if (x->unval != NULL)
  { LazyCodeModule_Eval (x->unval);
  }
  while (1) 
  { free = x->callers;
    if (free == NULL) { return; }
    caller = free->head;
    x->callers = free->tail;
    free->tail = Free;
    Free = free;
    LazyCodeModule_IUnval_0 ((StandardTypes_Incr0)caller);
  }
} /* Unval */

#define UNVAL(n) \
void CAT(LazyCodeModule_Unval_,n) (CAT(StandardTypes_Vincr,n) x) \
{ LazyCodeModule_IUnval_0 ((StandardTypes_Incr0)x); \
}

UNVAL(1)
UNVAL(2)
UNVAL(4)
UNVAL(8)

#define IUNVAL(n) \
void CAT(LazyCodeModule_IUnval_,n) (CAT(StandardTypes_Incr,n) x) \
{ LazyCodeModule_IUnval_0 ((StandardTypes_Incr0)x); \
}

IUNVAL(1)
IUNVAL(2)
IUNVAL(4)
IUNVAL(8)

#define ASSIGN(n) \
static CAT(TYPE_,n) CAT(newval_,n); \
\
static void CAT(AddUndo_,n) (CAT(StandardTypes_Vincr,n) vincr); \
\
void CAT(LazyCodeModule_Assign_,n) (CAT(StandardTypes_Vincr,n) x, CAT(TYPE_,n) y) \
{ if (x->value == y) { return; } \
  CAT(newval_,n) = y; \
  CAT(AddUndo_,n) (x); \
  LazyCodeModule_IUnval_0 ((StandardTypes_Incr0)x); \
  x->value = y; \
}

ASSIGN(1)
ASSIGN(2)
ASSIGN(4)
ASSIGN(8)

#define CREATE_VINCR(n) \
CAT(StandardTypes_Vincr,n) CAT(Create_StandardTypes_Vincr,n) (CAT(TYPE_,n) y) \
{ CAT(StandardTypes_Vincr,n) x = MyStorage_Const_ALLOCATE (sizeof(*x)); \
  x->env     = (address)NULL; \
  x->eval    = CAT(EvalStandardTypes_Vincr,n); \
  x->callers = NULL; \
  x->unval   = NULL; \
  x->value   = y; \
  return x; \
}

CREATE_VINCR(1)
CREATE_VINCR(2)
CREATE_VINCR(4)
CREATE_VINCR(8)

#define NEWVAL(n) \
CAT(TYPE_,n) CAT(LazyCodeModule_NewVal_,n) (CAT(StandardTypes_Vincr,n) x) \
{ return CAT(newval_,n); }

NEWVAL(1)
NEWVAL(2)
NEWVAL(4)
NEWVAL(8)

void LazyCodeModule_Caller (StandardTypes_Incr0 x)
{ register StandardTypes_List l;
  StandardTypes_List m;
  register char* current = (char*)LazyCodeModule_Current;
  register StandardTypes_List callers = x->callers;
  register StandardTypes_List free;
  if (callers != NULL)
  { if (current == NULL) { return; }
    if (callers->head == current) { return; }
  }
#ifdef _UNIQUE
  l = callers;
  while (l != NULL)
  { if (l->head == current) { return; }
    l = l->tail;
  }
#endif
  free = Free;
  if (free == NULL)
  { m = MyStorage_Const_ALLOCATE (sizeof(*m)); l = m; }
  else
  { l = free; Free = free->tail; }
  l->head = current;
  l->tail = callers;
  x->callers = l;
} /* Caller */



StandardTypes_Incr0 LazyCodeModule_CreateIncr (address env, PROC_StandardTypes_Incr0 eval)
{ StandardTypes_Incr0 code;

  code = MyStorage_Const_ALLOCATE (sizeof(Rec_StandardTypes_Incr0));
  code->env     = env;
  code->eval    = eval;
  code->callers = NULL;
  code->unval   = NULL;
  return (code);
} /* CreateIncr */

#define EVAL(n) \
CAT(TYPE_,n) CAT(EvalStandardTypes_Vincr,n) (CAT(StandardTypes_Vincr,n) x) \
{ LazyCodeModule_Caller ((StandardTypes_Incr0)x); \
  return (x->value); \
}

EVAL(1)
EVAL(2)
EVAL(4)
EVAL(8)


/********* Undo and Redo *****/

static StandardTypes_Bool undo_on = FALSE;
static LazyCodeModule_UndoTime the_time = 0;

typedef LazyCodeModule_UndoRec Undo;

LazyCodeModule_UndoRec LazyCodeModule_undo = NULL;
LazyCodeModule_UndoRec LazyCodeModule_redo = NULL;

static Undo undo_free = NULL;

LazyCodeModule_UndoTime LazyCodeModule_new_time (void)
{ if (undo_on) { the_time++; }
  return (the_time); 
}

LazyCodeModule_UndoTime LazyCodeModule_get_time (void)
{ return the_time; 
}

void LazyCodeModule_SetUndo (StandardTypes_Bool u)
{ undo_on = u;
}

#define AddUndo(n) \
static void CAT(AddUndo_,n) (CAT(StandardTypes_Vincr,n) vincr) \
{ Undo u, f; \
  if (!undo_on) { return; } \
  if (undo_free==NULL) \
  { u = MyStorage_ALLOCATE(sizeof(*u)); } \
  else \
  { u = undo_free; \
    undo_free = undo_free->next; \
  } \
  u->time = the_time; \
  u->size = CAT(SIZE_,n); \
  u->uval.CAT(uval,n).vincr = vincr; \
  u->uval.CAT(uval,n).value = vincr->value; \
  u->next = LazyCodeModule_undo; \
  LazyCodeModule_undo = u; \
  /* printf ("New undo %d for time %d\n", (int)u, the_time); */ \
  while (LazyCodeModule_redo!=NULL) \
  { f = LazyCodeModule_redo; \
    LazyCodeModule_redo = LazyCodeModule_redo->next; \
    f->next = undo_free; \
    undo_free = f; \
  } \
}

AddUndo(1)
AddUndo(2)
AddUndo(4)
AddUndo(8)

#define UndoReduStep(n) \
case CAT(SIZE_,n): { CAT(StandardTypes_Vincr,n) vincr = u1->uval.CAT(uval,n).vincr; \
                     StandardTypes_Bool x = undo_on; \
                     CAT(TYPE_,n) val = vincr->value; \
                     undo_on = FALSE; \
                     CAT(LazyCodeModule_Assign_,n) (vincr, u1->uval.CAT(uval,n).value); \
                     u1->uval.CAT(uval,n).value = val; \
                     the_time = u1->time; \
                     undo_on = x; \
                     break; \
                   }

static void UndoRedu (Undo *u, Undo *r, LazyCodeModule_UndoTime t, int forward)
{ Undo u1 = *u;
  if (u1==NULL || !undo_on || (forward ? u1->time>t : u1->time<t)) { return; }
  /* Remove u1 from undo-list */
  /* printf ("moving element %d for time %d towards time %d\n", (int)u1, u1->time, t); */
  *u = u1->next;
  /* Add u1 to redo-list */
  u1->next = *r;
  *r = u1;
  /* Undo u1 */
  switch (u1->size)
    { UndoReduStep(1)
      UndoReduStep(2)
      UndoReduStep(4)
      UndoReduStep(8)
    }
  UndoRedu (u, r, t, forward);
}

void LazyCodeModule_Undo (LazyCodeModule_UndoTime t)
{ UndoRedu (&LazyCodeModule_undo, &LazyCodeModule_redo, t, FALSE);
}

void LazyCodeModule_Redo (LazyCodeModule_UndoTime t)
{ UndoRedu (&LazyCodeModule_redo, &LazyCodeModule_undo, t, TRUE);
}

void LazyCodeModule_UndoStep (void)
{ if (LazyCodeModule_undo==NULL) { return; }
  LazyCodeModule_Undo (LazyCodeModule_undo->time);
}

void LazyCodeModule_RedoStep (void)
{ if (LazyCodeModule_redo==NULL) { return; }
  LazyCodeModule_Redo (LazyCodeModule_redo->time);
}


/*********************************/

CAT(StandardTypes_Lazy,SIZE_String)		LazyCodeModule_LazyEmptyString;
CAT(StandardTypes_Lazy,SIZE_pointer)		LazyCodeModule_LazyNIL;
CAT(StandardTypes_Lazy,SIZE_Bool)		LazyCodeModule_LazyFALSE;
CAT(StandardTypes_Lazy,SIZE_Bool)		LazyCodeModule_LazyTRUE;
CAT(StandardTypes_Lazy,SIZE_Int)		LazyCodeModule_LazyZero;
CAT(StandardTypes_Lazy,SIZE_Int)		LazyCodeModule_LazyOne;
CAT(StandardTypes_Closure,SIZE_void)		LazyCodeModule_LazySkip;

/*********************************/



void LazyCodeModule_Init(void)
{
  LazyCodeModule_LazyEmptyString = MyStorage_ALLOCATE (sizeof (*LazyCodeModule_LazyEmptyString));
  *((char**)&LazyCodeModule_LazyEmptyString->uval.value) = "";
  LazyCodeModule_LazyEmptyString->eval =  CAT(Const_StandardTypes_Lazy,SIZE_String);
  MyStorage_GC_Set_Global (&LazyCodeModule_LazyEmptyString);

  LazyCodeModule_LazyNIL = MyStorage_ALLOCATE (sizeof (*LazyCodeModule_LazyNIL));
  *((StandardTypes_String*)&LazyCodeModule_LazyNIL->uval.value) = NULL;
  LazyCodeModule_LazyNIL->eval =  CAT(Const_StandardTypes_Lazy,SIZE_pointer);
  MyStorage_GC_Set_Global (&LazyCodeModule_LazyNIL);

  LazyCodeModule_LazyFALSE = MyStorage_ALLOCATE (sizeof (*LazyCodeModule_LazyFALSE));
  *((StandardTypes_Bool*)&LazyCodeModule_LazyFALSE->uval.value) = FALSE;
  LazyCodeModule_LazyFALSE->eval =  CAT(Const_StandardTypes_Lazy,SIZE_Bool);
  MyStorage_GC_Set_Global (&LazyCodeModule_LazyFALSE);

  LazyCodeModule_LazyTRUE = MyStorage_ALLOCATE (sizeof (*LazyCodeModule_LazyTRUE));
  *((StandardTypes_Bool*)&LazyCodeModule_LazyTRUE->uval.value) = TRUE;
  LazyCodeModule_LazyTRUE->eval =  CAT(Const_StandardTypes_Lazy,SIZE_Bool);
  MyStorage_GC_Set_Global (&LazyCodeModule_LazyTRUE);

  LazyCodeModule_LazyZero = MyStorage_ALLOCATE (sizeof (*LazyCodeModule_LazyZero));
  *((StandardTypes_Int*)&LazyCodeModule_LazyZero->uval.value) = 0;
  LazyCodeModule_LazyZero->eval =  CAT(Const_StandardTypes_Lazy,SIZE_Int);
  MyStorage_GC_Set_Global (&LazyCodeModule_LazyZero);

  LazyCodeModule_LazyOne = MyStorage_ALLOCATE (sizeof (*LazyCodeModule_LazyOne));
  *((StandardTypes_Int*)&LazyCodeModule_LazyOne->uval.value) = 1;
  LazyCodeModule_LazyOne->eval =  CAT(Const_StandardTypes_Lazy,SIZE_Int);
  MyStorage_GC_Set_Global (&LazyCodeModule_LazyOne);

  LazyCodeModule_LazySkip = MyStorage_ALLOCATE (sizeof (*LazyCodeModule_LazySkip));
  LazyCodeModule_LazySkip->eval = (PROC_StandardTypes_Closure0)LazyCodeModule_Nothing;
  MyStorage_GC_Set_Global (&LazyCodeModule_LazySkip);
  
  MyStorage_GC_Set_Global (&LazyCodeModule_Current);
  MyStorage_GC_Set_Global (&LazyCodeModule_undo);
  MyStorage_GC_Set_Global (&LazyCodeModule_redo);

  LazyCodeModule_SetUndo (FALSE);
}



/* END LazyCodeModule */

