/* File : CGNInit.c */

#include "SYSTEM.h"
#include "Finit.h"
#include "GenCode.h"
#include "Init.h"
#include "Make.h"
#include "PathLib.h"
#include "Switches.h"
#include "TypeModule.h"

extern void CGNInit_Init(void)
{
  Finit_InitGlobals();
  GenCode_InitGlobals();
  Init_InitGlobals();
  Make_InitGlobals();
  PathLib_InitGlobals();
  Switches_InitGlobals();
  TypeModule_InitGlobals();
} /* Init */

/* END CGNInit */
