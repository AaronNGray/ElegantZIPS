/* File : CGNInit.c */

#include "SYSTEM.h"
#include "Checks.h"
#include "Finit.h"
#include "GenCode.h"
#include "Init.h"
#include "StaticSemantics.h"
#include "Switches.h"

extern void CGNInit_Init(void)
{
  Checks_InitGlobals();
  Finit_InitGlobals();
  GenCode_InitGlobals();
  Init_InitGlobals();
  StaticSemantics_InitGlobals();
  Switches_InitGlobals();
} /* Init */

/* END CGNInit */
