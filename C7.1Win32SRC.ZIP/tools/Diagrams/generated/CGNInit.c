/* File : CGNInit.c */

#include "SYSTEM.h"
#include "EBNFCode.h"
#include "Expressions.h"
#include "Finit.h"
#include "Fonts.h"
#include "GenCode.h"
#include "Init.h"
#include "PS.h"
#include "StaticSemantics.h"
#include "Switches.h"

extern void CGNInit_Init(void)
{
  EBNFCode_InitGlobals();
  Expressions_InitGlobals();
  Finit_InitGlobals();
  Fonts_InitGlobals();
  GenCode_InitGlobals();
  Init_InitGlobals();
  PS_InitGlobals();
  StaticSemantics_InitGlobals();
  Switches_InitGlobals();
} /* Init */

/* END CGNInit */
