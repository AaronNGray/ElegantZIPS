/* File : CGNInit.c */

#include "SYSTEM.h"
#include "Contexts.h"
#include "Cycles.h"
#include "Dependencies.h"
#include "Expressions.h"
#include "Fields.h"
#include "Finit.h"
#include "Functions.h"
#include "GenExpr.h"
#include "GenLALR.h"
#include "GenParse.h"
#include "GenRecovery.h"
#include "GenTry.h"
#include "GenTypes.h"
#include "GrammarSymbols.h"
#include "Init.h"
#include "Items.h"
#include "Modules.h"
#include "Operators.h"
#include "Optimize.h"
#include "Output.h"
#include "OutputCFG.h"
#include "Patterns.h"
#include "Ranges.h"
#include "Relations.h"
#include "ReservedIds.h"
#include "Starters.h"
#include "Statistics.h"
#include "Switches.h"
#include "SymbolTable.h"
#include "TermSets.h"
#include "TypeModule.h"
#include "Types.h"
#include "Units.h"
#include "Variables.h"
#include "common.h"

extern void CGNInit_Init(void)
{
  Contexts_InitGlobals();
  Cycles_InitGlobals();
  Dependencies_InitGlobals();
  Expressions_InitGlobals();
  Fields_InitGlobals();
  Finit_InitGlobals();
  Functions_InitGlobals();
  GenExpr_InitGlobals();
  GenLALR_InitGlobals();
  GenParse_InitGlobals();
  GenRecovery_InitGlobals();
  GenTry_InitGlobals();
  GenTypes_InitGlobals();
  GrammarSymbols_InitGlobals();
  Init_InitGlobals();
  Items_InitGlobals();
  Modules_InitGlobals();
  Operators_InitGlobals();
  Optimize_InitGlobals();
  Output_InitGlobals();
  OutputCFG_InitGlobals();
  Patterns_InitGlobals();
  Ranges_InitGlobals();
  Relations_InitGlobals();
  ReservedIds_InitGlobals();
  Starters_InitGlobals();
  Statistics_InitGlobals();
  Switches_InitGlobals();
  SymbolTable_InitGlobals();
  TermSets_InitGlobals();
  TypeModule_InitGlobals();
  Types_InitGlobals();
  Units_InitGlobals();
  Variables_InitGlobals();
  common_InitGlobals();
} /* Init */

/* END CGNInit */
