/* File : CGNInit.c */

#include "SYSTEM.h"
#include "Finit.h"
#include "GenCode.h"
#include "Init.h"
#include "NameSpaces.h"
#include "NonTerminals.h"
#include "Switches.h"
#include "TypeModule.h"

extern void CGNInit_Init(void)
{
  Finit_InitGlobals();
  GenCode_InitGlobals();
  Init_InitGlobals();
  NameSpaces_InitGlobals();
  NonTerminals_InitGlobals();
  Switches_InitGlobals();
  TypeModule_InitGlobals();
} /* Init */

/* END CGNInit */
