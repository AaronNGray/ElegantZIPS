/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/


#ifndef __Messages
#define __Messages

#ifndef __StandardTypes
#include "StandardTypes.h"
#endif

#define Messages_Message void

extern Messages_Message Messages_NewLine (void);

extern Messages_Message Messages_FromIdent (StandardTypes_Ident x);

extern Messages_Message Messages_FromInt (StandardTypes_Int x);

extern Messages_Message Messages_FromChar (StandardTypes_Char x);

extern Messages_Message Messages_FromBool (StandardTypes_Bool x);

extern Messages_Message Messages_FromString (StandardTypes_String x);

extern Messages_Message Messages_FromFloat (StandardTypes_Float x);

extern Messages_Message Messages_FromBitset (StandardTypes_Bitset x);

#endif /*   Messages */

