/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef __SYSTEM
#include "SYSTEM.h"
#endif

#ifndef __StandardTypes
#include "StandardTypes.h"
#endif

#ifndef __SysStreams
#include "SysStreams.h"
#endif

#ifndef __TextIO
#include "TextIO.h"
#endif

#ifndef __SystemTypes
#include "SystemTypes.h"
#endif

#ifndef __Messages
#include "Messages.h"
#endif

#ifndef __FileStream
#include "FileStream.h"
#endif

extern void PrintFloat (FileStream_WriteFile f, StandardTypes_Float s);

Messages_Message Messages_NewLine (void)
{
  TextIO_NewLine (SysStreams_sysErr);
} /* NewLine */

Messages_Message Messages_FromIdent (StandardTypes_Ident id)
{
  if (id NEQ NULL)
  { TextIO_WriteString (SysStreams_sysErr, (string)(id->represent)); }
} /* FromIdent */

Messages_Message Messages_FromInt (StandardTypes_Int i)
{
  TextIO_WriteINTEGER (SysStreams_sysErr, i);
} /* FromInt */

Messages_Message Messages_FromChar (StandardTypes_Char c)
{
  TextIO_WriteCHAR (SysStreams_sysErr, c);
} /* FromChar */

Messages_Message Messages_FromBool (StandardTypes_Bool b)
{
  if (b)
  { TextIO_WriteString (SysStreams_sysErr, (string)"TRUE"); } 
  else 
  { TextIO_WriteString (SysStreams_sysErr, (string)"FALSE"); }
} /* FromBool */

Messages_Message Messages_FromString (StandardTypes_String s)
{ if (s NEQ NULL)
  { TextIO_WriteString (SysStreams_sysErr, (string)(s)); }
} /* FromString */

Messages_Message Messages_FromFloat (StandardTypes_Float s)
{ PrintFloat (SysStreams_sysErr, s);
} /* FromFloat */

static Char hex_values[] = "0123456789abcdef";

Messages_Message Messages_FromBitset (StandardTypes_Bitset s)
{ 
  TextIO_WriteString (SysStreams_sysOut, "0x");
  if (s > 16) { Messages_FromBitset(s DIV 16); }
  TextIO_WriteCHAR(SysStreams_sysOut,hex_values[s MOD 16]);
} /* FromBitset */

/* END Messages */

