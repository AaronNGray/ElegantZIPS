/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef __SYSTEM
#include "SYSTEM.h"
#endif

#ifndef __StandardTypes
#include "StandardTypes.h"
#endif

#ifndef __SysStreams
#include "SysStreams.h"
#endif

#ifndef __TextIO
#include "TextIO.h"
#endif

#ifndef __SystemTypes
#include "SystemTypes.h"
#endif

#ifndef __Outputs
#include "Outputs.h"
#endif

extern void PrintFloat (FileStream_WriteFile f, StandardTypes_Float s);


Outputs_Output Outputs_NewLine (void)
{
  TextIO_NewLine (SysStreams_sysOut);
} /* NewLine */

Outputs_Output Outputs_FromIdent (StandardTypes_Ident id)
{
  if (id NEQ NULL)
  { TextIO_WriteString (SysStreams_sysOut, (string)(id->represent)); }
} /* FromIdent */

Outputs_Output Outputs_FromInt (StandardTypes_Int i)
{
  TextIO_WriteINTEGER (SysStreams_sysOut, i);
} /* FromInt */

Outputs_Output Outputs_FromChar (StandardTypes_Char c)
{
  TextIO_WriteCHAR (SysStreams_sysOut, c);
} /* FromChar */

Outputs_Output Outputs_FromBool (StandardTypes_Bool b)
{
  if (b)
  { TextIO_WriteString (SysStreams_sysOut, (string)"TRUE"); } 
  else 
  { TextIO_WriteString (SysStreams_sysOut, (string)"FALSE"); }
} /* FromBool */

Outputs_Output Outputs_FromString (StandardTypes_String s)
{ if (s NEQ NULL)
  { TextIO_WriteString (SysStreams_sysOut, (string)(s)); }
} /* FromString */

Outputs_Output Outputs_FromFloat (StandardTypes_Float s)
{ PrintFloat (SysStreams_sysOut, s);
} /* FromFloat */

static Char hex_values[] = "0123456789abcdef";

Outputs_Output Outputs_FromBitset (StandardTypes_Bitset s)
{ 
  TextIO_WriteString (SysStreams_sysOut, "0x");
  if (s > 16) { Outputs_FromBitset(s DIV 16); }
  TextIO_WriteCHAR(SysStreams_sysOut,hex_values[s MOD 16]);
} /* FromBitset */

/* END Outputs */

