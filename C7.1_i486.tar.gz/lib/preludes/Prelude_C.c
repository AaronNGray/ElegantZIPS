/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#include "StandardTypes.h"
#include "TextIO.h"
#include "Machines.h"

#include "Prelude_C.h"
#include "Prelude.h"
#include "SYSTEM.h"
#include "StandardTypes.h"
#include "TextIO.h"
#include "FileStream.h"
#include "SysStreams.h"
#include "UnixProcess.h"

/*************** Int operations ***************/

StandardTypes_Int _F_Plus (StandardTypes_Int i1, StandardTypes_Int i2)
{ return (i1+i2); }

StandardTypes_Int _F_Minus (StandardTypes_Int i1, StandardTypes_Int i2)
{ return (i1-i2); }

StandardTypes_Int _F_Times (StandardTypes_Int a, StandardTypes_Int b)
{ return (a*b); }

StandardTypes_Int _F_Div (StandardTypes_Int a, StandardTypes_Int b)
{ return (a / b); }

StandardTypes_Int _F_Rem (StandardTypes_Int a, StandardTypes_Int b)
{ return (_REM(a,b)); } 

StandardTypes_Int _F_Mod (StandardTypes_Int a, StandardTypes_Int b)
{ return (_MOD(a,b)); } 

StandardTypes_Int _F_Neg (StandardTypes_Int a)
{ return (-a); }

StandardTypes_Bool _F_Even (StandardTypes_Int a)
{ return (a % 2 == 0); }

StandardTypes_Bool _F_Odd (StandardTypes_Int a)
{ return (a % 2 != 0); }

StandardTypes_Int _F_Min (StandardTypes_Int a, StandardTypes_Int b)
{ return (_MIN(a,b)); } 

StandardTypes_Int _F_Max (StandardTypes_Int a, StandardTypes_Int b)
{ return (_MAX(a,b)); } 

void _F_AssPlus  (StandardTypes_Int *a, StandardTypes_Int b)
{ _ASSPLUS(a,b); } 

void _F_AssMinus (StandardTypes_Int *a, StandardTypes_Int b)
{ _ASSMINUS(a,b); } 

void _F_AssTimes (StandardTypes_Int *a, StandardTypes_Int b)
{ _ASSTIMES(a,b); } 

void _F_AssDiv   (StandardTypes_Int *a, StandardTypes_Int b)
{ _ASSDIV(a,b); } 


/*************** Float operations ***************/

StandardTypes_Float _Fl_Plus (StandardTypes_Float i1, StandardTypes_Float i2)
{ return (i1+i2); }

StandardTypes_Float _Fl_Minus (StandardTypes_Float i1, StandardTypes_Float i2)
{ return (i1-i2); }

StandardTypes_Float _Fl_Times (StandardTypes_Float a, StandardTypes_Float b)
{ return (a*b); }

StandardTypes_Float _Fl_Div (StandardTypes_Float a, StandardTypes_Float b)
{ return (a / b); }

StandardTypes_Float _Fl_Neg (StandardTypes_Float a)
{ return (-a); }

StandardTypes_Float _Fl_Min (StandardTypes_Float a, StandardTypes_Float b)
{ return (_MIN(a,b)); } 

StandardTypes_Float _Fl_Max (StandardTypes_Float a, StandardTypes_Float b)
{ return (_MAX(a,b)); } 

StandardTypes_Int _F_Float2Int (StandardTypes_Float a)
{ return ((StandardTypes_Int)a); }

StandardTypes_Float _F_Int2Float (StandardTypes_Int a)
{ return ((StandardTypes_Float)a); }

void _Fl_AssPlus  (StandardTypes_Float *a, StandardTypes_Float b)
{ _ASSPLUS(a,b); } 

void _Fl_AssMinus (StandardTypes_Float *a, StandardTypes_Float b)
{ _ASSMINUS(a,b); } 

void _Fl_AssTimes (StandardTypes_Float *a, StandardTypes_Float b)
{ _ASSTIMES(a,b); } 

void _Fl_AssDiv   (StandardTypes_Float *a, StandardTypes_Float b)
{ _ASSDIV(a,b); } 


static void PrintSimpleFloat (FileStream_WriteFile f, StandardTypes_Float real)
{
  int i, digit;
  if (real < 0.0)
  { TextIO_WriteCHAR (f, '-'); real = -real; }
  { StandardTypes_Float round = 0.5;
    for (i = 1 ; i <= Prelude_print_precision ; i++) { round /= 10.0; }
    real += round;
  }
  TextIO_WriteCARDINAL (f, (cardinal)real);
  real -= (StandardTypes_Float)((cardinal)real);
  if (Prelude_print_precision > 0)
  { TextIO_WriteCHAR (f, '.');
    for (i = 1 ; i <= Prelude_print_precision ; i++) 
    { real = 10.0 * real;
      digit = (cardinal)real;
      real = real - (StandardTypes_Float)digit;
      TextIO_WriteCHAR (f, (Char)((cardinal)'0'+digit));
    }
  }
} /* PrintSimpleFloat */

void PrintFloat (FileStream_WriteFile f, StandardTypes_Float real)
{
  if (Prelude_print_exponent)
  { int exponent = 0;
    if (real < 0.0)
    { TextIO_WriteCHAR (f, '-'); real = -real; }
    if (real != 0.0)
    { while (real >= 10.0) { exponent++ ; real /= 10.0; }
      while (real <   1.0) { exponent-- ; real *= 10.0; }
    }
    PrintSimpleFloat (f, real);
    TextIO_WriteCHAR (f, 'e');
    if (exponent < 0)
    { TextIO_WriteCHAR (f, '-'); exponent = -exponent; }
    else
    { TextIO_WriteCHAR (f, '+'); }
    if (exponent < 10)
    { TextIO_WriteCHAR (f, '0'); }
    TextIO_WriteINTEGER (f, exponent);
  }
  else
  { PrintSimpleFloat (f, real);
  }
}


/*************** Bool operations ***************/

StandardTypes_Bool _F_And (StandardTypes_Bool a, StandardTypes_Bool b)
{ return (a && b); }

StandardTypes_Bool _F_Or (StandardTypes_Bool a, StandardTypes_Bool b)
{ return (a || b); }

StandardTypes_Bool _F_Implies (StandardTypes_Bool a, StandardTypes_Bool b)
{ return (!a || b); }

StandardTypes_Bool _F_Not (StandardTypes_Bool a)
{ return (! a); }


/*************** Char operations ***************/

StandardTypes_Int _F_Char2Int (StandardTypes_Char c)
{ return ((unsigned int)c); }

StandardTypes_Char _F_Int2Char (StandardTypes_Int i)
{
  if ((i < 0) OR (i > 255))
  { TextIO_WriteString 
       (SysStreams_sysErr, (string)"Argument of Character.Chr out of range.");
    TextIO_NewLine (SysStreams_sysErr);
    TextIO_Flush(SysStreams_sysErr);
    UnixProcess_Exit (UnixProcess_Failure);
  }
  return ((StandardTypes_Char) (i));
} /* Chr */

/*************** String operations ***************/

StandardTypes_Bool _FS_Eq (StandardTypes_String a, StandardTypes_String b)
{ return _STRING_EQ (a,b); }

StandardTypes_Bool _FS_Lt (StandardTypes_String a, StandardTypes_String b)
{ return _STRING_LT (a,b); }

StandardTypes_Bool _FS_Gt (StandardTypes_String a, StandardTypes_String b)
{ return _STRING_GT (a,b); }


/*************** Bitset operations ***************/

StandardTypes_Bitset _F_Set_Empty ()
{ return _EMPTYSET(); }

StandardTypes_Bool _F_Set_In (StandardTypes_Int i, StandardTypes_Bitset s)
{ return _IN(i,s); }

StandardTypes_Bool _F_Set_Subset (StandardTypes_Bitset i, StandardTypes_Bitset s)
{ return SUBSET(i,s); }

StandardTypes_Bitset _F_Set_Incl (StandardTypes_Bitset s, StandardTypes_Int i)
{ StandardTypes_Bitset t;
  t = s;
  t = INCL (t, (cardinal)i);
  return (t);
} /* Incl */

StandardTypes_Bitset _F_Set_Excl (StandardTypes_Bitset s, StandardTypes_Int i)
{ StandardTypes_Bitset t;
  t = s;
  t = EXCL (t, (cardinal)i);
  return (t);
} /* Excl */

StandardTypes_Int _F_Set_Size (StandardTypes_Bitset s)
{ cardinal i, n;
  n = 0;
  for (i = 0; i < Machines_BITSPERWORD; i++)
  { if (IN(i,s)) { n++; } }
  return (n);
} /* Size */

StandardTypes_Bitset _F_Set_Union (StandardTypes_Bitset s, StandardTypes_Bitset i)
{ return s | i; }

StandardTypes_Bitset _F_Set_Diff (StandardTypes_Bitset s, StandardTypes_Bitset i)
{ return DIFFERENCE(s,i); }

StandardTypes_Bitset _F_Set_Intersect (StandardTypes_Bitset s, StandardTypes_Bitset i)
{ return s & i; }

StandardTypes_Bitset _F_Set_XOr (StandardTypes_Bitset s, StandardTypes_Bitset i)
{ return s ^ i; }

StandardTypes_Bitset _F_Set_Negate (StandardTypes_Bitset s)
{ return ~s; }

StandardTypes_Bitset _F_ShiftLeft (StandardTypes_Bitset s, StandardTypes_Int i)
{ return s << i; }

StandardTypes_Bitset _F_ShiftRight (StandardTypes_Bitset s, StandardTypes_Int i)
{ return s >> i; }

StandardTypes_Bitset _F_BITSET_NULL (StandardTypes_Int b)
{ return _BITSET_NULL(b); }

StandardTypes_Bitset _F_BITSET_CONSTRUCT (StandardTypes_Int b, StandardTypes_Bitset x)
{ return _BITSET_CONSTRUCT(b,x); }

StandardTypes_Int _F_BITSET_START (StandardTypes_Bitset s)
{ return _BITSET_START (s); }

StandardTypes_Bool _F_BITSET_DESTRUCT (StandardTypes_Bitset *b, StandardTypes_Int *s, StandardTypes_Int*x)
{ return _BITSET_DESTRUCT (b,s,x); }

/*************** Generic comparison operations ***************/

StandardTypes_Bool _F_Eq_1 (TYPE_1 a, TYPE_1 b)
{ return a==b; }

StandardTypes_Bool _F_Eq_2 (TYPE_2 a, TYPE_2 b)	
{ return a==b; }

StandardTypes_Bool _F_Eq_4 (TYPE_4 a, TYPE_4 b)	
{ return a==b; }

StandardTypes_Bool _F_Eq_8 (TYPE_8 a, TYPE_8 b)	
{ return a==b; }

StandardTypes_Bool _F_Neq_1 (TYPE_1 a, TYPE_1 b)
{ return a!=b; }
	
StandardTypes_Bool _F_Neq_2 (TYPE_2 a, TYPE_2 b)
{ return a!=b; }
	
StandardTypes_Bool _F_Neq_4 (TYPE_4 a, TYPE_4 b)
{ return a!=b; }
	
StandardTypes_Bool _F_Neq_8 (TYPE_8 a, TYPE_8 b)
{ return a!=b; }	

StandardTypes_Bool _F_Lt (StandardTypes_Int a, StandardTypes_Int b)
{ return (a < b); }

StandardTypes_Bool _F_Le (StandardTypes_Int a, StandardTypes_Int b)
{ return (a <= b); }

StandardTypes_Bool _F_Gt (StandardTypes_Int a, StandardTypes_Int b)
{ return (a > b); }

StandardTypes_Bool _F_Ge (StandardTypes_Int a, StandardTypes_Int b)
{ return (a >= b); }

/*********/

StandardTypes_Bool _Fl_Lt (StandardTypes_Float a, StandardTypes_Float b)
{ return (a < b); }

StandardTypes_Bool _Fl_Le (StandardTypes_Float a, StandardTypes_Float b)
{ return (a <= b); }

StandardTypes_Bool _Fl_Gt (StandardTypes_Float a, StandardTypes_Float b)
{ return (a > b); }

StandardTypes_Bool _Fl_Ge (StandardTypes_Float a, StandardTypes_Float b)
{ return (a >= b); }

/****** List operations  **********/

_List1 _F_LIST_NULL_1 (TYPE_1 x)
{ return _LIST_NULL (x); }

_List2 _F_LIST_NULL_2 (TYPE_2 x)
{ return _LIST_NULL (x); }

_List4 _F_LIST_NULL_4 (TYPE_4 x)
{ return _LIST_NULL (x); }

_List8 _F_LIST_NULL_8 (TYPE_8 x)
{ return _LIST_NULL (x); }

_List1 _F_LIST_CONSTRUCT_1 (_List1 l, TYPE_1 x)
{ _List1 *m = &l;
  while (*m != NULL) { m = &((*m)->tail); }
  *m = Create_Prelude_List1 (x, NULL);
  return l;
}

/*
_List2 _F_LIST_CONSTRUCT_2 (_List2 l, TYPE_2 x)
{ _List2 *m = &l;
  while (*m != NULL) { m = &((*m)->tail); }
  *m = Create_Prelude_List2 (x, NULL);
  return l;
}
*/

_List4 _F_LIST_CONSTRUCT_4 (_List4 l, TYPE_4 x)
{ _List4 *m = &l;
  while (*m != NULL) { m = &((*m)->tail); }
  *m = Create_Prelude_List4 (x, NULL);
  return l;
}

_List8 _F_LIST_CONSTRUCT_8 (_List8 l, TYPE_8 x)
{ _List8 *m = &l;
  while (*m != NULL) { m = &((*m)->tail); }
  *m = Create_Prelude_List8 (x, NULL);
  return l;
}


_List1 _F_LIST_START_1 (_List1 a)
{ return _LIST_START (a); }

/*
_List2 _F_LIST_START_2 (_List2 a)
{ return _LIST_START (a); }
*/

_List4 _F_LIST_START_4 (_List4 a)
{ return _LIST_START (a); }

_List8 _F_LIST_START_8 (_List8 a)
{ return _LIST_START (a); }

StandardTypes_Bool _F_LIST_DESTRUCT_1 (_List1 *a, _List1 *i, TYPE_1 *x)
{ return _LIST_DESTRUCT (a,i,x); }

/*
StandardTypes_Bool _F_LIST_DESTRUCT_2 (_List2 *a, _List2 *i, TYPE_2 *x)
{ return _LIST_DESTRUCT (a,i,x); }
*/

StandardTypes_Bool _F_LIST_DESTRUCT_4 (_List4 *a, _List4 *i, TYPE_4 *x)
{ return _LIST_DESTRUCT (a,i,x); }

StandardTypes_Bool _F_LIST_DESTRUCT_8 (_List8 *a, _List8 *i, TYPE_8 *x)
{ return _LIST_DESTRUCT (a,i,x); }


/****** Array operations **********/

StandardTypes_Int _F_Array_Size_1 (StandardTypes_Array1 a)
{ return _ARRAY_SIZE(a); }

/*
StandardTypes_Int _F_Array_Size_2 (StandardTypes_Array2 a)
{ return _ARRAY_SIZE(a); }
*/

StandardTypes_Int _F_Array_Size_4 (StandardTypes_Array4 a)
{ return _ARRAY_SIZE(a); }

StandardTypes_Int _F_Array_Size_8 (StandardTypes_Array8 a)
{ return _ARRAY_SIZE(a); }

/****** Set operations **********/

_Set1 _F_SET_NULL_1 (TYPE_1 x)
{ return _LIST_NULL (x); }

/*
_Set2 _F_SET_NULL_2 (TYPE_2 x)
{ return _LIST_NULL (x); }
*/

_Set4 _F_SET_NULL_4 (TYPE_4 x)
{ return _LIST_NULL (x); }

_Set8 _F_SET_NULL_8 (TYPE_8 x)
{ return _LIST_NULL (x); }

_Set1 _F_SET_START_1 (_Set1 a)
{ return _LIST_START (a); }

/*
_Set2 _F_SET_START_2 (_Set2 a)
{ return _LIST_START (a); }
*/

_Set4 _F_SET_START_4 (_Set4 a)
{ return _LIST_START (a); }

_Set8 _F_SET_START_8 (_Set8 a)
{ return _LIST_START (a); }

StandardTypes_Bool _F_SET_DESTRUCT_1 (_Set1 *a, _Set1 *i, TYPE_1 *x)
{ return _LIST_DESTRUCT (a,i,x); }

/*
StandardTypes_Bool _F_SET_DESTRUCT_2 (_Set2 *a, _Set2 *i, TYPE_2 *x)
{ return _LIST_DESTRUCT (a,i,x); }
*/

StandardTypes_Bool _F_SET_DESTRUCT_4 (_Set4 *a, _Set4 *i, TYPE_4 *x)
{ return _LIST_DESTRUCT (a,i,x); }

StandardTypes_Bool _F_SET_DESTRUCT_8 (_Set8 *a, _Set8 *i, TYPE_8 *x)
{ return _LIST_DESTRUCT (a,i,x); }


