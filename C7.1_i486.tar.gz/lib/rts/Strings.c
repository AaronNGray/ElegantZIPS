/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef __SYSTEM
#include "SYSTEM.h"
#endif

#ifndef __SystemTypes
#include "SystemTypes.h"
#endif

#ifndef __MyStorage
#include "MyStorage.h"
#endif

#ifndef __Strings
#include "Strings.h"
#endif


string Strings_New (int n)
{ 
  string s;
  if (n < 0) { n = 0; }
  s = MyStorage_ALLOCATE (sizeof (Char)*((cardinal)n+1));
  s[n] = '\0';
  return(s);
} /* New */

void Strings_Dispose (string s)
{
  MyStorage_DEALLOCATE (s, (cardinal)Strings_Length (s)+1);
} /* Dispose */

int Strings_Length (string s)
{ 
  cardinal i ;
  i = 0;
  while (s[i] NEQ '\0')
  { i++; }
  return(i);
} /* VLength */

void Strings_FromString (string s1, string s2, int length) 
{ int i;
  i = 0;
  while ((i < length) AND (s1[i] NEQ '\0'))
  { s2[i] = s1[i];
    i++;
  }
  s2[i] = '\0';
} /* FromString */

string Strings_LAppend (string s1, string s2, int l1, int l2)
{
  int i, j;
  string s3;
  s3 = Strings_New ((l1 + l2));
  i = 0;
  while (i < l1)
  { s3[i] = s1[i];
    i++;
  }
  j = 0;
  while (j < l2)
  { s3[i] = s2[j];
    i++;
    j++;
  }
  return(s3);
} /* Append */

string Strings_Append (string s1, string s2)
{
  return(Strings_LAppend (s1, s2, Strings_Length (s1), Strings_Length (s2)));
} /* SSAppend */

string Strings_FromCardinal (cardinal i)
{
  cardinal n;
  int l;
  string s;
  l = 0;
  n = i;
  do
  { n = n DIV 10;
    l++;
  } while (n NEQ 0);
  s = Strings_New (l);
  n = i;
  l--;
  while (l >= 0)
  { s[l] = (Char) (n MOD 10 + (cardinal)'0');
     l--;
     n = n DIV 10;
  }
  return(s);
} /* FromCardinal */

string Strings_LIAppend (string s, int length, int n)
{
  string s1;
  int l, i, j;
  bool neg = n < 0;
  l = 0;
  if (neg) { n = -n; l++; }
  i = n;
  do 
  { i = i DIV 10;
    l++;
  } while (i NEQ 0);
  s1 = Strings_New ((int)(length + l));
  j = 0;
  while (j < length)
  { s1[j] = s[j];
    j++;
  }
  j = j+l-1;
  i = n;
  if (neg) { l--; }
  while (l > 0)
  { s1[j] = (Char)(i MOD 10 + (cardinal)'0');
    l--;
    j--;
    i = i DIV 10;
  }
  if (neg) { s1[j] = '-'; }
  return(s1);
} /* IAppend */

string Strings_IAppend (string s, int n)
{
  return(Strings_LIAppend (s, Strings_Length (s), n));
} /* SIAppend */

SystemTypes_Comparison Strings_Compare (string s1, string s2)
{  
  cardinal i ;
  Char c1, c2 ;
  i = 0;
  while ((s1[i] NEQ '\0') AND (s2[i] NEQ '\0'))
  { c1 = s1[i];
    c2 = s2[i];
    if (c1 NEQ c2)
    { if (c1 < c2) { return(SystemTypes_LT); }
      return(SystemTypes_GT);
    }
    i++;
  }
  if (s1[i] EQ '\0')
  { if (s2[i] EQ '\0') { return(SystemTypes_EQ); }
    return(SystemTypes_LT);
  }
  return(SystemTypes_GT);
} /* Compare */

void Strings_InitGlobals (void) { }

/* END Strings */

