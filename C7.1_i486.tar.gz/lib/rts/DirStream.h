/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/
/* File DirStream.h
*/
#ifndef __DirStream
#define __DirStream

#ifndef __SYSTEM
#include "SYSTEM.h"
#endif

#ifndef __dirent
#ifndef _dos
#include <dirent.h>
#else
#include <msdir.h>
#endif
#endif

typedef DIR    *DirStream_Dir;
typedef struct dirent *DirStream_Dirent;

#define SIZE_Dirent SIZE_pointer
#define SIZE_Dir   SIZE_pointer

extern DirStream_Dir DirStream_opendir(string filename);

extern void DirStream_closedir(DirStream_Dir dirp);

extern DirStream_Dirent DirStream_readdir(DirStream_Dir dirp);

extern Char *DirStream_getname(DirStream_Dirent dirent);

extern void DirStream_InitGlobals (void);

#endif
