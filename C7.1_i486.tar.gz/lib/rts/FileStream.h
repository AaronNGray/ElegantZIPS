/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef __FileStream
#define __FileStream

#ifndef __SYSTEM
#include "SYSTEM.h"
#endif

typedef FILE* FileStream_ReadFile; /* Unix file */
typedef FILE* FileStream_WriteFile; /* Unix file */

#define SIZE_ReadFile SIZE_pointer
#define SIZE_WriteFile SIZE_pointer

extern bool FileStream_CreateInput (string name, FileStream_ReadFile *f);
/*  Open an input stream to file 'name'. Returns false on error.
*/

extern bool FileStream_CreateOutput (string name, FileStream_WriteFile *f);
/*  Open an output stream to file 'name'.
    The file is empty (emptied). Returns false on error.
*/

extern bool FileStream_AppendOutput (string name, FileStream_WriteFile *f);
/*  Reopen an output stream to file 'name'.
    The file is not emptied. Returns false on error.
*/

extern void FileStream_CloseInput (FileStream_ReadFile f);

extern void FileStream_CloseOutput (FileStream_WriteFile f);

extern int FileStream_Read (address ptr, int size, int nitems, FileStream_ReadFile f);
/*  Reads nitems of size bytes each in the locations starting at ptr.
   Returns the number actually read. */

extern int FileStream_Write (address ptr, int size, int nitems, FileStream_WriteFile f);
/*  Writes nitems of size bytes each from the locations starting at ptr.
   Returns the number actually written. */
   
extern bool FileStream_Eof (FileStream_ReadFile f);

extern void FileStream_InitGlobals (void);

#endif /*  FileStream */

