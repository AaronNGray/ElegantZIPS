/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef _ANSI
#define _ANSI  /* To avoid multiple inclusion */

/*
 * COPYRIGHT (C) 1987, 1988, 1989, 1990, 1991, 1992
 * PHILIPS RESEARCH 
 * INFORMATION AND SOFTWARE TECHNOLOGY
 * EINDHOVEN, THE NETHERLANDS
 *
 * FILE         : <ansi.h> for Sun3 and Sun4, OS4.1 with native C
 * 12NC         : 4322 270 54972
 *
 * DESCRIPTION  :
 *      This file contains the interface with the standard C run-time library
 *      as defined in the ANSI X3J11 Draft Standard version oct. 31, 1988.
 *      Since the X/OPEN group announced that they intend to follow the
 *      ANSI standard, the ANSI standard seems to be the C standard with
 *      the widest acceptance.
 *
 *      The goal of this header file is to provide a C-programmer with the
 *      definitions and declarations according to the ANSI-C standard.
 *      The portability of C-programs can be improved considerably by
 *      restricting yourself to your own stuff, supported by the <ansi.h>
 *      objects. The next list is an enumeration of the objects that must
 *      be defined or declared according to the ANSI-C standard.
 *      If you need external objects not mentioned in this list you can
 *      import them in the usual way e.g. by a conditional include of the
 *      appropriate header file e.g.:
 *
 *                      #ifndef _STDIO
 *                      #define _STDIO
 *                      #include <stdio.h>
 *                      #endif
 *
 *      This overrules the <stdio.h> part in <ansi.h> provided that <ansi.h>
 *      is included as last (preferably only) standard headerfile.
 *
 *      Note: Take care when doing this. When for instance you want to
 *      include your own file <varargs.h>, there is a problem since <ansi.h>
 *      assumes that variable argument stuff comes from <stdarg.h>.
 *
 *      It is also possible to exclude specific type definitions from
 *      this file. In that case you have to define the appropriate macro.
 *      To exclude for instance the typedef of size_t you would add the line
 *                      #define _SIZE_T
 *      before the inclusion of <ansi.h>
 *
 *      The ANSI-C draft standard library reserved names:
 *
 *      BUFSIZ          SEEK_END        fputs           rewind
 *      CHAR_BIT        SEEK_SET        fread           scanf
 *      CHAR_MAX        SHRT_MAX        free            setbuf
 *      CHAR_MIN        SHRT_MIN        freopen         setjmp
 *      CLK_TCK         SIGABRT         frexp           setlocale
 *      DBL_DIG         SIGFPE          fscanf          setvbuf
 *      DBL_EPSILON     SIGILL          fseek           sig_atomic_t
 *      DBL_MANT_DIG    SIGINT          fsetpos         signal
 *      DBL_MAX         SIGSEGV         ftell           sin
 *      DBL_MAX_10_EXP  SIGTERM         fwrite          sinh
 *      DBL_MAX_EXP     SIG_DFL         getc            size_t
 *      DBL_MIN         SIG_ERR         getchar         sprintf
 *      DBL_MIN_10_EXP  SIG_IGN         getenv          sqrt
 *      DBL_MIN_EXP     TMP_MAX         gets            srand
 *      EDOM            UCHAR_MAX       gmtime          sscanf
 *      EOF             UINT_MAX        isalnum         stderr
 *      ERANGE          ULONG_MAX       isalpha         stdin
 *      EXIT_FAILURE    USHRT_MAX       iscntrl         stdout
 *      EXIT_SUCCESS    _IOFBF          isdigit         strcat
 *      FILE            _IOLBF          isgraph         strchr
 *      FILENAME_MAX    _IONBF          islower         strcmp
 *      FLT_DIG         abort           isprint         strcoll
 *      FLT_EPSILON     abs             ispunct         strcpy
 *      FLT_MANT_DIG    acos            isspace         strcspn
 *      FLT_MAX         asctime         isupper         strerror
 *      FLT_MAX_10_EXP  asin            isxdigit        strftime
 *      FLT_MAX_EXP     assert          jmp_buf         strlen
 *      FLT_MIN         atan            labs            strncat
 *      FLT_MIN_10_EXP  atan2           lconv           strncmp
 *      FLT_MIN_EXP     atexit          ldexp           strncpy
 *      FLT_RADIX       atof            ldiv            strpbrk
 *      FLT_ROUNDS      atoi            ldiv_t          strrchr
 *      FOPEN_MAX       atol            localeconv      strspn
 *      HUGE_VAL        bsearch         localtime       strstr
 *      INT_MAX         calloc          log             strtod
 *      INT_MIN         ceil            log10           strtok
 *      LC_ALL          clearerr        longjmp         strtol
 *      LC_COLLATE      clock           malloc          strtoul
 *      LC_CTYPE        clock_t         mblen           strxfrm
 *      LC_MONETARY     cos             mbstowcs        system
 *      LC_NUMERIC      cosh            mbtowc          tan
 *      LC_TIME         ctime           memchr          tanh
 *      LDBL_DIG        difftime        memcmp          time
 *      LDBL_EPSILON    div             memcpy          time_t
 *      LDBL_MANT_DIG   div_t           memmove         tm
 *      LDBL_MAX        errno           memset          tmpfile
 *      LDBL_MAX_10_EXP exit            mktime          tmpnam
 *      LDBL_MAX_EXP    exp             modf            tolower
 *      LDBL_MIN        fabs            offsetof        toupper
 *      LDBL_MIN_10_EXP fclose          perror          ungetc
 *      LDBL_MIN_EXP    feof            pow             va_arg
 *      LONG_MAX        ferror          printf          va_end
 *      LONG_MIN        fflush          ptrdiff_t       va_list
 *      L_tmpnam        fgetc           putc            va_start
 *      MB_CUR_MAX      fgetpos         putchar         vfprintf
 *      MB_LEN_MAX      fgets           puts            vprintf
 *      NDEBUG          floor           qsort           vsprintf
 *      NULL            fmod            raise           wchar_t
 *      RAND_MAX        fopen           rand            wcstombs
 *      SCHAR_MAX       fpos_t          realloc         wctomb
 *      SCHAR_MIN       fprintf         remove
 *      SEEK_CUR        fputc           rename
 * 
 *      Changes in this version relative to the generic version:
 *      - Sun does not know the keyword signed (eg. signed char c);
 *        chars on sun are by default signed.
 *      - the type long double is not implemented on SUN.
 *      - no argument lists allowed in function declarations.
 *      - local values are substituted in float.h.
 *      - local values are substituted in limits.h.
 *      - local value is substituted for HUGE_VAL in math.h part.
 *      - va_arg returns something cast to (mode *) instead of (mode).
 *      - adapted constants L_tmpnam and TMP_MAX (stdio.h).
 *      - sprintf and vsprintf return a char * instead of an int.
 *      - The following functions are NOT available in the C library
 *        of the cc compiler. They ARE available in the library of the
 *        acc compiler:
 *       raise          (signal.h)
 *       fgetpos        (stdio.h)
 *       fsetpos        (stdio.h)
 *       strtoul        (stdlib.h)
 *       atexit         (stdlib.h)
 *       div            (stdlib.h)
 *       labs           (stdlib.h)
 *       ldiv           (stdlib.h)
 *       memmove        (string.h)
 *       strerror       (string.h)
 *       difftime       (time.h)
 *      - cc does not know the keywords const and volatile. If cc is used,
 *        they are defined as empty. If acc is used, these keywords are
 *        not redefined.
 *      - The type sig_atomic_t is nowhere mentioned.
 *        Currently it is typedef'd to int.
 *      - On some places in this include file routines are declared as
 *        having return type void or void *. Within the Sun run time
 *        support library these functions return int and char *
 *        respectively. This does not lead to errors. Using void is
 *        compatible with the ANSI standard.
 *      - Note that this SUN version is not intended for use with the
 *        system V compatibility library.
 *      - Note that this SUN version is intended for use without a
 *        floating point unit.
 *      
 * USED FILES   : None, but the following header files were used as source
 *                text to assemble large parts of <ansi.h>. A description
 *                of these files can be found in the 1988 ANSI C-draft and
 *                in the 1987 X/OPEN portability guide. Recent releases of
 *                professional C compiler packages contain most of these
 *                header files.
 *
 *                      <assert.h>
 *                      <ctype.h>
 *                      <errno.h>
 *                      <float.h>       only in ANSI
 *                      <limits.h>
 *                      <locale.h>
 *                      <math.h>
 *                      <search.h>      only in X/OPEN
 *                      <setjmp.h>
 *                      <stdarg.h>      called <varargs.h> in X/OPEN
 *                      <stddef.h>      only in ANSI
 *                      <stdio.h>
 *                      <stdlib.h>
 *                      <string.h>
 *                      <time.h>
 *
 * DECISIONS    : The parts of this file related to the above list of files
 *                are #ifndef#define/#endif bracketed to avoid clashes if
 *                such a file is included in a conditional way according to
 *                the coding standards. In this way a user can overrule
 *                e.g. the portable parts of <stdio.h> by the full <stdio.h>
 *                of the local compiler without overruling the remaining
 *                <ansi.h> sections.
 *
 *                Supporting functions for e.g. macro definitions are
 *                declared in this file. An undisciplined user can call
 *                these non ANSI-88 functions without warning.
 *
 *                NDEBUG is not defined in this file. If required, an end
 *                user must define it in his source file.
 *
 *                All typedefs will be bracketed with #ifndef/#endif to allow
 *                a user to exclude typedefs selectively (e.g. in the case of
 *                clashes with certain system defined types)
 *
 *                All function declarations contain optional parameter
 *                lists that are instantiated under the control of the
 *                _PROTOTYPES macro. If this macro is defined, all function
 *                declarations have prototypes, otherwise they don't (their
 *                parameter lists are empty).
 *
 * HISTORY      : J. Langhout, 860524, created for MS-DOS/LATTICE-C 2.X.
 *                R. Kloet, 860915, port to UNIFIVE 1.2.
 *                J. Langhout, 870113, General revision, port to VAX/VMS and
 *                                     MS-DOS/LATTICE-C 3.0.
 *                G. Litjens, 870601, Upgrade X/OPEN Januari 1987
 *                J. Langhout, 870819, General Revision.
 *                F. Meulenbroeks, 871019,
 *                      generic version conform ANSI-C Feb 1987.
 *                F. Meulenbroeks, 871030,
 *                      Sun version adapted from generic version.
 *                F. Meulenbroeks, 881214,
 *                      adapted to conform ANSI-C Oct 1988.
 *                F. Meulenbroeks, 890911,
 *                      made sunos 4.0 version from sunos 3.4 version
 *                F. Meulenbroeks, 890919,
 *                      added #ifndef/#endif around all typedefs
 *                D.P. Snoeck Henkemans, 891108,
 *                      added the _PROTOTYPES and PAR() macros and 
 *                      added PAR() around all formal parameter-lists.
 *                D.P. Snoeck Henkemans, 901204,
 *                      adapted to sunos 4.0.x
 *                D.P. Snoeck Henkemans, 910402,
 *                      adapted to sunos 4.1
 *                D.P. Snoeck Henkemans, 920820,
 *                      adapted to SUN ANSI C compiler (acc)
 *                      replaced toupper and tolower macros by functions.
 */

/* Data Definitions: */

#ifdef __STDC__
/* acc compiler supports prototypes */

#define _PROTOTYPES

#else 
/* cc compiler does not support prototypes or const or volatile */

#ifndef const      
#define const
#endif

#ifndef volatile  
#define volatile 
#endif

#endif /* __STDC__ */

#ifndef PAR
/*
 * The PAR() macro:
 *
 * description   This macro is used to declare functions, using parameter-lists
 *               that can be used both by compilers that support prototypes
 *               and compilers that don't.
 *
 *               The way this is done is by declaring the functions in the
 *               following way:
 *
 *               extern <func name> PAR((<par 1> , .. , <par n>));
 *                                 
 *               (Don't forget the space and the double parentheses !)
 *
 * example       extern exit PAR((int status));
 *
 *               If the macro _PROTOTYPES is defined, this will expand into:
 *
 *               extern exit (int status);
 *
 *               If _PROTOTYPES is not defined, the declaration becomes:
 *
 *               extern exit ();
 */
 
#ifdef _PROTOTYPES
 
#define PAR(list)               list
 
#else /* _PROTOTYPES */
 
#define PAR(list)               ()
 
#endif /* _PROTOTYPES */

#endif /* PAR */


#ifndef _ASSERT
#define _ASSERT
/*
 * From assert.h:
 *
 * description   The macro assert tests a program validity assertion and
 *               prints a message on stderr if the assertion is false.
 *               The x argument can be any expression that yields a
 *               truth value.
 *
 *               Note that the macro generates no code if the NDEBUG symbol
 *               is defined.  Also note that the error message is actually
 *               generated by the function _assert.
 */

# ifdef NDEBUG
# define assert(ex) ((void) 0)
# else
/* Note: The following definitions may differ in various implementions */
# define assert(ex)                                   \
{   if (!(ex))                                        \
    {                                                 \
      fprintf(stderr,                                 \
              "Assertion failed: file %s, line %d\n", __FILE__, __LINE__);\
      exit(1);                                        \
    }                                                 \
} 
#endif  /* NDEBUG */

#endif /* _ASSERT */

#ifndef _CTYPE
#define _CTYPE
/*
 * From ctype.h: The various ASCII character manipulation macros,
 *
 *       isalnum(c)    non-zero if c is alpha or digit
 *       isalpha(c)    non-zero if c is alpha
 *       iscntrl(c)    non-zero if c is control character
 *       isdigit(c)    non-zero if c is a digit (0 to 9)
 *       isgraph(c)    non-zero if c is graphic (excluding blank)
 *       islower(c)    non-zero if c is lower case
 *       isprint(c)    non-zero if c is printable (including blank)
 *       ispunct(c)    non-zero if c is punctuation
 *       isspace(c)    non-zero if c is white space
 *       isupper(c)    non-zero if c is upper case
 *       isxdigit(c)   non-zero if c is a hexadecimal digit (0-9|A-F|a-f)
 *       tolower(c)    conversion from upper to lower case
 *       toupper(c)    conversion from lower to upper case
 */

/* Not ANSI-88, not X/OPEN-87, support for ctype.h macros */

#ifndef _U
#define _U      01      /* upper case flag */
#endif
#ifndef _L
#define _L      02      /* lower case flag */
#endif
#ifndef _N
#define _N      04      /* number flag */
#endif
#ifndef _S
#define _S      010     /* space flag */
#endif
#ifndef _P
#define _P      020     /* punctuation flag */
#endif
#ifndef _C
#define _C      040     /* control character flag */
#endif
#ifndef _X
#define _X      0100    /* hexa decimal flag */
#endif
#ifndef _B
#define _B      0200    /* blank flag */
#endif
/* end support ctype.h macros */

#ifdef __STDC__
extern unsigned char    _ctype_[];
#else
extern  char    _ctype_[];
#endif

/* Note: The following definitions may differ in various implementions */
#ifndef lint /* N.B.: Not ANSI 1988, it requires functions */
             /*       according to ANSI 1988 the parameter should be int */

/* character testing functions */

#ifndef isalnum
#define isalnum(c)      (int)((_ctype_+1)[c]&(_U|_L|_N))
#endif
#ifndef isalpha
#define isalpha(c)      (int)((_ctype_+1)[c]&(_U|_L))
#endif
#ifndef iscntrl
#define iscntrl(c)      (int)((_ctype_+1)[c]&_C)
#endif
#ifndef isdigit
#define isdigit(c)      (int)((_ctype_+1)[c]&_N)
#endif
#ifndef isgraph
#define isgraph(c)      (int)((_ctype_+1)[c]&(_P|_U|_L|_N))
#endif
#ifndef islower
#define islower(c)      (int)((_ctype_+1)[c]&_L)
#endif
#ifndef isprint
#define isprint(c)      (int)((_ctype_+1)[c]&(_P|_U|_L|_N|_B))
#endif
#ifndef ispunct
#define ispunct(c)      (int)((_ctype_+1)[c]&_P)
#endif
#ifndef isspace
#define isspace(c)      (int)((_ctype_+1)[c]&_S)
#endif
#ifndef isupper
#define isupper(c)      (int)((_ctype_+1)[c]&_U)
#endif
#ifndef isxdigit
#define isxdigit(c)     (int)((_ctype_+1)[c]&_X)
#endif

/* Character case mapping functions */

extern int tolower PAR((int c));
extern int toupper PAR((int c));

#endif  /* lint */

#endif /* _CTYPE */

#ifndef _ERRNO
#define _ERRNO
/*
 * From errno.h
 */

#ifndef EDOM
#define EDOM    33      /* Math arg out of domain of func       */
#endif  /* EDOM */

#ifndef ERANGE
#define ERANGE  34      /* Math result not representable        */
#endif  /* ERANGE */

extern  int errno;

#endif /* _ERRNO */

#ifndef _FLOAT
#define _FLOAT
/*
 * From float.h
 */

/* Note: The following definitions may differ in various implementions */

/* Note: the values given here are implementation dependent
 *       The values here are minimal values.
 *       See also the ANSI standard
 */

#ifndef FLT_RADIX
#define FLT_RADIX       ( 2 )
#endif
#ifndef FLT_ROUNDS
#define FLT_ROUNDS      ( -1 )
#endif

/* float */

#ifndef FLT_DIG
#define FLT_DIG         ( 6 )
#endif
#ifndef FLT_EPSILON
#define FLT_EPSILON     (1.192093E-07)
#endif
#ifndef FLT_MANT_DIG
#define FLT_MANT_DIG    ( 24 )
#endif
#ifndef FLT_MAX
#define FLT_MAX         (3.402823E+38)
#endif
#ifndef FLT_MAX_10_EXP
#define FLT_MAX_10_EXP  (38)
#endif
#ifndef FLT_MAX_EXP
#define FLT_MAX_EXP     (128)
#endif
#ifndef FLT_MIN
#define FLT_MIN         (1.401298E-45)
#endif
#ifndef FLT_MIN_10_EXP
#define FLT_MIN_10_EXP  (-45)
#endif
#ifndef FLT_MIN_EXP
#define FLT_MIN_EXP     (-150)
#endif

/* double */

#ifndef DBL_DIG
#define DBL_DIG         (15)
#endif
#ifndef DBL_EPSILON
#define DBL_EPSILON     (2.220446049250313E-16)
#endif
#ifndef DBL_MANT_DIG
#define DBL_MANT_DIG    (53)
#endif
#ifndef DBL_MAX
#define DBL_MAX         (1.797693134862316E+308)
#endif
#ifndef DBL_MAX_10_EXP
#define DBL_MAX_10_EXP  (308)
#endif
#ifndef DBL_MAX_EXP
#define DBL_MAX_EXP     (1024)
#endif
#ifndef DBL_MIN
#define DBL_MIN         (4.940656458412465E-324)
#endif
#ifndef DBL_MIN_10_EXP
#define DBL_MIN_10_EXP  (-324)
#endif
#ifndef DBL_MIN_EXP
#define DBL_MIN_EXP     (-1075)
#endif
        
/* long double */
/* does not exist on SUN: made the same as double */

#ifndef LDBL_DIG
#define LDBL_DIG        (15)
#endif
#ifndef LDBL_EPSILON
#define LDBL_EPSILON    (2.220446049250313E-16)
#endif
#ifndef LDBL_MANT_DIG
#define LDBL_MANT_DIG   (53)
#endif
#ifndef LDBL_MAX
#define LDBL_MAX        (1.797693134862316E+308)
#endif
#ifndef LDBL_MAX_10_EXP
#define LDBL_MAX_10_EXP (308)
#endif
#ifndef LDBL_MAX_EXP
#define LDBL_MAX_EXP    (1024)
#endif
#ifndef LDBL_MIN
#define LDBL_MIN        (4.940656458412465E-324)
#endif
#ifndef LDBL_MIN_10_EXP
#define LDBL_MIN_10_EXP (-324)
#endif
#ifndef LDBL_MIN_EXP
#define LDBL_MIN_EXP    (-1075)
#endif

#endif /* _FLOAT */

#ifndef _LIMITS
#define _LIMITS
/*
 * From limits.h
 */

/* Note: the values given here are implementation dependent
 *       The values here are minimal values.
 *       See also the ANSI standard
 */

/* char definitions */

#ifndef CHAR_BIT
#define CHAR_BIT        (8)
#endif
#ifndef CHAR_MAX
#define CHAR_MAX        (-128)
#endif
#ifndef CHAR_MIN
#define CHAR_MIN        (127)
#endif
#ifndef SCHAR_MAX
#define SCHAR_MAX       (-128)
#endif
#ifndef SCHAR_MIN
#define SCHAR_MIN       (127)
#endif
#ifndef UCHAR_MAX
#define UCHAR_MAX       (255)
#endif
#ifndef MB_LEN_MAX
#define MB_LEN_MAX       ( 1 )
#endif

/* short definitions */

#ifndef SHRT_MAX
#define SHRT_MAX        (32767)
#endif
#ifndef SHRT_MIN
#define SHRT_MIN        (-32768)
#endif
#ifndef USHRT_MAX
#define USHRT_MAX       ((unsigned short)65535)
#endif

/* integer definitions */

#ifndef INT_MAX
#define INT_MAX         (2147483647)
#endif
#ifndef INT_MIN
#define INT_MIN         (-2147483648)
#endif
#ifndef UINT_MAX
#define UINT_MAX        ((unsigned int)4294967295)
#endif

/* long definitions */

#ifndef LONG_MAX
#define LONG_MAX        (2147483647L)
#endif
#ifndef LONG_MIN
#define LONG_MIN        (-2147483648L)
#endif
#ifndef ULONG_MAX
#define ULONG_MAX       ((unsigned long)4294967295)
#endif

#endif /* _LIMITS */

#ifndef _LOCALE
#define _LOCALE
/*
 * From locale.h
 */

#ifndef LC_ALL
#define LC_ALL
#endif
#ifndef LC_COLLATE
#define LC_COLLATE
#endif
#ifndef LC_CTYPE
#define LC_CTYPE
#endif
#ifndef LC_MONETARY
#define LC_MONETARY
#endif
#ifndef LC_NUMERIC
#define LC_NUMERIC
#endif
#ifndef LC_TIME
#define LC_TIME
#endif

#ifndef _LCONV
typedef struct lconv
        {
                char *decimal_point;
                char *thousands_sep;
                char *grouping;
                char *int_curr_symbol;
                char *currency_symbol;
                char *mon_decimal_point;
                char *mon_thousands_sep;
                char *mon_grouping;
                char *positive_sign;
                char *negative_sign;
                char int_frac_digits;
                char frac_digits;
                char p_cs_precedes;
                char p_sep_by_space;
                char n_cs_precedes;
                char n_sep_by_space;
                char p_sign_posn;
                char n_sign_posn;
        }lconv;
#endif

extern char *setlocale PAR((int category, const char *locale));
extern struct lconv *localeconv PAR((void));

#endif /* _LOCALE */

#ifndef _MATH
#define _MATH
/*
 * From math.h
 */

/* SUN: made HUGE_VAL equal to DBL_MAX */
#ifndef HUGE_VAL
#define HUGE_VAL DBL_MAX  /* huge double value */
#endif

/* trigonometric functions */

extern double acos PAR((double x));
extern double asin PAR((double x));
extern double atan PAR((double x));
extern double atan2 PAR((double x, double y));
extern double cos PAR((double x));
extern double sin PAR((double x));
extern double tan PAR((double x));

/* hyperbolic functions */

extern double cosh PAR((double x));
extern double sinh PAR((double x));
extern double tanh PAR((double x));

/* exponential and logarithmic functions */

extern double exp PAR((double x));
extern double frexp PAR((double value, int *exp));
extern double ldexp PAR((double x, int exp));
extern double log PAR((double x));
extern double log10 PAR((double x));
extern double modf PAR((double value, double *iptr));

/* power functions */

extern double pow PAR((double base, double exp));
extern double sqrt PAR((double x));

/* nearest integer, absolute value and remainder functions */

extern double ceil PAR((double x));
extern double fabs PAR((double x));
extern double floor PAR((double x));
extern double fmod PAR((double x, double y));

#endif /* _MATH */

#include <setjmp.h>
#ifndef __sparc_setjmp_h
#define __sparc_setjmp_h
/*
 * From setjmp.h
 */

#ifndef _JMP_BUF
typedef int jmp_buf[ 58 ];
#endif

extern void longjmp PAR((jmp_buf env, int val));
extern int setjmp PAR((jmp_buf env));
#pragma unknown_control_flow(setjmp)

#endif /* __sparc_setjmp_h */

#ifndef _SIGNAL
#define _SIGNAL
/*
 * From signal.h
 */

/* Note: The following definitions may differ in various implementions */

#ifndef _SIG_ATOMIC_T
typedef int sig_atomic_t;
#endif

#ifndef SIGABRT
#define SIGABRT 6       /* process abort signal. Note that this is the */
#endif
                        /* former SIGIOT in UNIX System V Release 2.0  */

#ifndef SIGFPE
#define SIGFPE  8       /* floating point exception */
#endif
#ifndef SIGILL
#define SIGILL  4       /* illegal instruction, not reset when caught */
#endif
#ifndef SIGINT
#define SIGINT  2       /* interrupt (rubout) */
#endif
#ifndef SIGSEGV
#define SIGSEGV 11      /* segmentation violation */
#endif
#ifndef SIGTERM
#define SIGTERM 15      /* software termination signal from kill */
#endif
#ifndef SIG_DFL
#define SIG_DFL (void (*)())0
#endif
#ifndef SIG_ERR
#define SIG_ERR (void (*)())-1   /* represents the return value by signal */
#endif
#ifdef lint
#ifndef SIG_IGN
#define  SIG_IGN (void (*)())0
#endif
#else
#ifndef SIG_IGN
#define  SIG_IGN (void (*)())1
#endif
#endif   /* lint */

extern int raise PAR((int sig));
extern void (*signal PAR((int sig, void (*func)(int)))) PAR((int));

#endif /* _SIGNAL */

#ifndef _STDARG
#define _STDARG

#ifdef __GNUC__
#define _STDARG_H

/* This is just like the default gvarargs.h
   except for differences described below.  */

/* Make this a macro rather than a typedef, so we can undef any other defn.  */
#define va_list __va___list
#ifndef __svr4__
/* This has to be a char * to be compatible with Sun.
   i.e., we have to pass a `va_list' to vsprintf.  */
typedef char * __va___list;
#else
/* This has to be a void * to be compatible with Sun svr4.
   i.e., we have to pass a `va_list' to vsprintf.  */
typedef void * __va___list;
#endif

/* In GCC version 2, we want an ellipsis at the end of the declaration
   of the argument list.  GCC version 1 can't parse it.  */

#if __GNUC__ > 1
#define __va_ellipsis ...
#else
#define __va_ellipsis
#endif

#ifdef _STDARG_H
#define va_start(AP, LASTARG)					\
  (__builtin_saveregs (), AP = ((char *) __builtin_next_arg ()))
#else
#define va_alist  __builtin_va_alist
/* The ... causes current_function_varargs to be set in cc1.  */
#define va_dcl    int __builtin_va_alist; __va_ellipsis

#define va_start(AP) 						\
 (__builtin_saveregs (), (AP) = ((char *) &__builtin_va_alist))
#endif

#define va_end(pvar)

#define __va_rounded_size(TYPE)  \
  (((sizeof (TYPE) + sizeof (int) - 1) / sizeof (int)) * sizeof (int))

/* Avoid errors if compiling GCC v2 with GCC v1.  */
#if __GNUC__ == 1
#define __extension__
#endif

/* RECORD_TYPE args passed using the C calling convention are
   passed by invisible reference.  ??? RECORD_TYPE args passed
   in the stack are made to be word-aligned; for an aggregate that is
   not word-aligned, we advance the pointer to the first non-reg slot.  */
#define va_arg(pvar,TYPE)					\
__extension__							\
({ TYPE __va_temp;						\
   ((__builtin_classify_type (__va_temp) >= 12)			\
    ? ((pvar) += __va_rounded_size (TYPE *),			\
       **(TYPE **) ((pvar) - __va_rounded_size (TYPE *)))	\
    : __va_rounded_size (TYPE) == 8				\
    ? ({ union {TYPE d; int i[2];} u;				\
	 u.i[0] = ((int *) (pvar))[0];				\
	 u.i[1] = ((int *) (pvar))[1];				\
	 (pvar) += 8;						\
	 u.d; })						\
    : ((pvar) += __va_rounded_size (TYPE),			\
       *((TYPE *) ((pvar) - __va_rounded_size (TYPE)))));})


#else  /* No __GNUC__ */
/*
 * From stdarg.h
 */

#ifndef _VA_LIST
#ifdef __STDC__
typedef void *va_list;
#else
typedef char *va_list;
#endif
#endif

/* Note: The following definitions may differ in various implementions */
#ifndef va_arg
#ifdef __STDC__
#define va_arg(ap, mode) ((mode *)__builtin_va_arg_incr((mode *)ap))[0]
#else
#define va_arg(ap, mode) (((mode *)(ap += sizeof(mode)))[-1])
#endif
#endif
#ifndef va_end
#ifdef __STDC__
extern void va_end(va_list);
#define va_end(list) (void)0
#else
#define va_end(ap)       (ap = (va_list) NULL)
#endif
#endif
#ifndef va_start
#ifdef __STDC__
#define va_start(ap, parmN) (void) (ap = (va_list) &__builtin_va_alist)
#else
#define va_start(ap, parmN) (ap = ((va_list)(&parmN)) + sizeof(parmN))
#endif
#endif

#endif /* __GNUC__ */
#endif /* _STDARGS */

#ifndef _STDDEF
#define _STDDEF
/*
 * from stddef.h
 */

#ifndef __sys_stdtypes_h   /* SunOS 4.1 hack */
typedef	unsigned short	mode_t;		/* file mode bits */
#ifndef _PTRDIFF_T
typedef int ptrdiff_t;
#endif
#ifndef _SIZE_T
typedef unsigned long size_t;
#endif
#ifndef _WCHAR_T
#ifdef __STDC__
typedef long wchar_t;
#else
typedef unsigned short wchar_t;
#endif
#endif
#endif /* __sys_stdtypes_h */

#ifndef NULL
#define NULL            (void *)0
#endif
#ifndef offsetof
#define offsetof( type, identifier)                     \
        ((size_t)(&((type *) NULL)->identifier))
#endif

#endif /* _STDDEF */

#ifndef _STDIO
#define _STDIO
/*
 * From stdio.h
 */

#ifndef _IOFBF
#define _IOFBF  0
#endif
#ifndef _IOLBF
#define _IOLBF  0200
#endif
#ifndef _IONBF
#define _IONBF  04
#endif

#ifndef BUFSIZ
#define BUFSIZ  1024
#endif

#ifndef EOF
#define EOF             (-1)
#endif
#ifndef L_tmpnam
#define L_tmpnam        25
#endif

#ifndef SEEK_CUR
#define SEEK_CUR 1      /* set file pointer to current plus 'offset' */
#endif
#ifndef SEEK_END
#define SEEK_END 2      /* set file pointer to EOF plus 'offset' */
#endif
#ifndef SEEK_SET
#define SEEK_SET 0      /* set file pointer to 'offset' */
#endif
#ifndef TMP_MAX
#define TMP_MAX 17567   /* max no. of unique names generated by tmpnam(3S) */
#endif

/* Not ANSI-88, not X/OPEN-87, support for file functions. */
#ifndef _IOEOF
#define _IOEOF  0020
#endif
#ifndef _IOERR
#define _IOERR  0040
#endif
/* end support for file functions */

#ifndef FOPEN_MAX
#define FOPEN_MAX 30  /* maximum number of open files on system */
#endif

#ifndef FILENAME_MAX
#define FILENAME_MAX 1024 /* maximum guaranteed file name length */
#endif

extern  struct  _iobuf {
        int     _cnt;
        unsigned char *_ptr;
        unsigned char *_base;
        int     _bufsiz;
        short   _flag;
        char    _file;          /* should be short */
} _iob[];

#ifndef _FPOS_T
typedef long fpos_t;
#endif

/* Note: according to ANSI FILE should be a type instead of a define */

#ifndef FILE
#define FILE        struct _iobuf
#endif

#ifndef stderr
#define stderr      (&_iob[2])
#endif
#ifndef stdin
#define stdin       (&_iob[0])
#endif
#ifndef stdout
#define stdout      (&_iob[1])
#endif

/* Not ANSI-88, not X/OPEN-87, support for file functions. */
extern int _filbuf PAR((FILE *));
extern int _flsbuf PAR((int, FILE *));
/* end support for file functions */

/* operations on files */

#ifndef remove
extern int unlink PAR((const char *file_spec));
#define remove(file) unlink(file)
#endif  /* remove */

extern int rename PAR((const char *oldname, const char *newname));
extern FILE *tmpfile PAR((void));
extern char *tmpnam PAR((char *name));

/* file access functions */

extern int fclose PAR((FILE *stream));
extern int fflush PAR((FILE *stream));
extern FILE *fopen PAR((const char *filespec, const char *a_mode));
extern FILE *freopen PAR((const char *filespec, const char *a_mode,
                          FILE *stream));
extern void setbuf PAR((FILE *stream, char *buffer));
extern int setvbuf PAR((FILE *stream, char *buffer, int type, size_t size));


/* formatted input/output functions */

/* Note: The following definitions may differ in various implementions */
extern int fprintf PAR((FILE *stream, const char *format_spec, ...));
extern int fscanf PAR((FILE *stream, const char *format_spec, ...));
extern int printf PAR((const char *format_spec, ...));
extern int scanf PAR((const char *format_spec, ...));
/* SUN: changed function result from int to char *  */
extern char *sprintf PAR((char *str, const char *format_spec, ...));
extern int sscanf PAR((const char *str, const char *format_spec, ...));
extern int vfprintf PAR((FILE *stream, const char *format, va_list arg));
extern int vprintf PAR((const char *format, va_list arg));
/* SUN: changed function result from int to char *  */
extern char *vsprintf PAR((char *s, const char *format, va_list arg));

/* character input/output functions */

extern int fgetc PAR((FILE *stream));
extern char *fgets PAR((char *str, int maxchar, FILE *stream));
extern int fputc PAR((char character, FILE *stream));
extern int fputs PAR((const char *str, FILE *stream));

#ifndef lint
#ifndef getc
#define getc(p)         (--(p)->_cnt>=0? ((int)*(p)->_ptr++):_filbuf(p))
#endif
#ifndef getchar
#define  getchar()       getc(stdin)
#endif
#endif  /* lint */

extern char *gets PAR((char *str));

#ifndef lint
#ifndef putc
#define putc(x,p) (--(p)->_cnt>=0?                              \
                      (int)(*(p)->_ptr++=(unsigned char)(x)):   \
        (((p)->_flag & _IOLBF) && -(p)->_cnt < (p)->_bufsiz ?\
                ((*(p)->_ptr = (unsigned char)(x)) != '\n' ?\
                        (int)(*(p)->_ptr++) :\
                        _flsbuf(*(unsigned char *)(p)->_ptr, p)) :\
                _flsbuf((unsigned char)(x), p)))
#endif
#ifndef putchar
#define  putchar(x)      putc((x), stdout)
#endif
#endif  /* lint */

extern int puts PAR((const char *str));
extern int ungetc PAR((int character, FILE *stream));

/* direct input/output functions */

extern size_t fread PAR((void *ptr, size_t size_item,
                         size_t nr_items, FILE *strm));
extern size_t fwrite PAR((const void *ptr, size_t size_item,
                          size_t nr_items, FILE *strm));

/* file positioning functions */

extern int fgetpos PAR((FILE *stream, fpos_t *position));
extern int fseek PAR((FILE *stream, long offset, int direction));
extern int fsetpos PAR((FILE *stream, const fpos_t *position));
extern long ftell PAR((FILE *stream));
extern int rewind PAR((FILE *stream));

/* error-handling functions */

#ifndef lint
#ifndef clearerr
#define clearerr(p)     (void) ((p)->_flag &= ~(_IOERR|_IOEOF))
#endif
#ifndef feof
#define feof(p)         (((p)->_flag&_IOEOF)!=0)
#endif
#ifndef ferror
#define ferror(p)       (((p)->_flag&_IOERR)!=0)
#endif
#endif  /* lint */

extern void perror PAR((const char *str));

#endif /* _STDIO */

#ifndef _STDLIB
#define _STDLIB
/*
 * from stdlib.h
 */

/* According to the ANSI standard the macro's ERANGE and HUGE_VAL are
   to be defined here. However, these macro's are also define in math.h,
   and thus defining them again here would lead to possible erroneous
   situations. Therefore they are omitted here.
 */

#ifndef EXIT_FAILURE
#define EXIT_FAILURE    ( 1 )
#endif
#ifndef EXIT_SUCCESS
#define EXIT_SUCCESS    ( 0 )
#endif
#ifndef RAND_MAX
#define RAND_MAX        INT_MAX
#endif
#ifndef MB_CUR_MAX
#define MB_CUR_MAX      ( 1 )
#endif

#ifndef _DIV_T
typedef struct
        {       int quot;       /* quotient */
                int rem;        /* remainder */
        }div_t;
#endif

#ifndef _LDIV_T
typedef struct
        {       long quot;      /* quotient */
                long rem;       /* remainder */
        }ldiv_t;
#endif

/* string conversion functions */

extern double atof PAR((const char *nptr));
extern int atoi PAR((const char *nptr));
extern long atol PAR((const char *nptr));
extern double strtod PAR((const char *nptr, char **endptr));
extern long strtol PAR((const char *nptr, char **endptr, int base));
extern unsigned long strtoul PAR((const char *nptr, char **endptr, int base));

/* pseudo-random sequence generation functions */

extern int rand PAR((void));
extern void srand PAR((unsigned int seed));

/* memory management functions */

extern char *calloc PAR((size_t nmemb, size_t size));
extern int free PAR((void *ptr)); 
extern char *malloc PAR((size_t size));
extern char *realloc PAR((void *ptr, size_t size));

/* communication with the environment */

extern void abort PAR((void));
extern int atexit PAR((void (*func)(void))); /* The normal declaration */
extern void exit PAR((int status));
extern char *getenv PAR((const char *name));
extern int system PAR((const char *string));

/* searching and sorting utilities */

extern void *bsearch PAR((const void *key, const void *base, size_t nmemb,
                          size_t size,int(*compar)(const void *,const void *)));
extern int qsort PAR((void *base, size_t nmemb, size_t size,
                       int (*compar)(const void *, const void *)));

/* integer arithmetic functions */

extern int abs PAR((int j));
extern div_t div PAR((int numer, int denom));
extern long labs PAR((long j));
extern ldiv_t ldiv PAR((long numer, long denom));

/* multibyte character functions */

extern int mblen PAR((const char *s, size_t n));
extern int mbtowc PAR((wchar_t *pwc, const char *s, size_t n));
extern int wctomb PAR((char *s, wchar_t wchar));

/* multibyte string functions */

extern size_t mbstowcs PAR((wchar_t *pwc, const char *s, size_t n));
extern size_t wcstombs PAR((char *s, const wchar_t *pwcs, size_t n));

#endif /* _STDLIB */

#ifndef _STRING
#define _STRING
/*
 * From string.h:
 */

/* copying functions */

#if __GNUC__ == 2 & __GNUC_MINOR__ == 5
extern char *memcpy ();
#else
extern void *memcpy PAR((void *s1, const void *s2, size_t size));
#endif
extern void *memmove PAR((void *s1, const void *s2, size_t size));
extern char *strcpy PAR((char *s1, const char *s2));
extern char *strncpy PAR((char *s1, const char *s2, size_t n));

/* concatenation functions */

extern char *strcat PAR((char *s1, const char *s2));
extern char *strncat PAR((char *s1, const char *s2, size_t n));

/* comparison functions */

#if __GNUC__ == 2 & __GNUC_MINOR__ == 5
extern int memcmp ();
#else
extern int memcmp PAR((const void *s1, const void *s2, size_t size));
#endif
extern int strcmp PAR((const char *s1, const char *s2));
extern int strcoll PAR((const char *s1, const char *s2));
extern int strncmp PAR((const char *s1, const char *s2, size_t n));
extern size_t strxfrm PAR((char *s1, const char *s2, size_t n));

/* search functions */

extern char *memchr PAR((const char *s1, int c, size_t size));
extern char *strchr PAR((const char *s, int character));
extern size_t strcspn PAR((const char *s1, const char *s2));
extern char *strpbrk PAR((const char *s1, const char *s2));
extern char *strrchr PAR((const char *s, int character));
extern size_t strspn PAR((const char *s1, const char *s2));
extern char *strstr PAR((const char *s1, const char *s2));
extern char *strtok PAR((char *s1, const char *s2));

/* miscellaneous functions */

extern char *memset PAR((char *s, int character, size_t size));
extern char *strerror PAR((int errnum));
extern size_t strlen PAR((const char *s));

#endif /* _STRING */

#ifndef _TIME
#define _TIME
/*
 * From time.h
 */

#ifndef CLK_TCK
#define CLK_TCK 1000000      /* no. of clock ticks per second */
#endif

#ifndef __sys_stdtypes_h     /* SunOS 4.1 hack */
#ifndef _CLOCK_T
typedef long clock_t;
#endif
#ifndef _TIME_T
typedef long time_t;
#endif
#endif /* __sys_stdtypes_h  */

struct  tm {    /* see ctime(3) */
        int     tm_sec;         /* seconds after the minute - [0,59] */
        int     tm_min;         /* minutes after the hour - [0,59] */
        int     tm_hour;        /* hours since midnight - [0,23] */
        int     tm_mday;        /* day of the month - [1,31] */
        int     tm_mon;         /* months since January - [0,11] */
        int     tm_year;        /* years since 1900 */
        int     tm_wday;        /* days since Sunday - [0,6] */
        int     tm_yday;        /* days since January 1 - [0,365] */
        int     tm_isdst;       /* Daylight Savings Time flag */
        /* Warning: only the fields mentioned above are guaranteed
           to exist by ANSI X3J11 */
        char   *tm_zone;        /* abbreviation of timezone name */
        long    tm_gmtoff;      /* offset from GMT in seconds */
};

/* time manipulation functions */

extern clock_t clock PAR((void));
extern double difftime PAR((time_t time1, time_t time0));
extern time_t mktime PAR((struct tm *timeptr));
extern time_t time PAR((time_t *time_location));

/* time conversion functions */

extern char *asctime PAR((const struct tm *timeptr));
extern char *ctime PAR((const time_t *bintim));
extern struct tm *gmtime PAR((const time_t *timer)); 
extern struct tm *localtime PAR((const time_t *bintim)); 
extern size_t strftime PAR((char *s1, size_t maxsize, const char *format,
                            const struct tm *time));

#endif /* _TIME */

#ifndef __sys_stdtypes_h	/* SUN hack */
typedef	int		sigset_t;	/* signal mask - may change */
#endif

#define __sys_stdtypes_h	/* Lex : SUN hack */

#endif /* _ANSI */
