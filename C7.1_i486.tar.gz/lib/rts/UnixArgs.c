/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef __SYSTEM
#include "SYSTEM.h"
#endif

#ifndef __Strings
#include "Strings.h"
#endif

#ifndef __MyStorage
#include "MyStorage.h"
#endif

#ifndef __UnixArgs
#include "UnixArgs.h"
#endif

int UnixArgs_Argc;
string *UnixArgs_Argv;

int UnixArgs_NoOfArguments (void)
{
  return (UnixArgs_Argc);
} /* NoOfArguments */

string UnixArgs_GetArgument (int argNr)
{ if ((argNr < 0) OR (argNr >= UnixArgs_Argc)) { return ((string)NULL); }
  return (UnixArgs_Argv[argNr]);
} /* GetArgument */

static Char empty[1];

string UnixArgs_GetEnvVariable (string name)
{ string env;
  env = (string)getenv ((char*)name);
  if (env EQ (string)NULL)
  { empty[0] = '\0';
    return (empty);
  }
  else return (env);
} /* GetEnvVariable */

void UnixArgs_Init (int argc, Char *argv[])
{ 
  UnixArgs_Argc = argc;
  UnixArgs_Argv = argv;
  MyStorage_GC_Set_Global (&UnixArgs_Argv);
}

void UnixArgs_InitGlobals (void) {}
 /* END UnixArgs */
