/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef __SYSTEM
#include "SYSTEM.h"
#endif

#ifndef __MyStorage
#include "MyStorage.h"
#endif

#ifndef __TextIO
#include "TextIO.h"
#endif

#ifndef __UnixProcess
#include "UnixProcess.h"
#endif

#ifndef __SysStreams
#include "SysStreams.h"
#endif

#ifndef __SystemTypes
#include "SystemTypes.h"
#endif

/*************** Alignment ***************/

#define OBJECT_ALIGN  MyStorage_ALIGNMENT
#define POINTER_ALIGN SIZE_pointer

#define ALIGN_UP(p,a) ((((cardinal)(p) + (a)-1) / (a)) * (a))
#define ALIGN_DO(p,a) ((((cardinal)(p)) / (a)) * (a))

/*************** GC configuration ***************/

/*
Each pointer is associated with NUM_BITS bits that describe its
GC properties.
These bits are packed in words, the words in an array of 
size MAP_SIZE, called a map and the maps in another array of size 
NUM_MAPS.
The bits of the pointer are used as indices in this structure to
access the GC bits.

               |..  MAP_SIZE ................................|
	                      |... NUM_BITS ..| OBJECT_ALIGN |
--------------------------------------------------------------
| index of map | index in map | index of bits | object align |
--------------------------------------------------------------

*/

#define _DEBUG 0
#define _STATISTICS 0

#define GC_THRESHOLD (0x1 << 20)

#ifndef MAP_SIZE
#define MAP_SIZE (0x1<<22)	/* 4 M, size of a map */
#endif

#ifndef NUM_MAPS
#define NUM_MAPS (0x1<<12)	/* Number of maps, 4 M * 4k = 16G */
#endif

#define NUM_BITS 4		/* Number of GC bits per pointer */
#define OBJ_BIT  0x1		/* Is an object */
#define FREE_BIT 0x2		/* Is free */
#define MARK_BIT 0x4		/* Is marked */
#define MEMO_BIT 0x8 		/* Memoized object */
#define ALL_BITS ((0x1 << NUM_BITS) - 1)

/* Size of one map in bytes */
#define MAP_BYTES (NUM_BITS * MAP_SIZE / (MyStorage_BYTESPERWORD * OBJECT_ALIGN))

#define NUM_WINDOWS 64		/* Max number of register windows */

/*
The memory allocator uses a table of free objects, indexed by size
(0..FREE_TABLE_SIZE-1)*OBJECT_ALIGN. 
Index FREE_TABLE_SIZE is used to store all the larger objects.
*/

#define FREE_TABLE_SIZE 128	/* Free table size */

/*************** GC data structures ***************/

/* List of allocated blocks of memory. This is the header of a block. */

typedef struct gc_block {
  cardinal size;
  struct gc_block *next;
} gc_block;

static gc_block *first_block = NULL, *last_block = NULL;

static int gc_block_size = 0;

/* By default, the GC is off. */
static void* (*malloc_func) (cardinal size) = &malloc;
static void skip (void);
static void (*run_gc) (void) = &skip;

static cardinal gc_prio  = GC_THRESHOLD;
static cardinal needs_gc = GC_THRESHOLD;
static bool     wants_gc = FALSE;
static cardinal num_gcs  = 0;

static cardinal heap_lo   = UINT_MAX, heap_hi   = 0,
                stack_lo  = UINT_MAX, stack_hi  = 0;
#if 0
                global_lo = UINT_MAX, global_hi = 0;
#endif

/* The maps */
static cardinal *maps[NUM_MAPS];
static cardinal map_lo = 0; /* Range of valid indices in maps */
static cardinal map_hi = 0;

/* The structure of free objects */
typedef struct free_obj {
  struct free_obj *next;
  cardinal size;
} free_obj;

static free_obj *free_table[FREE_TABLE_SIZE+1] = { NULL };

/* All globals must be reported to the GC by 
   MyStorage_GC_Set_Globals and are stored in this structure.
*/

typedef struct global_list {
  void *lo;			/* Address range of global */
  void *hi;
  bool memo_table;
  struct global_list *next;	/* Next one */
} global_list;

static global_list *global_addresses;	/* All globals */
bool MyStorage_CollectIdent;
bool MyStorage_CollectMemo;

/*************** GC access macros ***************/

/* Macro's to access the GC bits for a pointer. */

/* Index of map */
#define MAPI(b) (((cardinal)(b) - heap_lo) / MAP_SIZE)
#define MAPR(b) ((((cardinal)(b) - heap_lo) % MAP_SIZE) / OBJECT_ALIGN)

/* Index of word in map */
#define MAPRI(b) (MAPR(b) / (Machines_BITSPERWORD / NUM_BITS))
#define MAPRR(b) (MAPR(b) % (Machines_BITSPERWORD / NUM_BITS))

#define MAP(b) (maps[MAPI(b)])

#define MAP_MASK(b,m) ((cardinal)b % OBJECT_ALIGN != 0 || MAP(b)==NULL ? 0 : \
                     ((MAP(b) [MAPRI(b)]) & \
                      ((m) << (NUM_BITS * MAPRR(b))) \
                    ))

#define SET_MASK(b,m) ((cardinal)b % OBJECT_ALIGN != 0 || MAP(b)==NULL ? 0 : \
                     ((MAP(b) [MAPRI(b)]) |= \
                      ((m) << (NUM_BITS * MAPRR(b))) \
                    ))

#define CLR_MASK(b,m) ((cardinal)b % OBJECT_ALIGN != 0 || MAP(b)==NULL ? 0 : \
                     ((MAP(b) [MAPRI(b)]) &= \
                      ~((m) << (NUM_BITS * MAPRR(b))) \
                    ))

/* Individual bits per pointer */
#define  IS_OBJECT(b) MAP_MASK(b,OBJ_BIT)
#define SET_OBJECT(b) SET_MASK(b,OBJ_BIT)

#define  IS_MARKED(b) MAP_MASK(b,MARK_BIT)
#define SET_MARKED(b) SET_MASK(b,MARK_BIT)
#define CLR_MARKED(b) CLR_MASK(b,MARK_BIT)

#define  IS_FREE(b) MAP_MASK(b,FREE_BIT)
#define SET_FREE(b) SET_MASK(b,FREE_BIT)
#define CLR_FREE(b) CLR_MASK(b,FREE_BIT)

#define  IS_MEMO(b) MAP_MASK(b,MEMO_BIT)
#define SET_MEMO(b) SET_MASK(b,MEMO_BIT)
#define CLR_MEMO(b) CLR_MASK(b,MEMO_BIT)

#define IS_MARKED_OR_FREE(b) MAP_MASK(b,FREE_BIT|MARK_BIT)

#if _DEBUG
cardinal mapi (cardinal b) { return MAPI(b); }
cardinal mapr (cardinal b) { return MAPR(b); }

bool is_free_obj (cardinal b) { return IS_FREE(b); }
bool is_marked (cardinal b) { return IS_MARKED(b); }
bool is_object (cardinal b) { return IS_OBJECT(b); }
#endif

#if _STATISTICS
static cardinal num_marked;
static cardinal num_sweep = 0;
static cardinal num_free = 0;
#endif


/************** Heap status *********/

address  MyStorage_Bottom;
address  MyStorage_Top;
static cardinal MyStorage_left, 
                MyStorage_blocks, MyStorage_large,
                heapspace = 0;

extern void MyStorage_Exceeded (void);

#define mask (MyStorage_ALIGNMENT-1)

/************** Line number tracking *********/

/* Experimental, not yet in use */

char *MyStorage_filename;
int   MyStorage_linenum;

#if TRACK_LINES
static int indent = 0;

typedef struct Line_Heap_Block {
  char *file;
  int line;
  address rest[1];
} Line_Heap_Block ;

static address
fill_line (address adr)
#define BLOCK_OFFSET offsetof(Line_Heap_Block,rest)
{ Line_Heap_Block *base = (void*)((cardinal)adr - BLOCK_OFFSET);
  base->file = MyStorage_filename;
  base->line = MyStorage_linenum;
  return adr;
}
#else
#define BLOCK_OFFSET 0
#define fill_line(adr) (adr)
#endif

/************** Allocation *********/

/* Find large object in free_table[FREE_TABLE_SIZE] */

static address
get_large_object (cardinal size)
{
  free_obj *p, **q;
  
  for (q = &free_table[FREE_TABLE_SIZE], p = *q ; p!=NULL; q = &p->next, p = *q) {
    if (p->size != size) continue;
    *q = p->next;
#if _STATISTICS
    num_free--;
#endif
    return p;
  }
  return NULL;
}

/* Basic memory allocation function */

address MyStorage__ALLOCATE (cardinal units)
{ register address adr;

  /* Alignment */
  cardinal needed = ALIGN_UP(units, OBJECT_ALIGN);
  
  if (wants_gc) {
    cardinal s = (needed+BLOCK_OFFSET) / OBJECT_ALIGN;
    adr = NULL;
    
    /* Look in free table first */
    if (s < FREE_TABLE_SIZE) {
      if (free_table[s] != NULL) {
        adr = free_table[s];
        free_table[s] = free_table[s]->next; 
        CLR_FREE(adr);
#if _STATISTICS
        num_free--;
#endif
#if _DEBUG > 2
        printf ("     Recycled 0x%p %d\n", adr, needed);
        fflush(stdout);
#endif
        return fill_line(adr);
      }
    } else {
      if (free_table[FREE_TABLE_SIZE] != NULL) {
        adr = get_large_object (needed+BLOCK_OFFSET);
      }
      if (adr != NULL) { 
        CLR_FREE(adr); 
#if _DEBUG > 2
        printf ("     Recycled 0x%p %d\n", adr, needed);
        fflush(stdout);
#endif
	return fill_line(adr); 
      }
    }
  }
  
  /* Not in free table, allocate it */
  if (MyStorage_left < needed+BLOCK_OFFSET)
  { 
    /* Object does not fit in current block */
    if (wants_gc && gc_prio > 0 && needs_gc > gc_prio) {
      run_gc ();
      return MyStorage__ALLOCATE (needed);
    }
    
    if (needed+BLOCK_OFFSET > MyStorage_BlockSize)
    { 
      /* Very large object, allocate as a separate block */
      adr = malloc_func (needed + BLOCK_OFFSET);
      adr = (address)((cardinal)adr+BLOCK_OFFSET);
      if (adr EQ NULL) { MyStorage_Exceeded (); }
      MyStorage_large += needed;
      MyStorage_GC_Set_Heap (adr, needed);
      if (wants_gc) { needs_gc += needed; SET_OBJECT(adr); }
      return fill_line(adr);
    }
    
    /* Allocate new block */
    MyStorage_Top = malloc_func (MyStorage_BlockSize);
      if (MyStorage_Top EQ NULL) { MyStorage_Exceeded (); }
    MyStorage_blocks++;
    MyStorage_left = MyStorage_BlockSize;
  }
  
  /* Object fits in current block */
  adr = MyStorage_Top;
  MyStorage_Top = (address)((cardinal)MyStorage_Top + needed + BLOCK_OFFSET);
  adr = (address)((cardinal)adr+BLOCK_OFFSET);
  MyStorage_left -= needed+BLOCK_OFFSET;
  if ((cardinal)adr+needed > heap_hi) heap_hi = (cardinal)adr+needed;
#if _DEBUG > 2
  printf ("     ALLOCATE 0x%p %d\n", adr, needed);
  fflush(stdout);
#endif
  if (wants_gc) { needs_gc += needed; SET_OBJECT(adr); }
#if _DEBUG
  if ((cardinal)adr % OBJECT_ALIGN != 0) {
    printf ("Object alignment error1\n");
    exit (1);
  }
#endif
  return fill_line(adr);
} /* ALLOCATE */

/* Assume alignment and needed <= MyStorage_BlockSize */

address MyStorage__Fast_ALLOCATE (cardinal needed)
{ register address adr;
  
  if (wants_gc) {
    cardinal s = (needed+BLOCK_OFFSET) / OBJECT_ALIGN;
    adr = NULL;

    /* Look in free table first */
    if (s < FREE_TABLE_SIZE) {
      if (free_table[s] != NULL) {
        adr = free_table[s];
        free_table[s] = free_table[s]->next; 
        CLR_FREE(adr);
#if _STATISTICS
        num_free--;
#endif
#if _DEBUG > 2
        printf ("     Recycled 0x%p %d\n", adr, needed);
        fflush(stdout);
#endif
        return fill_line(adr);
      }
    } else {
      if (free_table[FREE_TABLE_SIZE] != NULL) {
        adr = get_large_object (needed+BLOCK_OFFSET);
      }
      if (adr != NULL) { 
        CLR_FREE(adr); 
#if _DEBUG > 2
        printf ("     Recycled 0x%p %d\n", adr, needed);
        fflush(stdout);
#endif
	return fill_line(adr); 
      }
    }
  }

  /* Not in free table, allocate it */
  if (MyStorage_left < needed+BLOCK_OFFSET)
  { 
    /* Object does not fit in current block */
    if (wants_gc && gc_prio > 0 && needs_gc > gc_prio) {
      run_gc ();
      return MyStorage__Fast_ALLOCATE (needed+BLOCK_OFFSET);
    }

    /* Allocate new block */
    MyStorage_Top = malloc_func (MyStorage_BlockSize); 
    if (MyStorage_Top EQ NULL) { MyStorage_Exceeded (); }
    MyStorage_blocks++;
    MyStorage_left = MyStorage_BlockSize;
  }

  /* Object fits in current block */
  adr = MyStorage_Top;
  MyStorage_Top = (address)((cardinal)MyStorage_Top + needed + BLOCK_OFFSET);
  adr = (address)((cardinal)adr+BLOCK_OFFSET);
  MyStorage_left -= needed+BLOCK_OFFSET;
  if ((cardinal)adr+needed > heap_hi) heap_hi = (cardinal)adr+needed;
#if _DEBUG > 2
  printf ("Fast_ALLOCATE 0x%p %d\n", adr, needed);
  fflush(stdout);
#endif
  if (wants_gc) {
#if _DEBUG
    if (IS_OBJECT(adr)) { printf ("already an object\n"); exit (1); }
#endif
    needs_gc += needed;
    SET_OBJECT(adr);
#if _DEBUG
    if (!IS_OBJECT(adr)) { printf ("not an object 0x%p\n", adr); exit (1); }
    if (IS_OBJECT((char*)adr + OBJECT_ALIGN)) 
    { cardinal b = (cardinal)adr + OBJECT_ALIGN;
      printf ("next an object 0x%p\n", &(MAP(b)[(MAPR(b) ) / MyStorage_BYTESPERWORD]));
      exit (1); 
    }
#endif
  }
  return fill_line(adr);
} /* Fast_ALLOCATE */

void MyStorage_Exceeded (void)
{ TextIO_WriteString (SysStreams_sysErr, (string)"Heapspace exceeded.....");
  TextIO_NewLine (SysStreams_sysErr);
  TextIO_WriteINTEGER (SysStreams_sysErr, MyStorage_HeapSize ());
  TextIO_WriteString (SysStreams_sysErr, (string)" bytes heapspace used");
  TextIO_NewLine (SysStreams_sysErr);
  TextIO_Flush (SysStreams_sysErr);
  UnixProcess_Exit (UnixProcess_Failure);
} /* Exceeded */

void MyStorage_DEALLOCATE (address adr, cardinal units)
{ } /* DEALLOCATE */

int MyStorage_HeapSize (void)
{ 
  if (wants_gc) return heapspace;
  return((int)(MyStorage_large + MyStorage_blocks * MyStorage_BlockSize - 
         MyStorage_left));
} /* HeapSize */

/************** GC functions *********/

static void sweep (void);

#if _DEBUG
static cardinal
object_size (void *p)
{
  cardinal b = (cardinal)p;
  for (b = b+OBJECT_ALIGN; !IS_OBJECT(b) && b < heap_hi; b +=OBJECT_ALIGN) {}
  return (b - (cardinal)p);
}
#endif

/* Allocate maps for pointers b .. b+size */

static void
get_maps (cardinal b, cardinal size)
{
  cardinal map_l = MAPI(b);
  cardinal map_h = MAPI(b+size-1);
  cardinal i, end;
  
  if (map_h >= NUM_MAPS) MyStorage_Exceeded ();
  for (; map_l <= map_h; map_l++) {
    if (maps[map_l] != NULL) continue;
    maps[map_l] = calloc (MAP_BYTES, 1);
    heapspace += MAP_BYTES;
    end = (cardinal)(maps[map_l])+MAP_SIZE / (MyStorage_BYTESPERWORD * OBJECT_ALIGN);
#if _DEBUG > 1
    printf ("calloced 0x%x bytes\n", MAP_BYTES);
    printf ("map[%d] = 0x%p .. 0x%p\n", map_l, maps[map_l], (void*)end);
    fflush(stdout);
#endif
    if (map_l < map_lo) map_lo = map_l;
    if (map_l > map_hi) map_hi = map_l;
    
    /* Recursively, get the map for the map. */
    get_maps ((cardinal)maps[map_l], 1);
    
    /* Set maps[map_l] to be an object prevents the object in front of it to
       overrun it. Setting it free prevents recycling of it.
    */
    for (i = (cardinal)maps[map_l]; i < end; i += OBJECT_ALIGN) {
      SET_OBJECT (i);
      SET_FREE   (i);
    }
  }
}

/* Allocate a new block */

static void*
malloc_block (cardinal size)
{ 
  void *b;
  gc_block *p;
  cardinal needed = ALIGN_UP((size_t)size + gc_block_size + OBJECT_ALIGN, OBJECT_ALIGN);
  
  b = (address) malloc (needed);
  heapspace += needed;
  if (b==NULL) return NULL;
  p = b;
    
  /* Fill in the header */
  p->size = size;
  p->next = NULL;
  if (first_block == NULL) {
    first_block = p;
    last_block = p;
  } else {
    last_block->next = p;
    last_block = p;
  }
  b = (void*)(ALIGN_UP((char*)b + gc_block_size, OBJECT_ALIGN));

  /* p points to the gc_block, b to the contents */
  if ((cardinal)b < heap_lo) {
    /* Shift maps, not implement yet
       Assume malloc gives increasing addresses.
    */
  }
#if _DEBUG > 1
  printf ("malloc_block 0x%p .. 0x%p\n", b, (char*)b + size);
  fflush(stdout);
#endif

  /* Allocate the maps for this block */
  get_maps ((cardinal)b, size);
#if _DEBUG
  /* Check that the map is empty */
  {
    cardinal x; 
    for (x = 0; x < size; x += OBJECT_ALIGN) {
      if (IS_OBJECT((char*)b+x)) {
        printf ("map error for 0x%x\n", (cardinal)b+x);
        exit (1);
      }
    }
  }
  if ((cardinal)b % OBJECT_ALIGN != 0) {
    printf ("Object alignment error\n");
    exit (1);
  }
#endif
  /* Setting the last object prevents the object in front of it to
     overrun it. Setting it free prevents recycling of it.
  */
  SET_OBJECT (ALIGN_DO((cardinal)b + size + OBJECT_ALIGN, OBJECT_ALIGN));
  SET_FREE   (ALIGN_DO((cardinal)b + size + OBJECT_ALIGN, OBJECT_ALIGN));
  return b;
}

#if _DEBUG
static void
test_pointer (cardinal p)
{
  if (p > heap_hi && p-heap_hi < 200) {
    printf ("mark of 0x%x > heap_hi=0x%x, top = 0x%x\n", p, heap_hi, (cardinal)MyStorage_Top);
    fflush(stdout);
  }
}
#else
#define test_pointer(p)
#endif

/* Mark an object if it is a valid pointer */

#define mark(p) \
  { test_pointer(p); \
    if ((cardinal)(p) % POINTER_ALIGN == 0 && \
      min_heap <= (cardinal)(p) && (cardinal)(p) <= max_heap && \
      ((p1 = ALIGN_DO (p, OBJECT_ALIGN)) != p || !IS_MARKED_OR_FREE(p1))) { \
      s = _mark(p1, min_heap, max_heap); \
      if (s < s_lim) s_lim = s; \
  } }

/* p is a valid pointer, mark it and recurse on ids kids.
   returns the the lowest stack pointer used.
*/

static cardinal
_mark (cardinal p, cardinal min_heap, cardinal max_heap)
{
  cardinal s_lim = ALIGN_UP(&s_lim, POINTER_ALIGN);
  cardinal s;
  cardinal p1, q;
  
#if 0
  cardinal i;
  cardinal r = ALIGN_UP (p, OBJECT_ALIGN);
  for (i=map_lo; i <= map_hi; i++) {
    if (maps[i] != NULL && (cardinal)maps[i] <= r && 
        q < (cardinal)maps[i] + NUM_BITS*MAP_SIZE / (MyStorage_BYTESPERWORD*OBJECT_ALIGN)) return s_lim;
  }
#endif

  if (!IS_OBJECT(p)) {
    /* p points within an object. Search for the containing object. */
    while (!IS_OBJECT(p) && p >= heap_lo) { p -= OBJECT_ALIGN; }
    if (p < heap_lo || IS_MARKED_OR_FREE(p)) return s_lim;
  }
  SET_MARKED(p);
#if TRACK_LINES
  { Line_Heap_Block *base = (void*)((cardinal)p - BLOCK_OFFSET);
    int i;
    if (indent==0) printf ("\nROOT ");
    for (i=0; i < indent; i++) printf ("  ");
    printf ("%p\t%s\tline %d\n", p, base->file, base->line);
  }
  indent++;
#endif
#if _STATISTICS
  num_marked ++;
#endif
#if _DEBUG > 1
  printf ("Marked pointer 0x%x, size = %d\n", p, object_size((void*)p));
  fflush(stdout);
#endif

  /* Mark all pointers within p */
  q = p;
  if (MyStorage_CollectMemo && IS_MEMO(p)) {
    /* Skip link field in memo objects */
    q += POINTER_ALIGN;
    while (!IS_OBJECT(q)) {
      mark (*(cardinal*)q);
      q += POINTER_ALIGN;
    }
  } else {
    do {
      if (OBJECT_ALIGN == 2*POINTER_ALIGN) {
	mark (*(cardinal*)q);
	q += POINTER_ALIGN;
	mark (*(cardinal*)q);
	q += POINTER_ALIGN;
      } else {
	mark (*(cardinal*)q);
	q += POINTER_ALIGN;
      }
    } while (!IS_OBJECT(q));
  }
#if TRACK_LINES
  indent--;
#endif
  /* Return the stack limit */
  return s_lim;
}

/* Mark all pointers from lo..hi */

static cardinal
mark_region (cardinal lo, cardinal hi)
{
  cardinal s_lim = ALIGN_UP(&s_lim, POINTER_ALIGN);
  cardinal p, p1;
  cardinal min_heap = heap_lo;
  cardinal max_heap = (cardinal)MyStorage_Top < heap_hi ? (cardinal)MyStorage_Top : heap_hi;
  cardinal s;

#if _DEBUG
  printf ("  region 0x%x .. 0x%x\n", lo, hi);
  fflush(stdout);
#endif
  for (p = ALIGN_DO (lo, POINTER_ALIGN); p <= hi; p += POINTER_ALIGN) {
    if (p == (cardinal)&MyStorage_Bottom || 
        p == (cardinal)&MyStorage_Top || 
        p == (cardinal)&first_block || 
        p == (cardinal)&last_block || 
        p == (cardinal)&heap_lo || 
        p == (cardinal)&heap_hi || 
        p == (cardinal)&stack_lo || 
        p == (cardinal)&stack_hi || 
        p == (cardinal)&global_addresses || 
        p == (cardinal)&maps) continue;
    mark (*(cardinal*)p);
  }
  return s_lim;
}

/* Store object p with its size in the free table */

static void
give_free (cardinal p, cardinal size)
{
  free_obj *f = (void*)p;
  cardinal s = size / OBJECT_ALIGN;
  
#if _DEBUG > 1
  printf ("  free %s 0x%x, size %d\n", IS_MEMO(p)?"memo":"", p, size);
  fflush (stdout);
#endif
#if _DEBUG
  if (!IS_FREE(p)) {
    printf ("  0x%x is not free\n", p);
    exit (1);
  }
  { int *end = (int*)((int)f+s);
    int *q;
    for (q = (void*)&f[1]; q < end; q++) *q = 0;
  }
#endif
  CLR_MEMO(p);
  if (s >= FREE_TABLE_SIZE) {
    f->size = size;
    s = FREE_TABLE_SIZE;
  }
  f->next = free_table[s];
  free_table[s] = f;
#if _STATISTICS
  num_free++;
#endif
}

/* Collect memo tables */

typedef struct memo { struct memo *link; } memo;
  
static memo*
_sweep_memo (memo *m)
{ if (m == NULL) return m;
  m->link = _sweep_memo(m->link);
#if _DEBUG
  assert (IS_OBJECT (m));
  assert (IS_MEMO (m));
  printf ("Removing from memo table 0x%p\n", m);
  fflush (stdout);
#endif
  if (!IS_MARKED(m)) {
    return m->link;
  }
  return m;
}

static void
sweep_memo (void)
{ global_list *p;
  memo **q;
  
  if (!MyStorage_CollectMemo) return;
  for (p = global_addresses; p != NULL; p = p->next) {
    if (!p->memo_table) continue;
    for (q = p->lo; ; q++) {
      *q = _sweep_memo (*q);
      if (q == p->hi) break;
    } 
  } 
}

/* Search the maps for unmarked objects and set them free */

static void
sweep (void)
{
  cardinal i, j, m, f;
  cardinal *map;
  cardinal bits, new;
  cardinal k;
  cardinal p = heap_lo, q = heap_lo;
  bool free = FALSE;
  
  
  sweep_memo ();
  /* p is current pointer, q is last object */

#if _STATISTICS
  num_sweep = 0;
#endif  

  /* For all maps ... */
  for (i=map_lo; i <= map_hi; i++) {
    map = maps[i];
    if (map == NULL) {
      /* reset p and q */
      p = q = heap_lo + (i+1)*MAP_SIZE;
      continue;
    }
    
    /* For all words in the map ... */
    for (j=0; j < NUM_BITS * MAP_SIZE / (Machines_BITSPERWORD*OBJECT_ALIGN); j++) {
      bits = map[j];
      new = bits;
      if (bits == 0) { p += Machines_BITSPERWORD*OBJECT_ALIGN/NUM_BITS; continue; }
      m = MARK_BIT;
      f = FREE_BIT;
      k = 0;
      
      /* For all GC-bits in the word ... */
      do {
        if (MAPI(p) != i) { 
           printf ("Oops\n"); 
	   exit (1);
        }
#if _DEBUG
        assert (MAPI(p) == i);
        assert (MAPRI(p) == j);
        assert (MAPRR(p) == k);
#endif
        /* p is a valid object */
        if (bits & OBJ_BIT || p >= heap_hi) {
          if (free) {
	    /* q has to be freed and we now know its size */
            give_free (q, p-q);
          }
          free = FALSE;
	  
	  /* q becomes current object */
          q = p;
          if (!(bits & FREE_BIT)) {
            if (bits & MARK_BIT) { 
	      /* If marked, reset mark bit */
              new &= ~m; 
            } else { 
	      /* Otherwise, set free bit and set variable free */
#if _STATISTICS
              num_sweep++; 
#endif
              new |= f; 
#if _DEBUG
              map[j] |= f;
#endif
              free = TRUE;
            }
          }
        }
	if (p > heap_hi) return;
	
	/* Shift bits */
        bits >>= NUM_BITS;
        if (bits == 0) { 
	  /* Out of bits, go to next word */
          p += (Machines_BITSPERWORD/NUM_BITS-k)*OBJECT_ALIGN; 
          break; 
        }
	
	/* Update pointer and shift masks */
        k ++;
        p += OBJECT_ALIGN;
        m <<= NUM_BITS;
        f <<= NUM_BITS;
      } while (TRUE);
      map[j] = new;
    }
  }
}

static void skip (void)
{
}

/* Mark all globals and return stack limit */

static cardinal
mark_globals (void)
{ global_list *p;
  cardinal s_lim = ALIGN_UP(&s_lim, POINTER_ALIGN);
  cardinal s, p1;
  cardinal min_heap = heap_lo;
  cardinal max_heap = (cardinal)MyStorage_Top < heap_hi ? (cardinal)MyStorage_Top : heap_hi;
  
#if _DEBUG > 1
  printf ("  mark globals ...\n");
  fflush (stdout);
#endif
  for (p = global_addresses; p != NULL; p = p->next) {
    if (MyStorage_CollectMemo && p->memo_table) continue;
    if (p->lo == p->hi) {
      mark (*(cardinal*)p->lo);
    } else {
      s = mark_region ((cardinal)p->lo, (cardinal)p->hi);
      if (s < s_lim) s_lim = s;
    }
  }
  return s_lim;
}

/* GC cycles, n register windows */

static cardinal
_gc (cardinal n, cardinal s_hi)
{  
  cardinal s_lim = ALIGN_UP(&s_lim, POINTER_ALIGN);
  cardinal s;
  if (n > 0) {
    /* Force registers in stack by recursion */
    return _gc (n-1, s_hi);
  }
#if _STATISTICS
  num_marked = 0;
#endif

  /* Mark the stack, both up and down */
  s = mark_region (stack_lo,  s_hi);
  if (s < s_lim) s_lim = s;
  s = mark_region (s_hi,  stack_hi);
  if (s < s_lim) s_lim = s;
  
  /* Mark the globals */
  s = mark_globals ();
  if (s < s_lim) s_lim = s;
  
  /* Sweep after marking */
  sweep ();
#if _STATISTICS
  printf ("GC ... %d bytes heapspace in use = %f/object\n", MyStorage_HeapSize(), (float)MyStorage_HeapSize()/(num_marked+num_sweep+num_free));
  printf ("  marked  %d\tobjects\n", num_marked);
  printf ("  sweeped %d\tobjects\n", num_sweep);
  printf ("  free    %d\tobjects\n", num_free);
#endif
  needs_gc = 0;
  return s_lim; /* return stack limit */
}

/* The the stack pointer */
static cardinal
next_sp (void)
{ cardinal x;
  return (cardinal) &x;
}

void
MyStorage_RunGC (void)
{  
  cardinal s_lo;
  cardinal s_hi = ALIGN_UP(next_sp (), POINTER_ALIGN);
  cardinal i, n;
  
  if (!wants_gc || gc_prio == 0) return;
  
  /* Run a mark-sweep GC cycle */
  s_lo = _gc (NUM_WINDOWS, s_hi);
  
  /* Clear the stack area used by the GC to remove pointers there */
  if (s_hi > s_lo) {
    n = (s_hi-s_lo)/sizeof(cardinal);
#if _DEBUG > 1
    printf ("  clearing 0x%x .. 0x%x\n", s_lo, s_hi);
    fflush (stdout);
#endif
    /* Do not call memset ((void*)s_lo, 0, s_hi-s_lo);
       since that would overwrite its own stack frame!
    */
    for (i = 0; i < n; i++) {
      ((cardinal*)s_lo)[i] = 0;
    }
  }
  num_gcs++;
}

void MyStorage_GC_Set_Heap (void *p, cardinal size)
{
  cardinal q = (cardinal)p;
  if (q < heap_lo) heap_lo = q;
  if (q+size > heap_hi) heap_hi = q+size;
}

void MyStorage_GC_Set_Stack (void *p)
{
  cardinal q = (cardinal)p;
  if (q < stack_lo) stack_lo = q;
  if (q > stack_hi) stack_hi = q;
}

void MyStorage_GC_Set_Globals (void *p, void *q, bool memo_table)
{
  global_list *g;
  g = malloc (sizeof(*g));
  heapspace += sizeof(*g);
  g->lo = p;
  g->hi = q;
  g->memo_table = memo_table;
  g->next = global_addresses;
  global_addresses = g;
}

void MyStorage_GC_Set_Global (void *p)
{
  MyStorage_GC_Set_Globals (p, p, FALSE);
}

address MyStorage_GC_Set_Memo (void *p)
{
#if _DEBUG > 1
    printf ("  memo 0x%p\n", p);
    fflush (stdout);
#endif
  SET_MEMO(p);
  return p;
}

void MyStorage_WantsGC (void)
{
  wants_gc = TRUE;
}

void MyStorage_SetGCPrio (cardinal n)
{
  gc_prio = n;
}

static int initdone = 0;

void MyStorage_InitGlobals(void)
{ 
  if (initdone) { return; }
  initdone = 1;
  if (wants_gc) {
    gc_block_size = ALIGN_UP(sizeof(gc_block), OBJECT_ALIGN);
    malloc_func   = &malloc_block;
    run_gc        = &MyStorage_RunGC;
    MyStorage_GC_Set_Heap (malloc (OBJECT_ALIGN), OBJECT_ALIGN);
  }
  MyStorage_left = MyStorage_BlockSize;
  MyStorage_Top = (address) malloc_func (MyStorage_BlockSize); 
  MyStorage_Bottom = MyStorage_Top; 
  MyStorage_blocks = 1;
  MyStorage_large = 0;
  MyStorage_CollectIdent = TRUE;
  MyStorage_CollectMemo = TRUE;
} 

bool is_free (void *p)
{
#if _DEBUG
  if (IS_FREE(p)) {
    printf ("Free object encountered 0x%x\n", (cardinal)p);
    fflush (stdout);
  }
#endif
  return IS_FREE(p);
}
/* END MyStorage */

