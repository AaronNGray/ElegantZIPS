/* File : CGNInit.c */

#include "SYSTEM.h"
#include "Bnf.h"
#include "CharSets.h"
#include "DFAs.h"
#include "Finit.h"
#include "GenCode.h"
#include "Init.h"
#include "NFAs.h"
#include "Output.h"
#include "Representations.h"
#include "Scopes.h"
#include "StaticSemantics.h"
#include "Switches.h"
#include "TypeModule.h"

extern void CGNInit_Init(void)
{
  Bnf_InitGlobals();
  CharSets_InitGlobals();
  DFAs_InitGlobals();
  Finit_InitGlobals();
  GenCode_InitGlobals();
  Init_InitGlobals();
  NFAs_InitGlobals();
  Output_InitGlobals();
  Representations_InitGlobals();
  Scopes_InitGlobals();
  StaticSemantics_InitGlobals();
  Switches_InitGlobals();
  TypeModule_InitGlobals();
} /* Init */

/* END CGNInit */
