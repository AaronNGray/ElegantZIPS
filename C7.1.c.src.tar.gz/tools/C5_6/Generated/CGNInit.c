/* File : CGNInit.c */

#include "SYSTEM.h"
#include "Convert.h"
#include "Finit.h"
#include "Init.h"
#include "Switches.h"

extern void CGNInit_Init(void)
{
  Convert_InitGlobals();
  Finit_InitGlobals();
  Init_InitGlobals();
  Switches_InitGlobals();
} /* Init */

/* END CGNInit */
