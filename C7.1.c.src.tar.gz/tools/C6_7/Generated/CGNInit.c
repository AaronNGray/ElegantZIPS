/* File : CGNInit.c */

#include "SYSTEM.h"
#include "Finit.h"
#include "Init.h"
#include "Mappings.h"
#include "Switches.h"

extern void CGNInit_Init(void)
{
  Finit_InitGlobals();
  Init_InitGlobals();
  Mappings_InitGlobals();
  Switches_InitGlobals();
} /* Init */

/* END CGNInit */
