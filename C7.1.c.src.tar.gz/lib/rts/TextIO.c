/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef __SYSTEM
#include "SYSTEM.h"
#endif

#ifndef __SystemTypes
#include "SystemTypes.h"
#endif

#ifndef __CharCodes
#include "CharCodes.h"
#endif

#ifndef __FileStream
#include "FileStream.h"
#endif

#ifndef __Strings
#include "Strings.h"
#endif

#ifndef __TextIO
#include "TextIO.h"
#endif


/* --------------------- Output Procedures -------------------------------- */

void TextIO_Flush (FileStream_WriteFile f)
{ 
  fflush (f);
} /* Flush */

void TextIO_WriteCHAR (FileStream_WriteFile f, Char ch)
{ 
  fputc (ch, f);
} /* WriteCHAR */

void TextIO_NewLine (FileStream_WriteFile f)
{ 
  fputc (CharCodes_NL, f);
} /* NewLine */

void TextIO_WriteString (FileStream_WriteFile f, string str)
{ 
  fputs ((char*)str, f);
} /* WriteString */

void TextIO_WriteINTEGER (FileStream_WriteFile f, int i)
{ 
  if (i  < 0)
  { TextIO_WriteCHAR(f,'-'); TextIO_WriteCARDINAL(f, (cardinal)(-i)); }
  else 
  { TextIO_WriteCARDINAL(f, (cardinal)i); }
} /* WriteINTEGER */

void TextIO_WriteCARDINAL (FileStream_WriteFile f, cardinal c)
{ 
  if (c > 9) { TextIO_WriteCARDINAL(f, c DIV 10); }
  TextIO_WriteCHAR(f,(Char)((cardinal)'0' + c MOD 10));
} /* WriteCARDINAL */

void TextIO_WriteBOOLEAN (FileStream_WriteFile f, bool b)
{ 
  if (b)
  { TextIO_WriteString (f, (string)"TRUE"); }
  else 
  { TextIO_WriteString (f, (string)"FALSE"); }
} /* WriteBOOLEAN */

void TextIO_WriteREAL (FileStream_WriteFile f, double real, int decplaces)
{ 
  int i, digit ;
  if (real < 0.0)
  { TextIO_WriteCHAR(f,'-'); }
  if (real < 0.0) real = -real;
  TextIO_WriteCARDINAL(f,(cardinal)real); TextIO_WriteCHAR(f,'.');
  real = real - (double)((cardinal)real);
  for (i = 1 ; i <= decplaces ; i++) 
  { real = 10.0 * real; digit = (cardinal)real; real = real - (double)digit;
    TextIO_WriteCHAR(f, (Char)((cardinal)'0'+digit));
  }
} /* WriteREAL */


/* --------------------- Input Procedures -------------------------------- */

Char TextIO_ReadCHAR (FileStream_ReadFile f)
{ 
  int c ;
  c = fgetc (f);
  if (c EQ EOF) { return(0); }
  return((Char) (c));
} /* ReadCHAR */

int TextIO_ReadC (FileStream_ReadFile f)
{ 
  return(fgetc (f));
} /* ReadC */

typedef enum {First, Second, Third, Neither} TextIO_SKIPRESULT;
    /* returned by SkipToOneOf */

static TextIO_SKIPRESULT TextIO_SkipToOneOf (FileStream_ReadFile f, Char ch1, Char ch2, Char ch3)
/*  return 'First' if 'ch1' encountered,
   'Second' if 'ch2' encountered,
   'Third' if 'ch3' encountered, 'Neither' otherwise
*/
{ 
  Char ch ;
  ch = TextIO_ReadCHAR (f);
  while(TRUE)
  { if ((ch NEQ CharCodes_SP) AND (ch NEQ CharCodes_HT) AND 
        (ch NEQ CharCodes_LF) AND (ch NEQ CharCodes_FF) AND 
        (ch NEQ CharCodes_CR))
    { if      (ch EQ ch1) { return(First);  }
      else if (ch EQ ch2) { return(Second);  }
      else if (ch EQ ch3) { return(Third);  }
      else {  ungetc (ch, f); return(Neither); }
    }
    ch = TextIO_ReadCHAR (f);
  }
} /* SkipToOneOf */

static Char TextIO_SkipWhiteSpace (FileStream_ReadFile f)
{ 
  Char ch ;
  do { ch = TextIO_ReadCHAR (f); }
  while ((ch EQ CharCodes_SP) OR (ch EQ CharCodes_LF) OR
         (ch EQ CharCodes_FF) OR (ch EQ CharCodes_HT) OR
         (ch EQ CharCodes_CR));
  return(ch);
} /* SkipWhiteSpace */

int TextIO_ReadINTEGER (FileStream_ReadFile f)
{ 
  int i ;
  bool negative ;
  negative = TextIO_SkipToOneOf(f, '-', '+', '\0') EQ First;
  i = (int)TextIO_ReadCARDINAL (f);
  if (negative) { return(-i); } else { return(i); }
} /* ReadINTEGER */

static bool TextIO_CheckTrueOrFalse (FileStream_ReadFile f, string chars)
{ 
  Char ch ;
  cardinal i ;
  i = 1; /* first char already swallowed */
  while (chars[i] NEQ '\0')
  { ch = TextIO_ReadCHAR (f);
    if (ch NEQ chars[i]) { ungetc (ch, f); return(FALSE); }
    i++;
  }  /* while */
  return(TRUE);
} /* CheckTrueOrFalse */

bool TextIO_ReadBOOLEAN (FileStream_ReadFile f)
{ 
  switch (TextIO_SkipToOneOf(f, 'T', 'F', '\0'))
  { case First :  return(TextIO_CheckTrueOrFalse (f, (string)"TRUE"));
    case Second : return(NOT TextIO_CheckTrueOrFalse (f, (string)"FALSE"));
    default : break;
  } /* case */
  return(FALSE);
} /* ReadBOOLEAN */

cardinal TextIO_ReadCARDINAL (FileStream_ReadFile f)
{ 
  Char ch ;
  cardinal sum, c ;
  ch = TextIO_SkipWhiteSpace (f);
  sum = 0;
  while (TRUE)
  { if ((ch >= '0') AND (ch <= '9'))
    { c = (cardinal)ch - (cardinal)'0'; }
    else 
    { c = 100; }
    if (c >= 10) { break; }
    sum = sum*10 + c;
    ch = TextIO_ReadCHAR (f);
  }
  ungetc (ch, f);
  return(sum);
} /* ReadCARDINAL */

double TextIO_ReadREAL (FileStream_ReadFile f)
{ 
  double real, factor, frac ;
  bool negative, fractionalpart ;
  Char ch ;
  int exponent ;
  real =  0.0; fractionalpart = FALSE;
  negative = TextIO_SkipToOneOf (f, '-', '+', '\0') EQ First;
  while (TRUE)
  { ch = TextIO_ReadCHAR (f);
    if ((ch >= '0') AND (ch <= '9')) 
    { real = real * 10.0 + (double) ((cardinal)ch - (cardinal)'0'); }
    else if (ch EQ '.') 
    { fractionalpart = TRUE;
      break;
    }
    else { break; }
  }
  if (fractionalpart) 
  { factor = 1.0; frac = 0.0;
    while (TRUE)
    { ch = TextIO_ReadCHAR (f);
      if (('0' <= ch) AND (ch <= '9'))
      { factor = factor / 10.0;
        frac = frac + factor * (double)((cardinal)ch - (cardinal)'0'); 
      }
      else 
      { break; }
    }
    real = real + frac;
  }
  if ((ch EQ 'E') OR (ch EQ 'e'))
  { exponent = TextIO_ReadINTEGER (f);
    while (exponent > 0) {  real = real * 10.0; exponent--; }
    while (exponent < 0) {  real = real / 10.0; exponent++; } 
  }
  else 
  { ungetc (ch, f); }
  if (negative) { return(-real); } else { return(real); }
} /* TextIO_ReadREAL */

bool TextIO_WhiteSpace (Char ch)
{ 
  return((ch EQ CharCodes_SP) OR (ch EQ CharCodes_HT) OR 
         (ch EQ CharCodes_LF) OR (ch EQ CharCodes_CR) OR (ch EQ CharCodes_FF));
} /* WhiteSpace */

bool TextIO_EndOfLine (Char ch)
{ 
  return((ch EQ CharCodes_LF) OR (ch EQ CharCodes_CR) OR (ch EQ CharCodes_FF));
} /* EndOfLine */

void TextIO_ReadChars(FileStream_ReadFile f, char *chars, int n)
{
  fgets (chars, n, f);
} /* ReadChars */

string TextIO_ReadString (FileStream_ReadFile f)
{ 
  char buffer[TextIO_MaxStringSize];
  fgets (buffer, TextIO_MaxStringSize, f);
  return(Strings_Append ((string)"", (string)buffer));
} /* ReadString */

bool TextIO_Eof (FileStream_ReadFile f)
{ 
  int ch ;
  ch = TextIO_ReadC (f);
  if (ch EQ EOF) { return(TRUE); }
  ungetc ((Char)ch, f);
  return(FALSE);
} /* Eof */

void TextIO_InitGlobals (void) { }

/* END TextIO */

