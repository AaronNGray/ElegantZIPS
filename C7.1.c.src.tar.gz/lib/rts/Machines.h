/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef __Machines
#define __Machines

#ifndef __SYSTEM
#include "SYSTEM.h"
#endif

typedef cardinal Machines_Machine;
#define Machines_Sun    	0
#define Machines_HP700    	1
#define Machines_PC    		2
#define Machines_MAC		3
#define Machines_I486		4
#define Machines_SGI		5
#define Machines_MAX	Machines_SGI

#define ESIZE_Machine SIZE_cardinal

#ifdef _hp700
#define Machines_ThisMachine  Machines_HP700
#define Machines_BITSPERWORD  32
#endif

#ifdef _dos
#define Machines_ThisMachine  Machines_PC
#define Machines_BITSPERWORD  32	/* Assume 386 protected mode */
#endif

#ifdef _sun4
#define Machines_ThisMachine  Machines_Sun
#define Machines_BITSPERWORD  32
#endif

#ifdef _solaris
#define Machines_ThisMachine  Machines_Sun
#define Machines_BITSPERWORD  32
#endif

#ifdef _mac
#define Machines_ThisMachine  Machines_MAC
#define Machines_BITSPERWORD  32
#endif

#ifdef _i486
#define Machines_ThisMachine  Machines_I486
#define Machines_BITSPERWORD  32
#endif

#ifdef _sgi
#define Machines_ThisMachine  Machines_SGI
#define Machines_BITSPERWORD  32
#endif

#ifndef Machines_ThisMachine
#define Machines_ThisMachine  Machines_Sun
#define Machines_BITSPERWORD  32
#endif


extern cardinal Machines_BitsPerWord[Machines_MAX+1];

extern void Machines_InitGlobals(void);

#endif /*  Machines */

