/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

/************** ansi.h *************/

#ifndef __ansi
#define __ansi

#ifdef _hp700
#define _INCLUDE_POSIX_SOURCE
#define _INCLUDE_XOPEN_SOURCE
#define _INCLUDE_XOPEN_SOURCE_EXTENDED
#define _INCLUDE_HPUX_SOURCE
#define _INCLUDE_AES_SOURCE
/* #include "ansihp700.h" */
/* Avoid anoying warning on time.h */
#ifndef _GET_EXPIRATION_TIME
#define _GET_EXPIRATION_TIME
#endif
#include <errno.h>
#include <stddef.h>
#include <assert.h>
#include <ctype.h>
#include <locale.h>
#include <math.h>
#include <setjmp.h>
#include <signal.h>

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <limits.h>

#include <dirent.h>
#include <utime.h>
#include <sys/types.h>
#endif

#ifdef _sun4
#include "ansisun4.h"
#endif

#ifdef _solaris
#define _INCLUDE_POSIX_SOURCE
#define _INCLUDE_XOPEN_SOURCE
#define _INCLUDE_HPUX_SOURCE
#define _INCLUDE_AES_SOURCE
/* #include "ansisola.h" */
#include <errno.h>
#include <stddef.h>
#include <assert.h>
#include <ctype.h>
#include <locale.h>
#include <math.h>
#include <setjmp.h>
#include <signal.h>

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <limits.h>

#include <dirent.h>
#include <utime.h>
#include <sys/types.h>
#endif

#ifdef _i486
#include <errno.h>
#include <stddef.h>
#include <assert.h>
#include <ctype.h>
#include <locale.h>
#include <math.h>
#include <setjmp.h>
#include <signal.h>

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <limits.h>

#include <dirent.h>
#include <utime.h>
/* #include <types.h> */
/* #include "ansii486.h" */
#endif

#if defined(WIN32) && !defined(_dos)
#define _dos
#endif

#ifdef _dos
/* #include "ansidos.h" */
#include <errno.h>
#include <stddef.h>
#include <assert.h>
#include <ctype.h>
#include <locale.h>
#include <math.h>
#include <setjmp.h>
#include <signal.h>

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <limits.h>
#include <msdir.h>

#if 0
#include <utime.h>
#endif
#include <sys/types.h>
#endif

#ifdef _sgi
/* #include "ansisgi.h" */
#include <errno.h>
#include <stddef.h>
#include <assert.h>
#include <ctype.h>
#include <locale.h>
#include <math.h>
#include <setjmp.h>
#include <signal.h>

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <limits.h>

#include <dirent.h>
#include <utime.h>
/* #include <types.h> */
#endif

#endif
