/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef __SYSTEM
#include "SYSTEM.h"
#endif

#ifndef __SystemTypes
#include "SystemTypes.h"
#endif

#ifndef __TimeDate
#include "TimeDate.h"
#endif

time_t TimeDate_Clock (void)
/* Time in seconds since 1-1-1970, 00:00:00 GMT */
{ 
    return(time (NULL)); 
} /* Clock */

TIME TimeDate_LocalTime (time_t clock)
{ 
  return((TIME) localtime (&clock));
} /* LocalTime */

TIME TimeDate_GMT (time_t clock)
{ 
  return((TIME) gmtime (&clock));
} /* GMT */

string TimeDate_TimeString (time_t clock)
{ 
  return((string)ctime (&clock));
} /* TimeString */

string TimeDate_TIMEToString (TIME time)
{ 
  return((string)asctime (time));
} /* TIMEToString */

void TimeDate_InitGlobals (void) { }

/* END TimeDate */


