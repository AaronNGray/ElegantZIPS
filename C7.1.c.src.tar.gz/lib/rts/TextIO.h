/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef __TextIO
#define __TextIO

#ifndef __SYSTEM
#include "SYSTEM.h"
#endif

#ifndef __FileStream
#include "FileStream.h"
#endif

/* CONST */
/* #define EOF  (-1) */

#define TextIO_MaxStringSize  10240

/*    
    The procedures ReadINTEGER, ReadCARDINAL,
    ReadBOOLEAN and ReadREAL
    skip all leading whitespace (spaces, tabs, newlines, form-feeds),
    and terminate reading when any character outside the range
    defined by the radix is encountered.  If no valid characters
    are found, the result is 0 for numbers and FALSE for booleans
    and the last character is put back on the stream.  
    ReadChars and ReadString do not skip any characters.
    
    Signed numbers are only accepted by ReadINTEGER and ReadREAL.
    
    The format of objects is as follows.
    [] signifies optional things and | alternatives.

    Type            Input               Output    
    ----            -----               ------

    int:            [+|-]n              [-]n
    cardinal:       n   base 10         as input
    Char:           character           as input
    double:          [+|-]n[.fE[+|-]s]   [-]i.f
    bool:           TRUE|FALSE          TRUE|FALSE
    String, Chars   abcdeLF              abcdeLF
                    where 'abcde' are the characters of the string
                    and T is a terminating character, i.e. a LF or EOF.
                    If the array is not large enough, only the number
                    of chars that it can contain will be read.
                    Strings are maximally MaxStringSize large.
*/

extern void TextIO_Flush (FileStream_WriteFile f);


extern void TextIO_WriteCHAR (FileStream_WriteFile f, Char ch);

extern Char TextIO_ReadCHAR (FileStream_ReadFile f);

extern int TextIO_ReadC (FileStream_ReadFile f);
/* Returns EOF on eof. */

extern void TextIO_NewLine (FileStream_WriteFile f);


extern void TextIO_WriteINTEGER (FileStream_WriteFile f, int i);

extern int TextIO_ReadINTEGER (FileStream_ReadFile f);


extern void TextIO_WriteCARDINAL (FileStream_WriteFile f, cardinal c);

extern cardinal TextIO_ReadCARDINAL (FileStream_ReadFile f);

extern void TextIO_WriteBOOLEAN (FileStream_WriteFile f, bool b);

extern bool TextIO_ReadBOOLEAN (FileStream_ReadFile f);


extern void TextIO_WriteREAL (FileStream_WriteFile f, double real, int decplaces);

extern double TextIO_ReadREAL (FileStream_ReadFile f);


extern void TextIO_ReadChars (FileStream_ReadFile f, char *chars, int n);
/*  Reads characters until chars is full, or LF or end of file is reached,
    and places the characters in standard language form. 
*/

extern void TextIO_WriteString (FileStream_WriteFile f, string str);
/* FileStream_WriteFile s; String string; */

extern string TextIO_ReadString (FileStream_ReadFile f);
/*  Similar to ReadChars, save that the characters are placed in
    a dynamically allocated String.  The caller is responsible for
    disposing of the resulting object.
    The maximum number of characters that can be read with this 
    routine is MaxStringSize.
*/
extern bool TextIO_WhiteSpace (Char ch);
/*  Returns TRUE for the white-space characters,
    specifically SP, LF, CR, FF and HT
    (from CharCodes), for common use with ReadChars, ReadString.
*/
extern bool TextIO_EndOfLine (Char ch);
/*  Returns TRUE for the end-of-line characters,
    specifically LF, CR, FF.
    (from CharCodes), for common use with ReadChars, ReadString.
*/

extern void TextIO_InitGlobals (void);

#endif /*  TextIO */

