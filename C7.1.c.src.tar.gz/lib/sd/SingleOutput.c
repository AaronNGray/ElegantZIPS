/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef __SYSTEM
#include "SYSTEM.h"
#endif

#ifndef __StandardTypes
#include "StandardTypes.h"
#endif

#ifndef __CharCodes
#include "CharCodes.h"
#endif

#ifndef __FileStream
#include "FileStream.h"
#endif

#ifndef __SysStreams
#include "SysStreams.h"
#endif

#ifndef __TextIO
#include "TextIO.h"
#endif

#ifndef __Strings
#include "Strings.h"
#endif

#ifndef __Machines
#include "Machines.h"
#endif

#ifndef __UnixProcess
#include "UnixProcess.h"
#endif

#ifndef __MyStorage
#include "MyStorage.h"
#endif

#ifndef __SingleOutput
#include "SingleOutput.h"
#endif

extern StandardTypes_Bool Prelude_print_exponent;
extern StandardTypes_Int  Prelude_print_precision;

/* CONST */

#define SingleOutput_FileNameLength (256)

static Char SingleOutput_Buffer[SingleOutput_BufferSize];
FileStream_WriteFile SingleOutput_Current = NULL;
string SingleOutput_Current_name = NULL;
static StandardTypes_List SingleOutputFileStack = NULL;

int SingleOutput_left;

#define left SingleOutput_left

static Char *pointer;

static Char lf;

static void SingleOutput_WriteBuffer(void);

void SingleOutput_OpenFile (string name)
{ StandardTypes_List StackEntry;
  if (SingleOutput_Current NEQ NULL)
  { if (left < SingleOutput_BufferSize)
    { SingleOutput_WriteBuffer(); }
    if (left < SingleOutput_BufferSize)
    { TextIO_WriteString (SysStreams_sysErr, (string)"Cannot write to file");
      TextIO_NewLine (SysStreams_sysErr);
      TextIO_Flush(SysStreams_sysErr);
      UnixProcess_Exit (UnixProcess_Failure);
    }  
    if (SingleOutput_Current NEQ SysStreams_sysOut AND 
        SingleOutput_Current NEQ SysStreams_sysErr) 
    { FileStream_CloseOutput (SingleOutput_Current); 
      SingleOutput_Current = NULL;
    } else {
      TextIO_Flush (SingleOutput_Current); 
    }
    StackEntry = MyStorage_Fast_ALLOCATE(sizeof(Rec_StandardTypes_List));
    StackEntry->head=(void*)SingleOutput_Current_name;
    StackEntry->tail=(void*)SingleOutputFileStack;
    SingleOutputFileStack=StackEntry;
  }
  if (name EQ NULL)
  { SingleOutput_Current = SysStreams_sysErr; }
  else if (Strings_Length (name) EQ 0)
  { SingleOutput_Current = SysStreams_sysOut; }
  else
  { StackEntry = SingleOutputFileStack;
    while(StackEntry NEQ (StandardTypes_List)NULL)
    {
      if (StackEntry->head NEQ NULL AND
          Strings_Compare((string)StackEntry->head,name) == SystemTypes_EQ)
      { break; }
      StackEntry = StackEntry->tail;
    }
    if (StackEntry NEQ (StandardTypes_List)NULL AND
        Strings_Compare((string)StackEntry->head,name) == SystemTypes_EQ)
    { if (NOT FileStream_AppendOutput (name, &SingleOutput_Current))
      { TextIO_WriteString (SysStreams_sysErr, (string)"Cannot open file ");
        TextIO_WriteString (SysStreams_sysErr, name);
        TextIO_NewLine (SysStreams_sysErr);
        TextIO_Flush(SysStreams_sysErr);
        UnixProcess_Exit (UnixProcess_Failure);
      }
    }
    else
    { if (NOT FileStream_CreateOutput (name, &SingleOutput_Current))
      { TextIO_WriteString (SysStreams_sysErr, (string)"Cannot open file ");
        TextIO_WriteString (SysStreams_sysErr, name);
        TextIO_NewLine (SysStreams_sysErr);
        TextIO_Flush(SysStreams_sysErr);
        UnixProcess_Exit (UnixProcess_Failure);
      }
    }
  }
  if(name NEQ (string)NULL)
  { SingleOutput_Current_name = Strings_Append(Strings_New(0), name); }
  else
  { SingleOutput_Current_name = (string)NULL;}
  pointer = &SingleOutput_Buffer[0];
  left = SingleOutput_BufferSize;
} /* OpenFile */

static void SingleOutput_WriteBuffer(void)
{
  cardinal cnt;
  if (SingleOutput_Current == NULL)
  { TextIO_WriteString (SysStreams_sysErr, (string)"Output file is not open");
    TextIO_NewLine (SysStreams_sysErr);
    TextIO_Flush(SysStreams_sysErr);
    UnixProcess_Exit (UnixProcess_Failure);
  }
  cnt = FileStream_Write (&SingleOutput_Buffer[0], 1, SingleOutput_BufferSize-left, SingleOutput_Current);
  pointer -= cnt;
  left += cnt;
} /* WriteBuffer */

void SingleOutput_CloseFile(void)
{ StandardTypes_List StackEntry;
  if (SingleOutput_Current == NULL) { return; }
  if (left < SingleOutput_BufferSize)
  { SingleOutput_WriteBuffer(); }
  if (left < SingleOutput_BufferSize)
  { TextIO_WriteString (SysStreams_sysErr, (string)"Cannot write to file");
    TextIO_NewLine (SysStreams_sysErr);
    TextIO_Flush(SysStreams_sysErr);
    UnixProcess_Exit (UnixProcess_Failure);
  }  
  if (SingleOutput_Current NEQ SysStreams_sysOut AND 
      SingleOutput_Current NEQ SysStreams_sysErr) 
  { FileStream_CloseOutput (SingleOutput_Current); 
    SingleOutput_Current = NULL;
  } else { 
    TextIO_Flush (SingleOutput_Current); 
  }
  if (SingleOutputFileStack==(StandardTypes_List)NULL) {return;}
  SingleOutput_Current_name = (string) SingleOutputFileStack->head;
  if (SingleOutput_Current_name EQ NULL)
  { SingleOutput_Current = SysStreams_sysErr; }
  else if (Strings_Length (SingleOutput_Current_name) EQ 0)
  { SingleOutput_Current = SysStreams_sysOut; }
  else
  { if (NOT FileStream_AppendOutput (SingleOutput_Current_name, &SingleOutput_Current))
    { TextIO_WriteString (SysStreams_sysErr, (string)"Cannot re-open file ");
      TextIO_WriteString (SysStreams_sysErr, SingleOutput_Current_name);
      TextIO_NewLine (SysStreams_sysErr);
      TextIO_Flush(SysStreams_sysErr);
      UnixProcess_Exit (UnixProcess_Failure);
    }
  }
  StackEntry = SingleOutputFileStack;
  SingleOutputFileStack = SingleOutputFileStack->tail;
} /* CloseFile */

void SingleOutput_FromString (StandardTypes_String s)
{ 
  Char *i;
  
  if (s==NULL) return;
  i = &s[0];
  while (*i)
  { if (left EQ 0) { SingleOutput_WriteBuffer(); }
    *pointer++ = *i++;
    left--;
  }
} /* FromString */

void SingleOutput_FromIdent (StandardTypes_Ident id)
{ 
  Char *i;
  
  if (id==NULL) return;
  i = &(id->represent[0]);
  while (*i)
  { if (left EQ 0) { SingleOutput_WriteBuffer(); }
    *pointer++ = *i++;
    left--;
  }
} /* FromIdent */

void SingleOutput_FromChar (StandardTypes_Char c)
{
  if (left EQ 0) { SingleOutput_WriteBuffer(); }
  *pointer++ = c;
  left--;
  if (c EQ lf)
  { SingleOutput_WriteBuffer();
    TextIO_Flush (SingleOutput_Current);
  }
} /* FromChar */

void SingleOutput_FromInt (StandardTypes_Int i)
{ int q, r;
  if (i < 0)
  {
    SingleOutput_FromChar('-');
    /* Old code used SingleOutput_FromInt(-i),
     * but that will not work if i ==MaxInt
     */
    q = i/10; r = i - q*10; /* ANSI-C guarantees (a/b)*b + a%b = a */
    if (q NEQ 0)
      SingleOutput_FromInt(abs(q));
    SingleOutput_FromChar ((Char) ((cardinal)(abs(r)) + (cardinal)'0'));
  }
  else
  {
    if (i >= 10)
    {
      SingleOutput_FromInt (i DIV 10);
      SingleOutput_FromChar ((Char) ((cardinal)(i MOD 10) + (cardinal)'0'));
    } 
    else 
    {
      SingleOutput_FromChar ((Char) ((cardinal)(i) + (cardinal)'0'));
    }
  }
} /* FromInt */

void SingleOutput_FromCardinal (cardinal i)
{ 
  if (i >= 10)
  { SingleOutput_FromCardinal (i DIV 10);
    SingleOutput_FromChar ((Char) ((cardinal)(i MOD 10) + (cardinal)'0'));
  } 
  else 
  { SingleOutput_FromChar ((Char) ((cardinal)(i) + (cardinal)'0')); }
} /* FromCardinal */

void SingleOutput_FromBool (bool b)
{
  if (b) { SingleOutput_FromString ((string)"TRUE"); } 
  else   { SingleOutput_FromString ((string)"FALSE"); }
} /* FromBool */

static void SingleOutput_SimpleFloat (StandardTypes_Float real)
{
  int i, digit;
  if (real < 0.0)
  { SingleOutput_FromChar ('-'); real = -real; }
  { StandardTypes_Float round = 0.5;
    for (i = 1 ; i <= Prelude_print_precision ; i++) { round /= 10.0; }
    real += round;
  }
  SingleOutput_FromCardinal ((cardinal)real);
  real -= (StandardTypes_Float)((cardinal)real);
  if (Prelude_print_precision > 0)
  { SingleOutput_FromChar ('.');
    for (i = 1 ; i <= Prelude_print_precision ; i++) 
    { real = 10.0 * real;
      digit = (cardinal)real;
      real = real - (StandardTypes_Float)digit;
      SingleOutput_FromChar ((Char)((cardinal)'0'+digit));
    }
  }
} /* SimpleFloat */

void SingleOutput_FromFloat (StandardTypes_Float real)
{
  if (Prelude_print_exponent)
  { int exponent = 0;
    if (real < 0.0)
    { SingleOutput_FromChar ('-'); real = -real; }
    if (real NEQ 0.0)
    { while (real >= 10.0) { exponent++ ; real /= 10.0; }
      while (real <   1.0) { exponent-- ; real *= 10.0; }
    }
    SingleOutput_SimpleFloat (real);
    SingleOutput_FromChar ('e');
    if (exponent < 0)
    { SingleOutput_FromChar ('-'); exponent = -exponent; }
    else
    { SingleOutput_FromChar ('+'); }
    if (exponent < 10)
    { SingleOutput_FromChar ('0'); }
    SingleOutput_FromInt (exponent);
  }
  else
  { SingleOutput_SimpleFloat (real);
  }
} /* FromFloat */

static Char hex_values[] = "0123456789abcdef";

void SingleOutput_FromBitset (StandardTypes_Bitset s)
{ 
  SingleOutput_FromString ("0x");
  if (s > 16) { SingleOutput_FromBitset (s DIV 16); }
  SingleOutput_FromChar (hex_values[s MOD 16]);
} /* FromBitset */

void SingleOutput_Nothing (void)
{
} /* Nothing */

void SingleOutput_NewLine (void)
{
  SingleOutput_FromChar (lf);
} /* NewLine */

void SingleOutput_FromStringLn (string str)
{ 
  Char *i = &(str[0]);
  while (*i)
  { if (left EQ 0) { SingleOutput_WriteBuffer(); }
    *pointer++ = *i++;
    left--;
  }
  SingleOutput_FromChar(lf);
} /* FromStringLn */

void SingleOutput_Init(void)
{ if (Machines_ThisMachine EQ Machines_MAC)
  { lf = CharCodes_CR; } 
  else
  { lf = CharCodes_LF; }
  /*SingleOutput_OpenFile ((string)"");*/
  MyStorage_GC_Set_Global(&SingleOutput_Current);
  MyStorage_GC_Set_Global(&SingleOutput_Current_name);
  MyStorage_GC_Set_Global(&SingleOutputFileStack);
} /* Init */

void SingleOutput_InitGlobals (void) { }

/* END SingleOutput */

