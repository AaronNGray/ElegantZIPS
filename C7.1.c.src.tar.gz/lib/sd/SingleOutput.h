/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/


#ifndef __SingleOutput
#define __SingleOutput

#ifndef __StandardTypes
#include "StandardTypes.h"
#endif

#ifndef __FileStream
#include "FileStream.h"
#endif


#define SingleOutput_BufferSize (1024 * 32)

extern int SingleOutput_left;

/* The current output file */

extern FileStream_WriteFile SingleOutput_Current;

/* To open a file, all output operations write out to this file */

extern void SingleOutput_OpenFile (string name);

/* To close the current file */

extern void SingleOutput_CloseFile(void);

/* Writing of standard types */

extern void SingleOutput_FromString (StandardTypes_String x);

extern void SingleOutput_FromIdent (StandardTypes_Ident x);

extern void SingleOutput_FromChar (StandardTypes_Char x);

extern void SingleOutput_FromInt (StandardTypes_Int x);

extern void SingleOutput_FromCardinal (cardinal x);

extern void SingleOutput_FromBool (StandardTypes_Bool x);

extern void SingleOutput_FromFloat (StandardTypes_Float x);

extern void SingleOutput_FromBitset (StandardTypes_Bitset x);

extern void SingleOutput_Nothing (void);

extern void SingleOutput_NewLine (void);

extern void SingleOutput_FromStringLn (StandardTypes_String x);

extern void SingleOutput_Init (void);

extern void SingleOutput_InitGlobals (void);

#endif /*   SingleOutput */

