/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef __SYSTEM
#include "SYSTEM.h"
#endif

#ifndef __StandardTypes
#include "StandardTypes.h"
#endif

#ifndef __TextIO
#include "TextIO.h"
#endif

#ifndef __SysStreams
#include "SysStreams.h"
#endif

#ifndef __FileStream
#include "FileStream.h"
#endif

#ifndef __UnixProcess
#include "UnixProcess.h"
#endif

#ifndef __MyStorage
#include "MyStorage.h"
#endif

#ifndef __Identifier
#include "Identifier.h"
#endif

#ifndef __LazyCodeModule
#include "LazyCodeModule.h"
#endif

#ifndef __ScanIO
#include "ScanIO.h"
#endif


/* CONST */

int ScanIO_tokenptr,                 /* tokenend in buffer          */ 
    ScanIO_rememberptr,              /* possible tokenend in buffer */ 
    ScanIO_startptr ;                /* token start in buffer       */ 

bool ScanIO_skipbool, 
     ScanIO_resetbool;

int ScanIO_symbollength, 
    ScanIO_totalerrors, 
    ScanIO_totalwarnings,
    ScanIO_maxerrors ;

bool ScanIO_noerrors ; 
bool ScanIO_SuppressContextChecks ;
bool ScanIO_SuppressWarnings ;
bool ScanIO_deleting ;

Char ScanIO_buffer[StandardTypes_MaxBuf];    /* Token ScanIO_buffer for scanner */ 

FileStream_ReadFile ScanIO_scanin;            /* Current input file       */ 
StandardTypes_String ScanIO_scanstring;       /* Current input string     */

int ScanIO_CharCount;
static int stringsize ; 

/* Terminal attributes */

StandardTypes_SimpleType ScanIO_ScanAttribute; 
StandardTypes_SimpleType *ScanIO_RefAttribute; /* & ScanIO_ScanAttribute */

ScanIO_InputFiles ScanIO_inputs, 
                  ScanIO_firstinput, 
                  ScanIO_lastinput; 

bool ScanIO_inputerrors;

#define ScanIO_MaxLines  (1024 * 1024 * 2)

static StandardTypes_Int  *ScanIO_LineIndex;
static unsigned int ScanIO_LineSize; /*Size of LineIndex */

static void ScanIO_ResetInput (int readptr)
{
  ScanIO_inputs->firstchar = ScanIO_CharCount + readptr;
  ScanIO_inputerrors = FALSE;
} /* ResetInput */

void ScanIO_reset (FileStream_ReadFile *s, char *fn) 
{
  if (NOT FileStream_CreateInput ((string)fn, s))
  { TextIO_WriteString (SysStreams_sysErr, (string)"Cannot open file ");
    TextIO_WriteString (SysStreams_sysErr, (string)fn);
    TextIO_NewLine (SysStreams_sysErr);
    TextIO_Flush(SysStreams_sysErr);
    UnixProcess_Exit (UnixProcess_Failure);
  }
} /* reset */

void ScanIO_reset_input (void) 
{ ScanIO_scanin = NULL;
  ScanIO_scanstring = NULL;
  if (ScanIO_inputs->str NEQ NULL)
  { ScanIO_scanstring = ScanIO_inputs->str; 
    stringsize = ScanIO_inputs->strlen;
  }
  else if (ScanIO_inputs->name NEQ NULL)
  { ScanIO_reset (&ScanIO_scanin, (char*)ScanIO_inputs->name->represent); }
  else
  { ScanIO_scanin = stdin; }
} 

#define ScanIO_ClearBuf(from) (ScanIO_buffer[from] = ScanIO_EOFChar)

static int ReadBuf (int readptr)
{ int n = StandardTypes_MaxBuf - readptr;
  if (ScanIO_scanin NEQ NULL)
  { return FileStream_Read (&ScanIO_buffer[readptr], 1, n, ScanIO_scanin);
  }
  else if (ScanIO_scanstring NEQ NULL)
  { if (n > stringsize) { n = stringsize; }
    memcpy (&ScanIO_buffer[readptr], ScanIO_scanstring, (unsigned)n);
    ScanIO_scanstring = &ScanIO_scanstring[n];
    stringsize -= n;
    return n;
  }
  return 0;
}

static void ScanIO_FillBuf (int from)
{ int readptr;
  bool stop;
  readptr = from;
  do
  { readptr += ReadBuf (readptr);
    stop = readptr >= StandardTypes_MaxBuf;
    if (NOT stop)
    { if ((ScanIO_inputs EQ NULL) OR (ScanIO_inputs->next EQ NULL))
      { ScanIO_ClearBuf(readptr);
        stop = TRUE;
      } 
      else 
      { ScanIO_inputs = ScanIO_inputs->next;
        if (ScanIO_scanin NEQ NULL)
        { FileStream_CloseInput (ScanIO_scanin); }
        ScanIO_reset_input ();
        ScanIO_ResetInput (readptr-from);
      }
    }
  } while (NOT stop);
} /* FillBuf */

void ScanIO_ResetBuf(void) 
{
  int i, j;
  if (ScanIO_startptr EQ -1)
  { ScanIO_fatalerror ((string)"token too long"); }
  j = 0;
  for (i = ScanIO_startptr+1; i <= ScanIO_tokenptr; i++)
  { ScanIO_buffer[j] = ScanIO_buffer[i];
    j++;
  }
  ScanIO_tokenptr -= ScanIO_startptr+1;
  ScanIO_rememberptr -= ScanIO_startptr+1;
  ScanIO_startptr = -1;
  ScanIO_FillBuf(ScanIO_tokenptr + 1);
} /* ResetBuf */

void ScanIO_rewrite (FileStream_WriteFile *s, char *fn) 
{
  if (NOT FileStream_CreateOutput ((string)fn, s))
  { TextIO_WriteString (SysStreams_sysErr, (string)"Cannot open file ");
    TextIO_WriteString (SysStreams_sysErr, (string)fn);
    TextIO_NewLine (SysStreams_sysErr);
    TextIO_Flush(SysStreams_sysErr);
    UnixProcess_Exit (UnixProcess_Failure);
  }
} /* rewrite */

/***************************************/
/* listing procedures                  */
/***************************************/

static int linenrcnt = 0;

static void *expand (void *array, unsigned int elem, unsigned int *size)
{ void *a = MyStorage_ALLOCATE ((cardinal)(2 * (*size) * elem));
  memcpy (a, array, *size * elem);
  *size = *size * 2;
  return a;
}

static ScanIO_InputFiles curr_input = NULL;

void ScanIO_writelnlist(void) 
{
  while (ScanIO_CharCount <= ScanIO_LineIndex[linenrcnt])
        /* Backup in case of back tracking */
  { linenrcnt--; }
  linenrcnt++;
  if (linenrcnt EQ (int)ScanIO_LineSize)
  { ScanIO_LineIndex = expand (ScanIO_LineIndex, sizeof (ScanIO_LineIndex[0]), &ScanIO_LineSize);
  }
  ScanIO_LineIndex[linenrcnt] = ScanIO_CharCount;
  while (curr_input->next!=NULL &&
         curr_input->next->firstchar >= 0 &&
         curr_input->next->firstchar <= ScanIO_CharCount)
  { curr_input = curr_input->next;
    ScanIO_StoreLineDir (0, curr_input->name); 
  }
} /* writelnlist */

/***************************************/
/* error procedure                     */
/***************************************/

static void ScanIO_FindPosition (int ch, int *line, int *pos)
{ int l, h, m;
  if (ch EQ 0)
  { *line = 0;
    *pos = 0;
    return;
  }
  if (ScanIO_LineIndex[linenrcnt] < ch)
  { *line = linenrcnt; }	/* past last line */
  else
  { l = 0;
    h = linenrcnt;
    while (l < h-1)
    { /* ScanIO_LineIndex[l] < ch <= ScanIO_LineIndex[h] */
      m = (l+h) DIV 2; /* l < m < h */
      if (ScanIO_LineIndex[m] >= ch) { h = m; }
      else                           { l = m; }
    }
    /* ScanIO_LineIndex[h-1] < ch <= ScanIO_LineIndex[h] AND l EQ h-1 */
    *line = l;
  }
  *pos = ch - ScanIO_LineIndex[*line];
  (*line)++;
} /* FindPosition */

/***************/

struct filelines { int absline;
                   int relline;
                   StandardTypes_Ident file_id;
                 } *ScanIO_FileIndex;

unsigned int ScanIO_FileSize;
static int filenrcnt = -1;

static StandardTypes_Ident last_pragma_file = NULL;

void ScanIO_StoreLineDir (int rel, StandardTypes_Ident f) 
{
  last_pragma_file = f;
  filenrcnt++;
  if (filenrcnt EQ (int)ScanIO_FileSize)
  { ScanIO_FileIndex = expand (ScanIO_FileIndex, sizeof (ScanIO_FileIndex[0]), &ScanIO_FileSize);
  }
  ScanIO_FileIndex[filenrcnt].absline = linenrcnt;
  ScanIO_FileIndex[filenrcnt].relline = rel;
  ScanIO_FileIndex[filenrcnt].file_id = f;
}

static void ScanIO_FindFilePosition (int abs, int *rel, StandardTypes_Ident *f)
{ int l, h, m;
  if (ScanIO_FileIndex[filenrcnt].absline < abs)
  { l = filenrcnt; }	/* past last line */
  else
  { l = 0;
    h = filenrcnt;
    while (l < h-1)
    { /* ScanIO_FileIndex[l].absline < abs <= ScanIO_FileIndex[h] */
      m = (l+h) DIV 2; /* l < m < h */
      if (ScanIO_FileIndex[m].absline >= abs) { h = m; }
      else                                    { l = m; }
    }
    /* ScanIO_FileIndex[h-1] < abs <= ScanIO_FileIndex[h] AND l EQ h-1 */
  }
  *rel = abs - ScanIO_FileIndex[l].absline
             + ScanIO_FileIndex[l].relline;
  *f   = ScanIO_FileIndex[l].file_id;
}

/***************/

StandardTypes_Ident ScanIO_FindFileName (int ch)
{ int line, pos;
  StandardTypes_Ident file;
  ScanIO_FindLocation (ch, &line, &pos, &file);
  return file;
} /* ScanIO_FindFileName */


void ScanIO_FindLocation (int ch, int *line, int *pos, StandardTypes_Ident *file)
{ int abs;
  ScanIO_FindPosition (ch, &abs, pos);
  ScanIO_FindFilePosition (abs, line, file);
}

ScanIO_FileLocation Create_ScanIO_FileLocation(StandardTypes_Int line,StandardTypes_Int pos,StandardTypes_Ident file)
{ 
  ScanIO_FileLocation qqqq;
  qqqq = MyStorage_Const_ALLOCATE((cardinal)((size_t)(&(((((ScanIO_FileLocation)NULL)->file))))+sizeof(StandardTypes_Ident)));
    ((qqqq->line)) = line;
    ((qqqq->pos)) = pos;
    ((qqqq->file)) = file;
  return (qqqq);
}

ScanIO_FileLocation ScanIO_XFindLocation (int ch)
{ int abs;
  ScanIO_FileLocation l = (ScanIO_FileLocation) MyStorage_ALLOCATE((cardinal)sizeof(*l));
  ScanIO_FindPosition (ch, &abs, &l->pos);
  ScanIO_FindFilePosition (abs, &l->line, &l->file);
  return l;
}

void ScanIO_LinePragma (string repr, int l)
{ int line;
  StandardTypes_Ident file;
  char *s0 = (char*)repr;
  char *s, *s1;
  char ch = s0[l];
  s0[l]=0;
  s = strchr (s0, 'e');
  s1 = strchr (s0, '"');
  if (s==NULL || s > s1)	/* gcc # l "id" problem */
    { s = strchr (s0, '#'); }
  s = strchr (s, ' ');
  sscanf (s, "%d", &line);
  s = strchr (s, '"');
  if (s==NULL) { file = NULL; }
  else
  { s++;
    s1 = strchr (s, '"');
    if (s1 != NULL)
    { file = Identifier_PutInIdTable ((string)s, 0, s1-s-1); }
    else
    { file = NULL; }  
  }
  if (file==NULL) 
  { if (last_pragma_file == NULL) 
    { file = ScanIO_inputs->name; }
    else
    { file = last_pragma_file; }
  }
  s0[l] = ch;
  ScanIO_StoreLineDir (line-1, file);
}

void ScanIO_error (int ch, string errortext, string terminal) 
{
  int line, pos;
  cardinal i;
  StandardTypes_Ident file;

  ScanIO_noerrors=FALSE;
  ScanIO_totalerrors++;
  if (ScanIO_maxerrors >= 0 && ScanIO_totalerrors > ScanIO_maxerrors)
  { ScanIO_SuppressContextChecks = TRUE; return; }
  ScanIO_FindLocation (ch, &line, &pos, &file);
  if (file)
  { TextIO_WriteCHAR (SysStreams_sysErr, '\"');
    TextIO_WriteString (SysStreams_sysErr, file->represent);
    TextIO_WriteString (SysStreams_sysErr, (string)"\", ");
  }
  TextIO_WriteString (SysStreams_sysErr, (string)"line ");
  TextIO_WriteINTEGER(SysStreams_sysErr, line);
  TextIO_WriteString (SysStreams_sysErr, (string)"  ");
  TextIO_WriteINTEGER(SysStreams_sysErr,pos);
  TextIO_WriteString (SysStreams_sysErr, (string)"  ");
  TextIO_WriteString(SysStreams_sysErr,errortext);
  if (terminal[0] NEQ '\0')
  { TextIO_WriteString (SysStreams_sysErr, (string)" (");
    i = 0;
    while ((terminal[i] NEQ '\0') AND (terminal[i] NEQ ' '))
    { TextIO_WriteCHAR (SysStreams_sysErr, terminal[i]);
      i++;
    }
    TextIO_WriteString (SysStreams_sysErr, (string)" encountered)");
  }
  TextIO_NewLine (SysStreams_sysErr);
  TextIO_Flush (SysStreams_sysErr);
} /* error */

void ScanIO_FlushError(void) 
{
  if (ScanIO_maxerrors >= 0 && ScanIO_totalerrors > ScanIO_maxerrors)
  { ScanIO_SuppressContextChecks = TRUE; return; }
  TextIO_NewLine(SysStreams_sysErr);
  TextIO_Flush(SysStreams_sysErr);
} /* FlushError */

void ScanIO_OpenError (int ch, bool warning) 
{ 
  int line, pos;
  StandardTypes_Ident file;
  if (warning)
  { ScanIO_totalwarnings++;
  } 
  else 
  { ScanIO_totalerrors++;
    ScanIO_noerrors = FALSE;
    if (ScanIO_maxerrors >= 0 && ScanIO_totalerrors > ScanIO_maxerrors)
    { ScanIO_SuppressContextChecks = TRUE;
      if (ScanIO_totalerrors == ScanIO_maxerrors+1)
      { TextIO_WriteString (SysStreams_sysErr, 
         (string)"Too many error messages: remaining messages are suppressed\n");
        TextIO_Flush (SysStreams_sysErr);
      }
      return; }
  }
  ScanIO_FindLocation (ch, &line, &pos, &file);
  if (file)
  { TextIO_WriteCHAR (SysStreams_sysErr, '\"');
    TextIO_WriteString (SysStreams_sysErr, file->represent);
    TextIO_WriteString (SysStreams_sysErr, (string)"\", ");
  }
  TextIO_WriteString (SysStreams_sysErr, (string)"line ");
  TextIO_WriteINTEGER(SysStreams_sysErr,line);
  TextIO_WriteString (SysStreams_sysErr, (string)"  ");
  TextIO_WriteINTEGER(SysStreams_sysErr,pos);
  TextIO_WriteString (SysStreams_sysErr, (string)"  ");
  if (warning) { TextIO_WriteString (SysStreams_sysErr, (string)"Warning: "); } 
} /* OpenError */

void ScanIO_fatalerror (string text) 
{
  int line, pos;
  StandardTypes_Ident file;
  ScanIO_FindLocation(ScanIO_CharCount, &line, &pos, &file);
  if (NOT ScanIO_inputerrors)
  { if (file)
    { TextIO_WriteString (SysStreams_sysErr, file->represent);
      TextIO_WriteCHAR (SysStreams_sysErr, ':');
    }
    TextIO_NewLine (SysStreams_sysErr);
    ScanIO_inputerrors = TRUE;
  }
  ScanIO_noerrors=FALSE;
  ScanIO_SuppressContextChecks = TRUE;
  ScanIO_totalerrors++;
  TextIO_WriteINTEGER(SysStreams_sysErr,line);
  TextIO_WriteString (SysStreams_sysErr, (string)"  ");
  TextIO_WriteINTEGER(SysStreams_sysErr,pos);
  TextIO_WriteString (SysStreams_sysErr, (string)"  ");
  TextIO_WriteString (SysStreams_sysErr, (string)"?? fatalerror : ");
  TextIO_WriteString(SysStreams_sysErr,text);
  TextIO_NewLine (SysStreams_sysErr);
  TextIO_Flush(SysStreams_sysErr);
  ScanIO_finalize();
  UnixProcess_Exit (UnixProcess_Failure);
} /* fatalerror */

static void AddInput (StandardTypes_Ident id, StandardTypes_String str, StandardTypes_Int strlen) 
{
  if (ScanIO_inputs EQ NULL)
  { ScanIO_inputs = MyStorage_Const_ALLOCATE (sizeof(*ScanIO_inputs));
    ScanIO_lastinput = ScanIO_inputs;
    ScanIO_firstinput = ScanIO_inputs;
    curr_input = ScanIO_firstinput;
  } 
  else 
  { (ScanIO_lastinput->next) = MyStorage_Const_ALLOCATE (sizeof(*ScanIO_lastinput));
    ScanIO_lastinput = ScanIO_lastinput->next;
  }
  ScanIO_lastinput->name = id;
  ScanIO_lastinput->next = NULL;
  ScanIO_lastinput->str = str;
  ScanIO_lastinput->strlen = strlen;
  ScanIO_lastinput->firstchar = -1;
} /* AddInput */

void ScanIO_AddInputFile (StandardTypes_Ident id) 
{ AddInput (id, NULL, 0);
} 

void ScanIO_AddInputString (StandardTypes_String str, StandardTypes_Int strlen, StandardTypes_Ident name) 
{ AddInput (name, str, strlen);
} 

void ScanIO_OpenInputs(void) 
{
  if (ScanIO_inputs NEQ NULL)
  { ScanIO_reset_input ();
    ScanIO_ResetInput (0);  
    linenrcnt = 0;
    /* Scanner.nextchar increases it for the very first file. */
    ScanIO_FillBuf (0);
    ScanIO_StoreLineDir (0, ScanIO_firstinput->name); 
  }
  ScanIO_CharCount = 0;
} /* OpenInputs */

void ScanIO_OpenFreshInput (StandardTypes_Ident id) 
/* ScanIO_scanin is already opened on the required file */
{
  int readptr;
  ScanIO_inputs = MyStorage_Const_ALLOCATE (sizeof(*ScanIO_inputs));
  ScanIO_inputs->name = id;
  ScanIO_inputs->firstchar = 0;
  ScanIO_inputs->next = NULL;
  ScanIO_inputs->str  = NULL;
  ScanIO_lastinput = ScanIO_inputs;
  ScanIO_firstinput = ScanIO_inputs;
  curr_input = ScanIO_firstinput;
  ScanIO_CharCount = 0;
  ScanIO_ResetInput (0);
  linenrcnt = 0;
              /* Scanner.nextchar increases it for the very first file. */
  filenrcnt = -1;
  readptr = 0;
  readptr += ReadBuf (readptr);
  if (readptr < StandardTypes_MaxBuf)
  { ScanIO_ClearBuf(readptr); }
  ScanIO_startptr = -1;
  ScanIO_tokenptr = -1;
  ScanIO_StoreLineDir (0, ScanIO_inputs->name); 
} /* OpenFreshInput */

void ScanIO_ReInit(void)
{
/*  initscan; !!!! initscan generated by scannergenerator */
  ScanIO_inputs = NULL;
  ScanIO_lastinput = 0;
  ScanIO_CharCount = 0;
  linenrcnt = 0;
  filenrcnt = -1;
} /* ReInit */

void ScanIO_finalize(void) 
{
  if (ScanIO_scanin NEQ NULL) 
  { FileStream_CloseInput (ScanIO_scanin);  }
  ScanIO_scanin = NULL;
  ScanIO_scanstring = NULL;
} /* finalize */

#define PRINTNIL(s) if (s == NULL) { printf("NIL"); return; }

static int initdone = 0;

void ScanIO_InitGlobals(void)
{
  if (initdone) { return; }
  initdone = 1;
  ScanIO_ReInit();
  ScanIO_totalerrors=0;
  ScanIO_totalwarnings=0;
  ScanIO_maxerrors= -1;
  ScanIO_noerrors=TRUE;
  ScanIO_SuppressContextChecks = FALSE;
  ScanIO_SuppressWarnings = FALSE;
  ScanIO_deleting = FALSE;
  ScanIO_LineSize = 2048; 
  ScanIO_LineIndex = MyStorage_ALLOCATE (
           (cardinal)(ScanIO_LineSize * sizeof (ScanIO_LineIndex[0])));
  MyStorage_GC_Set_Global (&ScanIO_LineIndex);
  ScanIO_LineIndex[0] = 0;
  ScanIO_FileSize = 2048; 
  ScanIO_FileIndex = MyStorage_ALLOCATE (
           (cardinal)(ScanIO_FileSize * sizeof (ScanIO_FileIndex[0])));
  MyStorage_GC_Set_Global (&ScanIO_FileIndex);
  ScanIO_RefAttribute = & ScanIO_ScanAttribute;
  MyStorage_GC_Set_Global (&ScanIO_RefAttribute);

  MyStorage_GC_Set_Global (&ScanIO_inputs);
  MyStorage_GC_Set_Global (&ScanIO_firstinput);
  MyStorage_GC_Set_Global (&ScanIO_lastinput);
  MyStorage_GC_Set_Global (&ScanIO_scanstring);
  MyStorage_GC_Set_Global (&curr_input);
  MyStorage_GC_Set_Global (&ScanIO_scanin);
}

/* END ScanIO */

