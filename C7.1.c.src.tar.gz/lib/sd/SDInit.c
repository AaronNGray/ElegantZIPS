/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef __SYSTEM
#include "SYSTEM.h"
#endif

#ifndef __ScanIO
#include "ScanIO.h"
#endif

#ifndef __RTSInit
#include "RTSInit.h"
#endif

#ifndef __Identifier
#include "Identifier.h"
#endif

#ifndef __SingleOutput
#include "SingleOutput.h"
#endif

#ifndef __StandardTypes
#include "StandardTypes.h"
#endif

#ifndef __LazyCodeModule
#include "LazyCodeModule.h"
#endif

#ifndef __ScanIO
#include "ScanIO.h"
#endif

void SDInit_Init(void) 
{ RTSInit_Init();
  Identifier_Init();
  SingleOutput_Init();
  LazyCodeModule_Init();
  ScanIO_InitGlobals();
  StandardTypes_Init ();
} 

/* END Init */

