/* Copyright (C) 2000 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 2000 Philips Electronics N.V. **
**                                             **
************************************************/

/* File : BTSupport.h 
   Run-time support for back-tracking parser.
*/

#ifndef _BTSupport
#define _BTSupport

#ifndef _StandardTypes
#include "StandardTypes.h"
#endif

#ifndef _Machines
#include "Machines.h"
#endif

#define BTSUPPORT_SUCCESS (1<<(Machines_BITSPERWORD-1))
#define BTSUPPORT_FAIL (0)

typedef unsigned int (*BTSupport_ContProc)();

/* Continuation c is a closure (c->p)(c->c)
   if result & BTSUPPORT_SUCCESS: success,
   result & ~BTSUPPORT_SUCCESS = #symbols parsed successfully
*/
typedef struct BTSupport_Continuation {
      BTSupport_ContProc p;
      struct BTSupport_Continuation *c;
      struct BTSupport_Continuation *prev; /* for memoization */
      struct BTSupport_Continuation *next; /* for memoization */
} *BTSupport_Continuation;

/* List of choices (production rule numbers) made during a parse */
typedef struct BTSupport_ChoiceList {
    struct BTSupport_ChoiceList *next;
    StandardTypes_Int choice;
} *BTSupport_ChoiceList;

/* List of choices made at a terminal position */
typedef struct BTSupport_NT_Choice {
  struct BTSupport_NT_Choice *next;
  StandardTypes_Int nonterm;
  BTSupport_Continuation cont;
  StandardTypes_Int choice;
  BTSupport_ContProc proc;
} *BTSupport_NT_Choice;

/* List of terminals visited during a parse */
typedef struct BTSupport_TermList {
    struct BTSupport_TermList *next;
    StandardTypes_Int sym;
    StandardTypes_Int charcount, length;
    StandardTypes_SimpleType attribute;
    BTSupport_NT_Choice choices;
} *BTSupport_TermList;

#define BTSUPPORT_CHOOSE(num, proc) \
  if (max == BTSUPPORT_FAIL || m >= max) \
  { choice->choice = num; \
    p = proc; \
    max = m; \
  }

/**********************************/

extern BTSupport_ChoiceList
         BTSupport_FirstChoice, 
         BTSupport_ThisChoice, 
         BTSupport_LastChoice;

/* Recognizes epsilon and returns SUCCESS */
extern BTSupport_Continuation BTSupport_success;

extern BTSupport_Continuation 
  BTSupport_NewCont (BTSupport_ContProc p, BTSupport_Continuation c);

/* Append one element to the choicelist */
extern BTSupport_ChoiceList 
  BTSupport_ClaimChoice(void);

/* (c->p)(c->c) */
extern unsigned int 
  BTSupport_Continue (BTSupport_Continuation c);

/* Attempt p (success) */
extern unsigned int 
BTSupport_Try (BTSupport_ContProc p);

extern BTSupport_TermList BTSupport_FirstTerm, 
                          BTSupport_ThisTerm, 
                          BTSupport_LastTerm;

extern void (*BTSupport_NextSym)(void);

/* Parse next symbol from list or from scanner */
extern void BTSupport_PushNextSym(void);

/* Pop one symbol from l into scanner state */
extern void BTSupport_ResetTerms (BTSupport_TermList l);

extern void BTSupport_Init(StandardTypes_Int *scanner_sym,
                           void (*scanner_nextsym)());


/* Allocate a choice and add it to ThisTerm */
extern BTSupport_NT_Choice 
  BTSupport_NewChoice (BTSupport_TermList term, 
                       StandardTypes_Int nonterm,
		       BTSupport_Continuation cont, 
		       StandardTypes_Int choice,
		       BTSupport_ContProc p);

/* Find in ThisTerm a coice for nonterm */
extern BTSupport_NT_Choice 
  BTSupport_FindChoice (StandardTypes_Int nonterm,
                	BTSupport_Continuation cont);

#endif /* BTSupport */
