/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/


#ifndef __StandardTypes
#include "StandardTypes.h"
#endif

#ifndef __MyStorage
#include "MyStorage.h"
#endif

#ifndef __TextIO
#include "TextIO.h"
#endif

#ifndef __SysStreams
#include "SysStreams.h"
#endif

#ifndef __FileStream
#include "FileStream.h"
#endif

#ifndef __Strings
#include "Strings.h"
#endif

#ifndef __SystemTypes
#include "SystemTypes.h"
#endif

#ifndef __UnixProcess
#include "UnixProcess.h"
#endif

#ifndef __Identifier
#include "Identifier.h"
#endif

#define Identifier_MaxHash (1024)

static StandardTypes_Ident Identifier_HashTable[Identifier_MaxHash];


/* Identifiertable handling */

StandardTypes_Ident Identifier_NewIdent (int len, int start, string buffer)
{
  StandardTypes_Ident p;
  p = MyStorage_Const_ALLOCATE (sizeof(StandardTypes_RecIdent));
  if (MyStorage_CollectIdent) MyStorage_GC_Set_Memo (p);
  p->length=len;
  p->next=NULL;
  p->info = NULL;
  p->represent = MyStorage_Const_ALLOCATE ((cardinal)((p->length+1)*sizeof(Char)));
  p->represent[p->length] = '\0';
  StandardTypes_Pack (buffer,start,p->represent,0,p->length-1);
  return (p);
} /* NewIdent */

#define HASH1(s,lo,hi,len) ((s[lo]+s[hi])*len)
#define HASH2(s,lo,hi,len) ((s[lo]<<3)^(s[hi])^len)
#define HASH(s,lo,hi,len) ((s[lo]<<3)^(s[hi])^len^(len<<6))

StandardTypes_Ident Identifier_PutInIdTable (string s, int lo, int hi)
{
  int hashindex, i;
  StandardTypes_Ident h1, *h2, id;
  int symbollength = hi-lo+1;
  Char *b;
  Char *c;
  if (symbollength EQ 0)
  { hashindex = 0; }
  else
  { hashindex = HASH(s, lo, hi, symbollength) MOD Identifier_MaxHash;
  }
  h2 = &Identifier_HashTable [hashindex];
  h1 = *h2;

  if ((int)&s[lo] % MyStorage_BYTESPERWORD == 0) {
    /* Both strings are word-aligned, compare word-by-word */
    int *b1, *c1;
    for (; h1 != NULL; h2 = &h1->next, h1 = h1->next) {
      if (symbollength != h1->length) continue;
      b1 = (int*) &s[lo];
      c1 = (int*)h1->represent;
      for (i=MyStorage_BYTESPERWORD; i < symbollength; i+=MyStorage_BYTESPERWORD) {
	if (*b1++ != *c1++) break;
      }
      if (i < symbollength) continue;
      i -= MyStorage_BYTESPERWORD;
      
      b = (Char *)b1;
      c = (Char *)c1;
      for (; i < symbollength; i++) {
	if (*b++ != *c++) break;
      }      
      if (i >= symbollength) {
	return h1;
      }
    }
  } else {
    /* Unaligned, compare byte-by-byte */
    for (; h1 != NULL; h2 = &h1->next, h1 = h1->next) {
      if (symbollength != h1->length) continue;
      b = &s[lo];
      c = h1->represent;
      for (i=0; i < symbollength; i++) {
	if (*b++ != *c++) break;
      }
      if (i >= symbollength) {
	return h1;
      }
    }
  }
  
  id = Identifier_NewIdent (symbollength, lo, s);
  *h2 = id;
  /*printf ("NEW: %s, index %d\n", id->represent, hashindex);*/
  return (id) ;
} /* PutInIdTable */

StandardTypes_Ident Identifier_FromString (string s)
{
  int len = 0;
  if (s EQ NULL) { return NULL; }
  while (s[len]) len++;
  return (Identifier_PutInIdTable (s, 0, len-1));
} /* FromString */

string Identifier_AsString (StandardTypes_Ident id)
{
  if (id EQ NULL) { return NULL; }
  return ((string)(id->represent));
} /* AsString */

StandardTypes_Int Identifier_Length (StandardTypes_Ident id)
{
  return (id->length);
} /* Length */

void Identifier_Init(void)
{
  MyStorage_GC_Set_Globals (&Identifier_HashTable[0], &Identifier_HashTable[Identifier_MaxHash-1], MyStorage_CollectIdent);
}

/* END Identifier */

