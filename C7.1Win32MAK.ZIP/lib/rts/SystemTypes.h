/* Copyright (C) 1997 Philips Electronics N.V.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file gnu_license.txt.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/************************************************
**                                             **
** Copyright (C) 1995 Philips Electronics N.V. **
**                                             **
************************************************/

#ifndef __SystemTypes
#define __SystemTypes

#ifndef __SYSTEM
#include "SYSTEM.h"
#endif

#define _CAT(x,y) x##y
#define CAT(x,y)  _CAT(x,y)

#define SIZE_void 0

#ifdef _sun4
#include "ts_sun4.h"
#endif
#ifdef _solaris
#include "ts_solaris.h"
#endif
#ifdef _hp700
#include "ts_hp700.h"
#endif
#ifdef _dos
#include "ts_dos.h"
#endif
#if _i486
#include "ts_i486.h"
#endif
#if _sgi
#include "ts_sgi.h"
#endif
#ifdef WIN32
#include "ts_Win32.h"
#endif

#define SIZE_0 0
#define SIZE_1 1
#define SIZE_2 2
#define SIZE_4 4
#define SIZE_8 8

/* CONST */
/* #define MAXCARD  ((CARDINAL)4294967295) */

typedef Char byte; /* [0 .. 255] */

typedef char signedbyte; /* [-128 .. 127] */

typedef enum {SystemTypes_EQ, SystemTypes_NE, SystemTypes_LT, 
              SystemTypes_GT, SystemTypes_LE, SystemTypes_GE} 
        SystemTypes_Comparison;
    /*  generic enumerated type which can be used by all
        modules which need simple comparisons. (e.g strings)
    */

extern void SystemTypes_InitGlobals (void);

#endif /*  SystemTypes */

