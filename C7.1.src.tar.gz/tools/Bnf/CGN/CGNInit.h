/* File : CGNInit.h */

#ifndef _CGNInit
#define _CGNInit

extern void CGNInit_Init(void);

#endif /* CGNInit */
